---@class UIFishingControllerLayout : IGUILayout
local UIFishingControllerLayout = class("UIFishingControllerLayout", IGUILayout)
---@type FishingState
local FishingState = T(Global, "FishingState")
---@type CFishingGroundMgr
local CFishingGroundMgr = T(Global, "FishingGroundMgr")
local BagContentType = {
    Cur = 1,
    History = 2
}
local BagTypeView = {
    [BagContentType.Cur] = {
        title = "gui.fish.bag.title.cur",
        select = "set:bed_war_fishing.json image:img_0_icon_1",
        unselect = "set:bed_war_fishing.json image:img_0_icon_1mask"
    },
    [BagContentType.History] = {
        title = "gui.fish.bag.title.history",
        select = "set:bed_war_fishing.json image:img_0_icon_2",
        unselect = "set:bed_war_fishing.json image:img_0_icon_2mask"
    }
}
local TabBg = {
    Select = "set:bed_war_fishing.json image:img_0_select_bg",
    Unselect = ""
}
local function onShowUIFlyTextAnim(widthSum, maxHeight, scale)
    scale = 2
    local height = 30
    local width = height * (widthSum / maxHeight)
    local posX = 0.44 + math.random(1, 3) * 0.02
    local posY = 0.4
    ---@type FishingFlyText
    local window = UIHelper.newGameGUIWindow("FishingFlyText", "FishingFlyText.json")
    window.root:SetArea({ posX, -width / 2 }, { posY, -height / 2 }, { 0, width * scale }, { 0, height * scale })
    GUISystem.Instance():GetRootWindow():AddChildWindow(window.root)
    local alpha = 1.2
    LuaTimer:scheduleTimer(function()
        alpha = alpha - 0.05
        if window and window.root then
            window.root:SetYPosition({ 0.4 - (1.2 - alpha) * 0.2, -height / 2 })
            window.root:SetAlpha(alpha)
            if alpha <= 0 then
                GUIManager:destroyGUIWindow(window.root)
                window = nil
            end
        end
    end, 50, 1.2 / 0.05)
end

---@private
function UIFishingControllerLayout:ctor(parent)
    self.super.ctor(self, "FishingController.json", parent)
end

---@private
function UIFishingControllerLayout:isDelayLoad()
    return true
end

---@private
function UIFishingControllerLayout:onCreate()
    self.pullProgress = 0
    self:initCreateEvent()
end

---@private
function UIFishingControllerLayout:initCreateEvent()
    self:registerEvent(Events.PlayerStartFishingEvent, function(userId)
        if userId == Game:getPlatformUserId() then
            self:show()
        end
    end)
    self:registerEvent(Events.PlayerStopFishingEvent, function(userId)
        if userId == Game:getPlatformUserId() then
            self:hide()
        end
    end)
end

---@private
function UIFishingControllerLayout:onLoad()
    self.btnToss = self:getChildWindow("FishingController-Toss", GUIType.Button)
    self.siTossEffect = self:getChildWindow("FishingController-TossEffect", GUIType.StaticImage)
    self.btnPull = self:getChildWindow("FishingController-Pull", GUIType.Button)
    self.siPullEffect = self:getChildWindow("FishingController-PullEffect", GUIType.StaticImage)
    self.btnExit = self:getChildWindow("FishingController-Exit", GUIType.Button)
    self.pbProgress = self:getChildWindow("FishingController-Progress", GUIType.ProgressBar)
    self.btnBagBtn = self:getChildWindow("FishingController-BagBtn", GUIType.Button)
    self.siBag = self:getChildWindow("FishingController-Bag", GUIType.StaticImage)
    self.stBagTitle = self:getChildWindow("FishingController-Bag-Title", GUIType.StaticText)
    self.btnBagCloseBtn = self:getChildWindow("FishingController-Bag-Close-Btn", GUIType.Button)
    self.siBagNull = self:getChildWindow("FishingController-Bag-Null", GUIType.StaticImage)
    self.siBagContent = self:getChildWindow("FishingController-Bag-Content", GUIType.StaticImage)
    self.curBagType = BagContentType.Cur
    self.tabs = {
        [BagContentType.Cur] = {
            btn = self:getChildWindow("FishingController-Bag-Tab-1", GUIType.Button),
            icon = self:getChildWindow("FishingController-Bag-Tab-Icon-1", GUIType.StaticImage)
        },
        [BagContentType.History] = {
            btn = self:getChildWindow("FishingController-Bag-Tab-2", GUIType.Button),
            icon = self:getChildWindow("FishingController-Bag-Tab-Icon-2", GUIType.StaticImage)
        }
    }
    self:initView()
    self:initEvent()
end

---@private
function UIFishingControllerLayout:initView()
    self.btnPull:SetVisible(false)
    self.btnToss:SetVisible(false)
    self.pbProgress:SetVisible(false)
    self.siBag:SetVisible(false)
    self.gvBagContent = IGUIGridView.new("FishingController-Bag-Content-Grid-View", self.siBagContent)
    self.gvBagContent.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.gvBagContent.root:SetVerticalAlignment(VerticalAlignment.Center)
    self.gvBagContent.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.gvBagContent:setConfig(30, 25, 3)
    ---@type FishBagItemAdapter
    self.bagAdapter = UIHelper.newGameAdapter("FishBagItemAdapter")
    local itemWidth = (self.gvBagContent:getWidth() - 60) / 3
    self.bagAdapter:setItemSize(itemWidth, itemWidth)
    self.gvBagContent:setAdapter(self.bagAdapter)
end

---@private
function UIFishingControllerLayout:initEvent()
    self.btnPull:registerEvent(GUIEvent.ButtonClick, function()
        onShowUIFlyTextAnim(182, 109, 2)
        self:updatePullProgress(20)
    end)
    self.btnToss:registerEvent(GUIEvent.ButtonClick, function()
        if self.state == FishingState.WaitToss then
            self:changeFishingState(FishingState.TossRod)
            PlayerManager:getClientPlayer():sendPacket({
                pid = "TryTossFishingRod"
            })
        elseif self.state == FishingState.WaitFish then
            self:changeFishingState(FishingState.FishRunAway)
            PlayerManager:getClientPlayer():sendPacket({
                pid = "TryTossFishingRod"
            })
        end
    end)
    self.btnExit:registerEvent(GUIEvent.ButtonClick, function()
        PlayerManager:getClientPlayer():sendPacket({
            pid = "TryStopFishing"
        })
    end)
    self:registerEvent(Events.PlayerFishingStateChangeEvent, function(userId, state)
        if userId ~= Game:getPlatformUserId() then
            return
        end
        self:changeFishingState(state)
    end)
    self.btnBagBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:showFishingBag(true)
    end)
    self.btnBagCloseBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:showFishingBag(false)
    end)
    for type, tab in pairs(self.tabs) do
        tab.btn:registerEvent(GUIEvent.ButtonClick, function()
            self:setTab(type)
        end)
    end
end

function UIFishingControllerLayout:onTick(frameTime)
    if self.state == FishingState.Pulling then
        self:updatePullProgress(-1)
    end
end

function UIFishingControllerLayout:updatePullProgress(progress)
    if self.pullProgress == 0 then
        return
    end
    self.pullProgress = self.pullProgress + progress
    if self.pullProgress <= 0 then
        self.pullProgress = 0
        self:changeFishingState(FishingState.FishRunAway)
        PlayerManager:getClientPlayer():sendPacket({
            pid = "OnFishRunAway",
        })
    elseif self.pullProgress >= 200 then
        self.pullProgress = 0
        self:changeFishingState(FishingState.CatchFish)
        PlayerManager:getClientPlayer():sendPacket({
            pid = "TryCatchFish",
        })
    end
    self.pbProgress:SetProgress(self.pullProgress / 200)
end

---@private
function UIFishingControllerLayout:changeFishingState(state)
    LuaTimer:cancel(self.pullEffectTimer)
    LuaTimer:cancel(self.tossEffectTimer)
    self.state = state
    if state == FishingState.WaitToss then
        self.btnToss:SetVisible(true)
        self.btnPull:SetVisible(false)
        self.pbProgress:SetVisible(false)
        self.tossEffectTimer = LuaTimer:scheduleTicker(function()
            self.siTossEffect:PlayEffect1("")
            self.siTossEffect:SetEffectName("g1008_effect_ui_buttonlight.effect")
        end, 150)
    elseif state == FishingState.TossRod then
        self.btnToss:SetVisible(false)
        self.btnPull:SetVisible(false)
        self.pbProgress:SetVisible(false)
    elseif state == FishingState.WaitFish then
        self.btnToss:SetVisible(true)
        self.btnPull:SetVisible(false)
        self.pbProgress:SetVisible(false)
    elseif state == FishingState.Pulling then
        self.pullProgress = 100
        self.btnToss:SetVisible(false)
        self.btnPull:SetVisible(true)
        self.pbProgress:SetVisible(true)
        self.pbProgress:SetProgress(self.pullProgress / 200)
        self.pullEffectTimer = LuaTimer:scheduleTicker(function()
            self.siPullEffect:PlayEffect1("")
            self.siPullEffect:SetEffectName("g1008_effect_ui_buttonlight.effect")
        end, 30)
    elseif state == FishingState.CatchFish then
        self.btnToss:SetVisible(false)
        self.btnPull:SetVisible(false)
        self.pbProgress:SetVisible(false)
    elseif state == FishingState.FishRunAway then
        self.btnToss:SetVisible(false)
        self.btnPull:SetVisible(false)
        self.pbProgress:SetVisible(false)
    end
end

function UIFishingControllerLayout:onHide()
    LuaTimer:cancel(self.pullEffectTimer)
    LuaTimer:cancel(self.tossEffectTimer)
end

function UIFishingControllerLayout:showFishingBag(isShow)
    self.siBag:SetVisible(isShow)
    if isShow then
        self:setTab(BagContentType.Cur)
    end
end

function UIFishingControllerLayout:setTab(type)
    for tabType, tab in pairs(self.tabs) do
        tab.btn:SetNormalImage(tabType == type and TabBg.Select or TabBg.Unselect)
        tab.btn:SetPushedImage(tabType == type and TabBg.Select or TabBg.Unselect)
        tab.icon:SetImage(tabType == type and BagTypeView[tabType].select or BagTypeView[tabType].unselect)
    end
    self.curBagType = type
    self:setBagContent()
end

function UIFishingControllerLayout:setBagContent()
    local data = {}
    local viewSetting = BagTypeView[self.curBagType]
    self.stBagTitle:SetText(Lang:getString(viewSetting.title))

    if self.curBagType == BagContentType.Cur then
        data = CFishingGroundMgr:getFishingOwn()
    elseif self.curBagType == BagContentType.History then
        data = CFishingGroundMgr:getFishingHistory()
    end

    if TableUtil.isEmpty(data) then
        self.siBagContent:SetVisible(false)
        self.siBagNull:SetVisible(true)
    else
        self.siBagContent:SetVisible(true)
        self.siBagNull:SetVisible(false)
        self.bagAdapter:setData(data)
    end
end

return UIFishingControllerLayout
