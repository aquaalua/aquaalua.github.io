---@class LuckyTurntableConfig
local LuckyTurntableConfig = T(Global, "LuckyTurntableConfig")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")

---@type LuckyTurntableData[]
local ConfigList = {}
---@type LuckyTurntableRewardData[]
local RewardConfig = {}

local function initConfig()
    local settings = FileUtil.getConfigFromCsv("plugins/activity/LuckyTurntableReward.csv", 2, true)
    for _, item in pairs(settings) do
        ---@type CommonActivityRewardData
        local rewardCfg = CommonActivityConfig:getRewardById(item.rewardId)
        if rewardCfg then
            ---@type CommonActivityRewardData
            local reward = TableUtil.copyTable(rewardCfg)
            reward.num = tonumber(item.num)
            ---@class LuckyTurntableRewardData
            local data = {
                id = tonumber(item.id),
                activityId = tonumber(item.activityId),
                groupSeq = tonumber(item.groupSeq),
                reward = reward,
                isCore = tonumber(item.isCore),
                weight = tonumber(item.weight),
                limitCount = tonumber(item.limitCount),
            }
            table.insert(RewardConfig, data)
        end
    end

    settings = FileUtil.getConfigFromCsv("plugins/activity/LuckyTurntable.csv", 2, true)

    for _, item in pairs(settings) do
        ---@class LuckyTurntableData
        local data = {
            activityId = tonumber(item.activityId),
            type = tonumber(item.type),
            price = tonumber(item.price),
            uniqueId = tonumber(item.uniqueId),
            weights = 0,
            rewardCfg = nil,
        }
        ConfigList[data.activityId] = data
    end
end

function LuckyTurntableConfig:getActivityById(activityId)
    ---@param cfg LuckyTurntableData
    for _, cfg in pairs(ConfigList) do
        if cfg.activityId == activityId then
            if cfg.rewardCfg == nil then
                cfg.rewardCfg = {}
                for _, reward in pairs(RewardConfig) do
                    if reward.activityId == activityId then
                        cfg.weights = cfg.weights + reward.weight
                        table.insert(cfg.rewardCfg, reward)
                    end
                end
                table.sort(cfg.rewardCfg, function(a, b)
                    return a.groupSeq < b.groupSeq
                end)
            end
            return cfg
        end
    end
    return nil
end

initConfig()

return LuckyTurntableConfig