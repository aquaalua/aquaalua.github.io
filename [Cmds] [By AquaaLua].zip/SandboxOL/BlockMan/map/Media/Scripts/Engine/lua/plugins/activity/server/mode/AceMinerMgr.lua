---@class AceMinerDBData
local initAceMinerDBData = {
    receiveCount = 0,
}

---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")

---@type AceMinerConfig
local AceMinerConfig = Plugins.Require("activity", "common.config.AceMinerConfig")

---@type SBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "server.mode.BaseActivityMgr")

---@class SAceMinerMgr : SBaseActivityMgr
local AceMinerMgr = class("SAceMinerMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.AceMiner, AceMinerMgr, AceMinerConfig)

--local function getDayStartTime(time)
--    local t = os.date("*t", time)
--    local timestamp = DateUtil.date2BeiJingTime({ year = t.year, month = t.month, day = t.day, hour = 0, min = 0, sec = 0 })
--    return timestamp
--end

--local function getDeltaDay(startTime, endTime)
--    local deltaDay = (getDayStartTime(endTime) - getDayStartTime(startTime)) / (3600 * 24)
--    return math.floor(deltaDay)
--end

--local function getCanReceiveCount(self, startTime, curTime)
--    if curTime < startTime then
--        return 0
--    end
--    local deltaDay = getDeltaDay(startTime, curTime)
--    if deltaDay < 0 then
--        return 0
--    end
--    local maxNum = AceMinerConfig:getMaxBoxNum(self.mainConfig.id)
--    if deltaDay >= maxNum then
--        return maxNum
--    end
--    return deltaDay + 1
--end

----------------------------------------------------------------------------------
---@param mgrConfig AceMinerConfigData
function AceMinerMgr:initActivity(mgrConfig)
    ---@private
    self.config = mgrConfig
end

---@param player SBasePlayer
function AceMinerMgr:initPlayerCache(player, data)
    data = data or {}
    local cache = {}
    for key, default in pairs(initAceMinerDBData) do
        cache[key] = data[key] or default
    end
    self:setPlayerCache(player, cache)
end

-------------------------------------功能相关---------------------------------------------------
---@param player SBasePlayer
function AceMinerMgr:buy(player)
    ---@type AceMinerDBData
    local cache = self:getPlayerCache(player)
    local maxBoxNum = AceMinerConfig:getMaxBoxNum(self.mainConfig.id)
    if cache.receiveCount >= maxBoxNum then
        return
    end
    local num = cache.receiveCount + 1
    if not self.config[num] then
        return
    end
    --local canReceiveCount = getCanReceiveCount(self, self.mainConfig.startTime, os.time())
    --if cache.receiveCount >= canReceiveCount then
    --    return
    --end

    local price = self.config[num].price
    local uniqueId = self.config[num].uniqueId
    self:payMoney(player, uniqueId, CurrencyId.GCube, price, function()
        cache.receiveCount = num
        self:setPlayerCache(player, cache)

        -- report
        ReportEvent.activity_ace_miner_buy(player, self.mainConfig.id, num)

        -- 延迟1秒给客户端播放动画
        LuaTimer:schedule(function()
            if player then
                self:tryGetReward(player, num)
                player:sendPacket({
                    pid = "GameActivityAceMinerStartAnimation",
                    start = false
                })
            end
        end, 1000)
    end)
end

local function tryReceive(self, player, items)
    local results = {}
    for i, item in pairs(items) do
        local reward = CommonActivityConfig:getRewardById(item.id)
        if reward then
            reward = TableUtil.copyTable(reward)
            reward.num = item.num
            local realReward = self:receiveReward(player, reward)
            if realReward then
                local newRewardId = realReward.realRewardId or realReward.rewardId
                if not results[newRewardId] then
                    results[newRewardId] = { rewardId = newRewardId, num = reward.num }
                else
                    results[newRewardId].num = results[newRewardId].num + reward.num
                end
            end
        end
    end
    local rewards = {}
    for i, v in pairs(results) do
        table.insert(rewards, v)
    end
    table.sort(rewards, function(a, b)
        return a.rewardId < b.rewardId
    end)
    local tableSize = TableUtil.getTableSize(rewards)
    if tableSize > 0 then
        player:sendPacket({
            pid = "GameActivityShowReward",
            rewards = rewards,
        })
    end
end

local function randomItems(rewardPool)
    local totalWeight = 0
    local item = {}
    for i, v in pairs(rewardPool or {}) do
        totalWeight = totalWeight + v.weight
    end
    if totalWeight < 1 then
        return rewardPool, item
    end

    local randNum = math.random(1, totalWeight)
    local curWeight = 0
    for index, v in pairs(rewardPool or {}) do
        local id = v.id
        local num = v.num
        local weight = v.weight
        curWeight = curWeight + weight
        if curWeight >= randNum then
            item = {
                id = id,
                num = num
            }
            table.remove(rewardPool, index)
            break
        end
    end
    return rewardPool, item
end

---@param player SBasePlayer
function AceMinerMgr:tryGetReward(player, index)
    ---@type AceMinerConfigData
    local config = self.config[index]
    local rewardPool = TableUtil.copyTable(config.rewardPool)
    local count = config.count

    local items = {}
    for _ = 1, count do
        local item
        rewardPool, item = randomItems(rewardPool)
        if item and next(item) then
            table.insert(items, item)
        end
    end

    tryReceive(self, player, items)
end

return AceMinerMgr