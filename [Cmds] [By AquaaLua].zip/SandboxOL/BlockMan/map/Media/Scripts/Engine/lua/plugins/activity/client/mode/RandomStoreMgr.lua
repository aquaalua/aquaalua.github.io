---@type RandomStoreConfig
local RandomStoreConfig = Plugins.Require("activity", "common.config.RandomStoreConfig")

---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")

---@class CRandomStoreMgr : CBaseActivityMgr
local RandomStoreMgr = class("CRandomStoreMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.RandomStore, RandomStoreMgr, RandomStoreConfig)
----------------------------------------------------------------------------------
---@param mgrConfig LevelActivityConfigData
function RandomStoreMgr:initActivity(mgrConfig)
    self.config = mgrConfig
    self.dataCache = {}
end

---@param player SBasePlayer
---@param cache LevelActivityDBData
function RandomStoreMgr:setPlayerCache(player, cache)
    self.dataCache = cache
    if self.cacheCallBack then
        self.cacheCallBack()
    end
end

---@return LevelActivityDBData
function RandomStoreMgr:getPlayerCache()
    return self.dataCache or {
        storeList = {},
        refreshTime = 0
    }
end

-------------------------------------功能相关---------------------------------------------------
function RandomStoreMgr:tryGetReward(rewardId)
    if not self:getPlayerCache().haveBuy then
        return
    end
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "tryGetReward",
        rewardId = rewardId,
    })
end

function RandomStoreMgr:onBuyPrivilege(id)
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        id = id,
        activityId = self.mainConfig.id,
        funcName = "buyGoods"
    })
    return true
end

function RandomStoreMgr:updateLastOpenUIDate()
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "updateLastOpenUIDate"
    })
end

return RandomStoreMgr