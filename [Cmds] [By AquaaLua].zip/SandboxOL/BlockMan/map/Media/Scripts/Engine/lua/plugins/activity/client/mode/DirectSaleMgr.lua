---@type DirectSaleConfig
local DirectSaleConfig = Plugins.Require("activity", "common.config.DirectSaleConfig")

---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")

---@class DirectSaleMgr : CBaseActivityMgr
local DirectSaleMgr = class("CDirectSaleMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.DirectSale, DirectSaleMgr, DirectSaleConfig)
----------------------------------------------------------------------------------
---@param mgrConfig DirectSaleConfigData
function DirectSaleMgr:initActivity(mgrConfig)
    self.config = mgrConfig
end

---@param player SBasePlayer
---@param cache DirectSaleDBData
function DirectSaleMgr:setPlayerCache(player, cache)
    self.dataCache = cache
    if self.cacheCallBack then
        self.cacheCallBack()
    end
end

---@return DirectSaleDBData
function DirectSaleMgr:getPlayerCache()
    return self.dataCache or {
        haveBuy = false,
    }
end

-------------------------------------功能相关---------------------------------------------------

function DirectSaleMgr:onBuyDirectSale()
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "buyDirectSale"
    })
    return true
end

return DirectSaleMgr