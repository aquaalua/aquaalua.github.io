local Settings = {}
local KeyBoardI = {}

local sendMessage = ShellInterface.sendMessage
ShellInterface.sendMessage = function(self, messageType, msgData)
    msgData.senderUserId = tostring(Game:getPlatformUserId())
    sendMessage(self, messageType, json.encode(msgData))
end

function KeyBoardI:init()
    if Platform.isWindow() and CGame.requireKeyboardEvent then
        CGame.Instance():requireKeyboardEvent()
        CEvents.KeyUpEvent:registerCallBack(self.onKeyUp)
        CEvents.KeyUpEvent:registerCallBack(self.onEventHold)
    end
end

function KeyBoardI:OnUpdate()
    local player = PlayerManager:getClientPlayer()
    if player == nil then
        return
    end
    local pos = player.Player:getPosition()
    MsgSender.sendTopTips(
        1,
        string.format(
            "XYZ: %s / %s / %s",
            tostring(math.floor(pos.x)),
            tostring(math.floor(pos.y)),
            tostring(math.floor(pos.z))
        )
    )
end

function KeyBoardI.onKeyUp(keyName, keyCode)
    A = not A
    if keyName == "F" then
        GUIGMControlPanel:show()
        UIHelper.showToast("[ON] Panel")
        if A then
            GUIGMControlPanel:hide()
            UIHelper.showToast("[OFF] Panel")
        end
        return
    end

    if keyName == "M" then
        RootGuiLayout.Instance():showMainControl()
        local moveDir = VectorUtil.newVector3(0.0, 1.35, 0.0)
        local player = PlayerManager:getClientPlayer()
        player.Player:setAllowFlying(true)
        player.Player:setFlying(true)
        player.Player:moveEntity(moveDir)
        return
    end
    local idx = tonumber(keyName)
    return true
end

KeyBoardI:init()
function Game:init()
    GUIManager:getWindowByName("Main-Parachute"):SetVisible(true)
    GUIManager:getWindowByName("Main-Parachute", GUIType.Button):registerEvent(
        GUIEvent.ButtonClick,
        function()
            A = not A
            local player = PlayerManager:getClientPlayer()
            player.Player:setAllowFlying(false)
            player.Player:setFlying(false)
            PlayerManager:getClientPlayer().Player:setSpeedAdditionLevel(100)
            UIHelper.showToast("^00FF00OFF")

            if A then
                local moveDir = VectorUtil.newVector3(0.0, 1.35, 0.0)
                local player = PlayerManager:getClientPlayer()
                player.Player:setAllowFlying(true)
                player.Player:setFlying(true)
                player.Player:moveEntity(moveDir)
                PlayerManager:getClientPlayer().Player:setSpeedAdditionLevel(10000)
                UIHelper.showToast("^00FF00ON")
            end
        end
    )

    GUIManager:getWindowByName("Main-Cannon"):SetVisible(true)
    GUIManager:getWindowByName("Main-Cannon", GUIType.Button):registerEvent(
        GUIEvent.ButtonClick,
        function()
            A = not A
            LuaTimer:cancel(ClickLocal)
            UIHelper.showToast("[OFF] SpamClick")
            
            if A then
                ClickLocal = LuaTimer:scheduleTimer(function()
                    CGame.Instance():handleTouchClick(800, 360)
                    UIHelper.showToast("[ON] SpamClick")
                end, 0.35, -1)
            end
        end
    )

    MsgSender.sendTopTips(999999999e9, "[Developer]".." ".."HacksLua, EternalHacker, Gottya")
    MsgSender.sendOtherTips(999999999e9, "Version: 1.3")

    CGame.Instance():SetMaxFps(999999e9)

    self.CGame = CGame.Instance()
    self.doubleJumpCount = 999999999e9
    self.GameType = CGame.Instance():getGameType()
    self.EnableIndie = CGame.Instance():isEnableIndie(true)
    self.Blockman = Blockman.Instance()
    self.World = Blockman.Instance():getWorld()
    self.LowerDevice = CGame.Instance():isLowerDevice()
    EngineWorld:setWorld(self.World)
end

function Game:isOpenGM()
    return isClient or TableUtil.include(AdminIds, tostring(Game:getPlatformUserId()))
end

local Settings = {}
GMSetting = {}

local function isGMOpen(userId)
    if isClient then
        return true
    end
    return TableUtil.include(AdminIds, tostring(userId))
end

function GMSetting:addTab(tab_name, index)
    for _, setting in pairs(Settings) do
        if setting.name == tab_name then
            setting.items = {}
            return
        end
    end
    index = index or #Settings + 1
    table.insert(Settings, index, {name = tab_name, items = {}})
end

function GMSetting:addItem(tab_name, item_name, func_name, ...)
    local settings
    for _, group in pairs(Settings) do
        if group.name == tab_name then
            settings = group
        end
    end
    if not settings then
        GMSetting:addTab(tab_name)
        GMSetting:addItem(tab_name, item_name, func_name, ...)
        return
    end
    table.insert(settings.items, {name = item_name, func = func_name, params = {...}})
end

function GMSetting:getSettings()
    return Settings
end

GMSetting:addTab("常见的")
GMSetting:addItem("常见的", "StartFlying", "setAllowFlying")
GMSetting:addItem("常见的", "AirCheat", "InTheAirCheat")
GMSetting:addItem("常见的", "ChangeSpeed", "changePlayerSpeed", 1000)
GMSetting:addItem("常见的", "TryStartGame", "tryStartGame")
GMSetting:addItem("常见的", "FindAlivePlayers", "findLifePlayer")
GMSetting:addItem("常见的", "ClearDataQuit", "clearDBAndLogout")
GMSetting:addItem("常见的", "ResetFirstCharge", "resetSumRecharge")
GMSetting:addItem("常见的", "Clear Inventory", "clearInventory")
GMSetting:addItem("常见的", "ShowUserRegion", "showUserRegion")
GMSetting:addItem("常见的", "ErrorLog (Overall)", "addErrorPlayer", true)
GMSetting:addItem("常见的", "ErrorLog (Recently)", "addErrorPlayer", false)
GMSetting:addItem("常见的", "InquireBoolKey", "queryBoolKey")
GMSetting:addItem("常见的", "InquireStringKey", "queryStringKey")
GMSetting:addItem("常见的", "Debug (Open)", "openDebug")
GMSetting:addItem("常见的", "Debug (Open)", "closeDebug")
GMSetting:addItem("常见的", "CPD (Open)", "openCommonPacketDebug")
GMSetting:addItem("常见的", "CPD (Close)", "closeCommonPacketDebug")
GMSetting:addItem("常见的", "DebugLeft", "moveDebugInfo", -5, 0)
GMSetting:addItem("常见的", "DebugRight", "moveDebugInfo", 5, 0)
GMSetting:addItem("常见的", "DebugUp", "moveDebugInfo", 0, -5)
GMSetting:addItem("常见的", "DebugDown", "moveDebugInfo", 0, 5)
GMSetting:addItem("常见的", "WorldTime (6000)", "setWorldTime", 6000)
GMSetting:addItem("常见的", "WorldTime (12000)", "setWorldTime", 12000)
GMSetting:addItem("常见的", "WorldTime (18000)", "setWorldTime", 18000)
GMSetting:addItem("常见的", "WorldTime (24000)", "setWorldTime", 24000)
GMSetting:addItem("常见的", "OpenScreenRec", "openScreenRecord")
GMSetting:addItem("常见的", "Panel (Invis)", "makeGmButtonTran")
GMSetting:addItem("常见的", "LuaHotUpdate (On)", "changeLuaHotUpdate", true)
GMSetting:addItem("常见的", "LuaHotUpdate (Offf)", "changeLuaHotUpdate", false)
GMSetting:addItem("常见的", "EventDialog (On)", "changeOpenEventDialog", true)
GMSetting:addItem("常见的", "EventDialog (Off)", "changeOpenEventDialog", false)
GMSetting:addItem("常见的", "OutputUiName", "setOutputUIName")
GMSetting:addItem("常见的", "GlobalShowText", "setGlobalShowText")
GMSetting:addItem("常见的", "Telnet (Client)", "telnetClient")
GMSetting:addItem("常见的", "Telnet (Server)", "telnetServer")
GMSetting:addItem("常见的", "CopyClientLog", "copyClientLog")

GMSetting:addTab("危险的")
GMSetting:addItem("危险的", "DisableApiGrapics", "DisableGraphicAPI")
GMSetting:addItem("危险的", "DAG & TestCPU", "DisableGraphicAPIAndTestCPU")
GMSetting:addItem("危险的", "DAG & TestGPU", "DisableGraphicAPIAndTestGPU")
GMSetting:addItem("危险的", "DAG & TestDraw", "DisableGraphicAPIAndDrawCallTest")
GMSetting:addItem("危险的", "ShutDownServer", "closeServer")
GMSetting:addItem("危险的", "GMPlayer (On)", "addGMPlayer", true)
GMSetting:addItem("危险的", "GMPlayer (Off)", "addGMPlayer", false)
GMSetting:addItem("危险的", "SpecialEffectsTest", "testinValidEffect", false)
GMSetting:addItem("危险的", "CPUTimer (On)", "setCPUTimerEnabled", true)
GMSetting:addItem("危险的", "CPUTimer (Off)", "setCPUTimerEnabled", false)
GMSetting:addItem("危险的", "GPUTimer (On)", "setGPUTimerEnabled", true)
GMSetting:addItem("危险的", "GPUTimer (Off)", "setGPUTimerEnabled", false)
GMSetting:addItem("危险的", "DrawCallTest", "SetEnabledRenderFrameTimer", true)
GMSetting:addItem("危险的", "PrintCPUTimer", "printCPUTimerResult")
GMSetting:addItem("危险的", "AutoPrintResult", "autoPrintResults")
GMSetting:addItem("危险的", "AutoProfilePerform", "autoProfilePerformance")
GMSetting:addItem("危险的", "UpdateShader", "updateAllShaders")
GMSetting:addItem("危险的", "AutoUpdateShader", "setNeedMonitorShader")
GMSetting:addItem("危险的", "DrawCallDisabled", "setDrawCallDisabled")
GMSetting:addItem("危险的", "MinimumGeometry", "setMinimumGeometry")
GMSetting:addItem("危险的", "ColorBlendDisabled", "setColorBlendDisabled")
GMSetting:addItem("危险的", "ZTestDisabled", "setZTestDisabled")
GMSetting:addItem("危险的", "ZWriteDisabled", "setZWriteDisabled")
GMSetting:addItem("危险的", "UseSmallTexture", "setUseSmallTexture")
GMSetting:addItem("危险的", "UseSmallViewport", "setUseSmallViewport")
GMSetting:addItem("危险的", "UseSmallVBO", "setUseSmallVBO")
GMSetting:addItem("危险的", "ClearColorDisabled", "setClearColorDisabled")
GMSetting:addItem("危险的", "RMSS (On)", "setRenderMainScreenSeparate", true)
GMSetting:addItem("危险的", "RMSS (Off)", "setRenderMainScreenSeparate", false)
GMSetting:addItem("危险的", "MergeBlock (On)", "setEnableMergeBlock", true)
GMSetting:addItem("危险的", "MergeBlock (Off)", "setEnableMergeBlock", false)
GMSetting:addItem("危险的", "AnvilToObj", "AnvilToObj")

GMSetting:addTab("坐标页")
GMSetting:addItem("坐标页", "First Person (x) +0.1", "changeGunFlameParam", "GunFlameFrontOff1", 0.1)
GMSetting:addItem("坐标页", "First Person (x) +0.01", "changeGunFlameParam", "GunFlameFrontOff1", 0.01)
GMSetting:addItem("坐标页", "First Person (x) -0.1", "changeGunFlameParam", "GunFlameFrontOff1", -0.1)
GMSetting:addItem("坐标页", "First Person (x) -0.01", "changeGunFlameParam", "GunFlameFrontOff1", -0.01)
GMSetting:addItem("坐标页", "First Person (y) +0.1", "changeGunFlameParam", "GunFlameRightOff1", 0.1)
GMSetting:addItem("坐标页", "First Person (y) +0.01", "changeGunFlameParam", "GunFlameRightOff1", 0.01)
GMSetting:addItem("坐标页", "First Person (y) -0.1", "changeGunFlameParam", "GunFlameRightOff1", -0.1)
GMSetting:addItem("坐标页", "First Person (y) -0.01", "changeGunFlameParam", "GunFlameRightOff1", -0.01)
GMSetting:addItem("坐标页", "First Person (z) +0.1", "changeGunFlameParam", "GunFlameDownOff1", 0.1)
GMSetting:addItem("坐标页", "First Person (z) +0.01", "changeGunFlameParam", "GunFlameDownOff1", 0.01)
GMSetting:addItem("坐标页", "First Person (z) -0.1", "changeGunFlameParam", "GunFlameDownOff1", -0.1)
GMSetting:addItem("坐标页", "First Person (z) -0.01", "changeGunFlameParam", "GunFlameDownOff1", -0.01)
GMSetting:addItem("坐标页", "First Person (s) +0.1", "changeGunFlameParam", "GunFlameScale1", 0.1)
GMSetting:addItem("坐标页", "First Person (s) +0.01", "changeGunFlameParam", "GunFlameScale1", 0.01)
GMSetting:addItem("坐标页", "First Person (s) -0.1", "changeGunFlameParam", "GunFlameScale1", -0.1)
GMSetting:addItem("坐标页", "First Person (s) -0.01", "changeGunFlameParam", "GunFlameScale1", -0.01)
GMSetting:addItem("坐标页", "ThirdPerson (x) +0.1", "changeGunFlameParam", "GunFlameFrontOff3", 0.1)
GMSetting:addItem("坐标页", "ThirdPerson (x) +0.01", "changeGunFlameParam", "GunFlameFrontOff3", 0.01)
GMSetting:addItem("坐标页", "ThirdPerson (x) -0.1", "changeGunFlameParam", "GunFlameFrontOff3", -0.1)
GMSetting:addItem("坐标页", "ThirdPerson (x) -0.01", "changeGunFlameParam", "GunFlameFrontOff3", -0.01)
GMSetting:addItem("坐标页", "ThirdPerson (y) +0.1", "changeGunFlameParam", "GunFlameRightOff3", 0.1)
GMSetting:addItem("坐标页", "ThirdPerson (y) +0.01", "changeGunFlameParam", "GunFlameRightOff3", 0.01)
GMSetting:addItem("坐标页", "ThirdPerson (y) -0.1", "changeGunFlameParam", "GunFlameRightOff3", -0.1)
GMSetting:addItem("坐标页", "ThirdPerson (y) -0.01", "changeGunFlameParam", "GunFlameRightOff3", -0.01)
GMSetting:addItem("坐标页", "ThirdPerson (z) +0.1", "changeGunFlameParam", "GunFlameDownOff3", 0.1)
GMSetting:addItem("坐标页", "ThirdPerson (z) +0.01", "changeGunFlameParam", "GunFlameDownOff3", 0.01)
GMSetting:addItem("坐标页", "ThirdPerson (z) -0.1", "changeGunFlameParam", "GunFlameDownOff3", -0.1)
GMSetting:addItem("坐标页", "ThirdPerson (z) -0.01", "changeGunFlameParam", "GunFlameDownOff3", -0.01)
GMSetting:addItem("坐标页", "ThirdPerson (s) +0.1", "changeGunFlameParam", "GunFlameScale3", 0.1)
GMSetting:addItem("坐标页", "ThirdPerson (s) +0.01", "changeGunFlameParam", "GunFlameScale3", 0.01)
GMSetting:addItem("坐标页", "ThirdPerson (s) -0.1", "changeGunFlameParam", "GunFlameScale3", -0.1)
GMSetting:addItem("坐标页", "ThirdPerson (s) -0.01", "changeGunFlameParam", "GunFlameScale3", -0.01)
GMSetting:addItem("坐标页", "GFCoordinate (On)", "setShowGunFlameCoordinate", true)
GMSetting:addItem("坐标页", "GFCoordinate (Off)", "setShowGunFlameCoordinate", false)
GMSetting:addItem("坐标页", "CopyFirstPerson", "copyShowGunFlameParam", 1)

GMSetting:addTab("Hacks", 1)
GMSetting:addItem("Hacks", "UP", "inTheAirCheat")
GMSetting:addItem("Hacks", "Fly", "NormalFly")
GMSetting:addItem("Hacks", "Blink", "BlinkOP")
GMSetting:addItem("Hacks", "Reach", "Reach")
GMSetting:addItem("Hacks", "Tracer", "Tracer")
GMSetting:addItem("Hacks", "Scaffold", "Scaffold")
GMSetting:addItem("Hacks", "Freecam", "Freecam")
GMSetting:addItem("Hacks", "Respawn", "RespawnNew")
GMSetting:addItem("Hacks", "Speed X2", "SpeedManager", 1000)
GMSetting:addItem("Hacks", "Speed X3", "SpeedManager", 2000)
GMSetting:addItem("Hacks", "Speed X4", "SpeedManager", 3000)
GMSetting:addItem("Hacks", "Speed Up", "SpeedUp")
GMSetting:addItem("Hacks", "Wall Hack", "Noclip")
GMSetting:addItem("Hacks", "Fast Break", "DestroyQuick")
GMSetting:addItem("Hacks", "QuickHacks", "QuickHacks")
GMSetting:addItem("Hacks", "Sharp Flying", "SharpFly")
GMSetting:addItem("Hacks", "CustomSpeed", "SpeedManagerSet")
GMSetting:addItem("Hacks", "SpamRespawn", "RespawnSpam")
GMSetting:addItem("Hacks", "TeleportNearest", "TeleportNear")
GMSetting:addItem("Hacks", "Parachute Mode", "FlyParachute")
GMSetting:addItem("Hacks", "Quick Place (Set)", "QuickBlock")
GMSetting:addItem("Hacks", "Block Reach (Set)", "BlockReachSet")
GMSetting:addItem("Hacks", "Attack Reach (Set)", "ReachSet")
GMSetting:addItem("Hacks", "Fast Screen Rotate", "AfkMode")
GMSetting:addItem("Hacks", "TH Reset", "MineReset")
GMSetting:addItem("Hacks", "TH Noclip", "THNoClip")

GMSetting:addTab("Wings", 2)
GMSetting:addItem("Wings", "Lv1", "equipWings", "154")
GMSetting:addItem("Wings", "Lv2", "equipWings", "155")
GMSetting:addItem("Wings", "Lv3", "equipWings", "156")
GMSetting:addItem("Wings", "Lv4", "equipWings", "157")
GMSetting:addItem("Wings", "Lv5", "equipWings", "158")
GMSetting:addItem("Wings", "Lv6", "equipWings", "159")
GMSetting:addItem("Wings", "Vip8", "equipWings", "114")
GMSetting:addItem("Wings", "Vip9", "equipWings", "115")
GMSetting:addItem("Wings", "Vip10", "equipWings", "116")
GMSetting:addItem("Wings", "Vip10+", "equipWings", "117")
GMSetting:addItem("Wings", "RealmCity1", "equipWings", "17")
GMSetting:addItem("Wings", "RealmCity2", "equipWings", "18")
GMSetting:addItem("Wings", "RealmCity3", "equipWings", "19")
GMSetting:addItem("Wings", "RealmCity4", "equipWings", "26")
GMSetting:addItem("Wings", "RealmCity5", "equipWings", "27")
GMSetting:addItem("Wings", "Dark", "equipWings", "13")
GMSetting:addItem("Wings", "Angel", "equipWings", "1")
GMSetting:addItem("Wings", "Yellow", "equipWings", "62")
GMSetting:addItem("Wings", "Feather", "equipWings", "42")
GMSetting:addItem("Wings", "Vampire", "equipWings", "60")
GMSetting:addItem("Wings", "BlueMetal", "equipWings", "24")
GMSetting:addItem("Wings", "YellowMetal", "equipWings", "20")
GMSetting:addItem("Wings", "RainbowBalls", "equipWings", "44")

GMSetting:addTab("Spawn", 3)
GMSetting:addItem("Spawn", "SpawnCar", "spawnCar")
GMSetting:addItem("Spawn", "SpawnNpc", "SpawnNPC")
GMSetting:addItem("Spawn", "SpawnItem", "SpawnItem")
GMSetting:addItem("Spawn", "SpawnBlock", "SpawnBlock")

GMSetting:addTab("Render", 4)
GMSetting:addItem("Render", "Day", "ChangeTime", false)
GMSetting:addItem("Render", "Night", "ChangeTime", true)
GMSetting:addItem("Render", "SpYaw", "SpYaw")
GMSetting:addItem("Render", "SetYaw", "setYaw")
GMSetting:addItem("Render", "OffDark", "OFFDARK")
GMSetting:addItem("Render", "SetTime", "SetTime")
GMSetting:addItem("Render", "SpYawSet", "SpYawSet")
GMSetting:addItem("Render", "CloudsStop", "CloudsOFF", true)
GMSetting:addItem("Render", "BreakParticle", "BreakParticles")
GMSetting:addItem("Render", "SetBlockToAir", "SetBlockToAir")
GMSetting:addItem("Render", "SetRenderWorld", "RenderWorld")
GMSetting:addItem("Render", "Start/Stop Cycle", "StartTime")

GMSetting:addTab("Change", 5)
GMSetting:addItem("Change", "Change Hair", "ChangeHair")
GMSetting:addItem("Change", "Change Nick", "ChangeNick")
GMSetting:addItem("Change", "Change Face", "ChangeFace")
GMSetting:addItem("Change", "Change Tops", "ChangeTops")
GMSetting:addItem("Change", "Change Wing", "ChangeWing")
GMSetting:addItem("Change", "Change Scarf", "ChangeScarf")
GMSetting:addItem("Change", "Change Scale", "changeScale")
GMSetting:addItem("Change", "Change Pants", "ChangePants")
GMSetting:addItem("Change", "Change Shoes", "ChangeShoes")
GMSetting:addItem("Change", "Change Actor1", "changePlayerActor", 1)
GMSetting:addItem("Change", "Change Actor2", "changePlayerActor", 2)
GMSetting:addItem("Change", "Change Glasses", "ChangeGlasses")

GMSetting:addTab("Interface", 6)
GMSetting:addItem("Interface", "FOG", "Fog")
GMSetting:addItem("Interface", "OpenUI", "GUIOpener")
GMSetting:addItem("Interface", "Camera", "CameraFunct")
GMSetting:addItem("Interface", "Bobbing", "SetBobbing")
GMSetting:addItem("Interface", "Interface", "PersonView")
GMSetting:addItem("Interface", "InsideGUI", "InsideGUI")
GMSetting:addItem("Interface", "FlipCamera", "CameraFlipModeON")
GMSetting:addItem("Interface", "SetAplhaGUI", "SetAlpha")
GMSetting:addItem("Interface", "InterfaceOFF", "GUIViewOFF")
GMSetting:addItem("Interface", "FlipCameraReset", "CameraFlipModeRESET")

GMSetting:addTab("Developers", 7)
GMSetting:addItem("Developers", "Dev Fly", "DeveloperFLY")
GMSetting:addItem("Developers", "Dev Noclip", "DevnoClip")

GMSetting:addTab("Movements", 8)
GMSetting:addItem("Movements", "Arm Speed", "ArmSpeed")
GMSetting:addItem("Movements", "Bow Speed", "BowSpeed")
GMSetting:addItem("Movements", "Spam Click", "AutoClick")
GMSetting:addItem("Movements", "Fight Mode", "FightMode")
GMSetting:addItem("Movements", "Water Push", "WaterPush")
GMSetting:addItem("Movements", "Seperate Cam", "SeperateCamera")
GMSetting:addItem("Movements", "Remove Click CD", "BanClickCD")
GMSetting:addItem("Movements", "Remove Click CD (BW)", "BWBanClickCD")

GMSettings:addTab("Miscellaneous", 9)
GMSetting:addItem("Miscellaneous", "(JB) Bypass", "JailBreakBypass")
GMSetting:addItem("Miscellaneous", "(Bw) Bypass V1", "BW")
GMSetting:addItem("Miscellaneous", "(Bw) Bypass V2", "BWV2")
GMSetting:addItem("Miscellaneous", "Show/Hide Armor", "SetHideAndShowArmor")
GMSetting:addItem("Miscellaneous", "testl999", "SetHitbox")

GMSetting:addTab("游戏道具")

function GMSetting:addItemGMItems()
    GMSetting:addItem("游戏道具", "DesignatedTools", "addInputItem")
    GMSetting:addItem("游戏道具", "ToolsChineseTable", "outputItemLangFile")
    for id = 6000, 1, -1 do
        local item = Item.getItemById(id)
        if item then
            local lang = Lang:getItemName(id, 0)
            if lang == "ru" then
                lang = item:getUnlocalizedName()
            end
            lang = tostring(id) .. "-" .. lang
            GMSetting:addItem("游戏道具", lang, "addItem", id)
        end
    end
    GMSetting:addItem("游戏道具", "", "")
    GMSetting:addItem("游戏道具", "", "")
end

GMSetting:addTab("平台装饰")

local dress_master = {
    "custom_hair",
    "custom_face",
    "clothes_tops",
    "clothes_pants",
    "custom_shoes",
    "custom_glasses",
    "custom_scarf",
    "custom_wing",
    "custom_hat",
    "custom_decorate_hat",
    "custom_hand",
    "custom_tail",
    "custom_wing_flag",
    "custom_foot_halo",
    "custom_back_effect",
    "custom_crown",
    "custom_head_effect",
    "custom_bag",
    "custom_privilege",
    "custom_suits"
}

for pos, master in pairs(dress_master) do
    GMSetting:addItem("平台装饰", master .. "Cloth (C)", "changeCloth", master)
    GMSetting:addItem("平台装饰", master .. "Cloth (R)", "resetCloth", master)
    if pos % 2 == 0 then
        GMSetting:addItem("平台装饰", "", "")
    end
end

GMSetting:addTab("连接器")
GMSetting:addItem("连接器", "ConnectorLog (On)", "openConnectorLog")
GMSetting:addItem("连接器", "ConnectorLog (On)", "closeConnectorLog")
GMSetting:addItem("连接器", "TestConnector", "testUpdateConnector")
GMSetting:addItem("连接器", "TCM 10005", "sendTestConnectorMsg", 10005)
GMSetting:addItem("连接器", "TCM 20000", "sendTestConnectorMsg", 20000)
GMSetting:addItem("连接器", "TCM 1000", "sendConnectorChatMsg", 1000)

GMHelper = {}

function GMHelper:enableGM()
    if GUIGMControlPanel then
        return
    end

    GUIGMControlPanel = UIHelper.newEngineGUILayout("GUIGMControlPanel", "GMControlPanel.json")
    GUIGMControlPanel:hide()
    GUIGMMain = UIHelper.newEngineGUILayout("GUIGMMain", "GMMain.json")
    GUIGMMain:show()
    
    local isOpenEventDialog = ClientHelper.getBoolForKey("g1008_isOpenEventDialog", false)
    GUIGMMain:changeOpenEventDialog(isOpenEventDialog)
    if GMSetting.addItemGMItems then
        GMSetting:addItemGMItems()
        GMSetting.addItemGMItems = nil
    end
end

function GMHelper:openInput(paramTexts, callBack)
    if type(paramTexts) ~= "table" then
        return
    end
    for _, paramText in pairs(paramTexts) do
        if type(paramText) ~= "string" then
            if isClient then
                assert(true, "param need string type")
            end
            return
        end
    end
    GUIGMControlPanel:openInput(paramTexts, callBack)
end

function GMHelper:callCommand(name, ...)
    local func = self[name]
    if type(func) == "function" then
        func(self, ...)
    end
    local data = {name = name, params = {...}}
    table.remove(data.params)
    PacketSender:sendLuaCommonData("GMCommand", json.encode(data))
end

function GMHelper:openDebug()
    CGame.Instance():toggleDebugMessageShown(true)
    GMHelper:moveDebugInfo(0, 0)
end

function GMHelper:closeDebug()
    CGame.Instance():toggleDebugMessageShown(false)
end

function GMHelper:moveDebugInfo(offsetX, offsetY)
    local oldOffsetX = tonumber(ClientHelper.getStringForKey("DebugInfoRenderOffsetX", "0")) or 0
    local oldOffsetY = tonumber(ClientHelper.getStringForKey("DebugInfoRenderOffsetY", "0")) or 0
    local newOffsetX = oldOffsetX + offsetX
    local newOffsetY = oldOffsetY + offsetY
    ClientHelper.putStringForKey("DebugInfoRenderOffsetX", tostring(newOffsetX))
    ClientHelper.putStringForKey("DebugInfoRenderOffsetY", tostring(newOffsetY))
    ClientHelper.putFloatPrefs("DebugInfoRenderOffsetX", newOffsetX)
    ClientHelper.putFloatPrefs("DebugInfoRenderOffsetY", newOffsetY)
end

function GMHelper:setCPUTimerEnabled(value)
    GUIGMControlPanel:hide()
    PerformanceStatistics.SetCPUTimerEnabled(value)
end

function GMHelper:setGPUTimerEnabled(value)
    GUIGMControlPanel:hide()
    PerformanceStatistics.SetGPUTimerEnabled(value)
end

function GMHelper:printCPUTimerResult()
    GUIGMControlPanel:hide()
    PerformanceStatistics.PrintResults(20)
end

function GMHelper:openChatWin()
    UIHelper.showGameGUILayout("GUILuaChat", Define.ChatTabType.SameServer)
end

function GMHelper:showChatRecord(chatId)
    ChatClient:getPrivateMsgCache(
        chatId,
        nil,
        function(chatMsgList)
            LogUtil.pv(chatMsgList)
        end
    )
end

function GMHelper:autoPrintResults()
    GUIGMControlPanel:hide()
    LuaTimer:schedule(
        function()
            PerformanceStatistics.PrintResults(20)
        end,
        5000
    )
end

function GMHelper:autoProfilePerformance()
    GUIGMControlPanel:hide()
    LuaTimer:schedule(
        function()
            PerformanceStatistics.ProfilePerformance(20)
        end,
        100
    )

    GMHelper:showInput(
        {
            "exp",
            "exp2"
        },
        function(exp, exp2)
        end
    )
end

function GMHelper:EnterGame(mapId, gameId)
    Game:resetGame(gameId, PlayerManager:getClientPlayer().userId, mapId)
end

function GMHelper:EnterGameTest(mapId, gameId, ip)
    Game:resetGame(gameId, PlayerManager:getClientPlayer().userId)
end

function GMHelper:SetPlayerScale2()
    PlayerManager:getClientPlayer().Player.SetPlayerScale = 5
end

function GMHelper:setYaw(yawNum, Sub)
    if Sub then
        PlayerManager:getClientPlayer().Player.rotationYaw = PlayerManager:getClientPlayer().Player.rotationYaw - yawNum
        return
    end
    PlayerManager:getClientPlayer().Player.rotationYaw = PlayerManager:getClientPlayer().Player.rotationYaw + yawNum
end

function GMHelper:setYaw()
    GMHelper:openInput(
        {""},
        function(Number)
            PlayerManager:getClientPlayer().Player.rotationYaw = Number
            UIHelper.showToast("^00FF00Changed")
        end
    )
end

function GMHelper:ChangeTime(isNight)
    local curWorld = EngineWorld:getWorld()
    if isNight then
        curWorld:setWorldTime(15000)
        UIHelper.showToast("^00FF00Now Night!")
        return
    end
    curWorld:setWorldTime(6000)
    UIHelper.showToast("^00FF00Now Day!")
end

function GMHelper:SetTime()
    GMHelper:openInput(
        {""},
        function(Number)
            local curWorld = EngineWorld:getWorld()
            curWorld:setWorldTime(Number)
            UIHelper.showToast("^00FF00Changed")
        end
    )
end

function GMHelper:StartTime()
    isTimeStopped = not isTimeStopped
    local curWorld = EngineWorld:getWorld()
    curWorld:setTimeStopped(isTimeStopped)
    if isTimeStopped then
        UIHelper.showToast("^FF0000Start/Stop Time: disabled!")
        return
    end
    UIHelper.showToast("^00FF00Start/Stop Time: enabled!")
end

function GMHelper:getConfig()
    MsgSender.sendMsg("Time:" .. tostring(ModsConfig.time))
    MsgSender.sendMsg("Show pos:" .. tostring(ModsConfig.showPos))
    MsgSender.sendMsg("Hp warn:" .. tostring(ModsConfig.lhwarn))
    MsgSender.sendMsg("Hp warn level:" .. tostring(ModsConfig.hpwarn))
    MsgSender.sendMsg("Hide player names:" .. tostring(ModsConfig.hpn))
end

function GMHelper:HidePlayerName()
    isHideNames = not isHideNames
    if isHideNames then
        ModsConfig.hpn = 1
        MsgSender.sendMsg("Hide players name: enabled!")
        return
    end
    if not isHideNames then
        ModsConfig.hpn = 0
        MsgSender.sendMsg("Hide players name: disabled!")
    end
end

function GMHelper:ShowPos()
    isShowPos = not isShowPos
    if isShowPos then
        ModsConfig.showPos = 1
        MsgSender.sendMsg("Show player position: enabled!")
        return
    end
    ModsConfig.showPos = 0
    MsgSender.sendMsg("Show player position: disabled!")
end

function GMHelper:EnableHPWarn()
    useHPWarn = not useHPWarn
    if useHPWarn then
        ModsConfig.lhwarn = 1
        MsgSender.sendMsg("HP Warning: enabled!")
        return
    end
    ModsConfig.lhwarn = 0
    MsgSender.sendMsg("HP Warning: disabled!")
end

function GMHelper:addHpLvl(amount, sub)
    if sub then
        if ModsConfig.hpwarn == 0 then
            return
        end
        ModsConfig.hpwarn = ModsConfig.hpwarn - 1
        MsgSender.sendMsg("Hp warn level:" .. tostring(ModsConfig.hpwarn))
        return
    end
    if ModsConfig.hpwarn == PlayerManager:getClientPlayer().Player:getHealth() then
        return
    end
    ModsConfig.hpwarn = ModsConfig.hpwarn + 1
    MsgSender.sendMsg("Hp warn level:" .. tostring(ModsConfig.hpwarn))
end

function GMHelper:addGMPlayer(player, isAllPlayer)
    if not isClient then
        return
    end
    if isAllPlayer then
        for _, c_player in pairs(PlayerManager:getPlayers()) do
            c_player:sendPacket({pid = "openGMHelper"})
            table.insert(GmIds, c_player.userId)
        end
    else
        local players = PlayerManager:getPlayers()
        local minDis = 99999999

        local nearestPlayer
        for _, c_player in pairs(players) do
            local distance = MathUtil:distanceSquare3d(c_player:getPosition(), player:getPosition())
            if minDis > distance and c_player ~= player then
                minDis = distance
                nearestPlayer = c_player
            end
        end
        if nearestPlayer and not PlayerManager:isAIPlayer(nearestPlayer) then
            nearestPlayer:sendPacket({pid = "openGMHelper"})
            table.insert(GmIds, nearestPlayer.userId)
        end
    end
    GUIGMControlPanel:hide()
end

function GMHelper:openCommonPacketDebug()
    CommonDataEvents.isDebug = true
end

function GMHelper:closeCommonPacketDebug()
    CommonDataEvents.isDebug = false
end

function GMHelper:openConnectorLog()
    local ConnectorCenter = T(Global, "ConnectorCenter")
    ConnectorCenter.isDebug = true

    local ConnectorDispatch = T(Global, "ConnectorDispatch")
    ConnectorDispatch.isDebug = true
end

function GMHelper:closeConnectorLog()
    local ConnectorCenter = T(Global, "ConnectorCenter")
    ConnectorCenter.isDebug = false

    local ConnectorDispatch = T(Global, "ConnectorDispatch")
    ConnectorDispatch.isDebug = false
end

function GMHelper:sendTestConnectorMsg(type)
    local data = {}
    data.a = 1
    data.b = 2

    local ConnectorCenter = T(Global, "ConnectorCenter")
    ConnectorCenter:sendMsg(type, data)
end

function GMHelper:SetEnabledRenderFrameTimer(value)
    PerformanceStatistics.SetEnabledRenderFrameTimer(value)
    GUIGMControlPanel:hide()
end

function GMHelper:updateAllShaders()
    Blockman.Instance().m_gameSettings:updateAllShaders()
    GUIGMControlPanel:hide()
end

function GMHelper:setNeedMonitorShader()
    Blockman.Instance().m_gameSettings:setNeedMonitorShader(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setDrawCallDisabled()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setDrawCallDisabled(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setMinimumGeometry()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setMinimumGeometry(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setColorBlendDisabled()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setColorBlendDisabled(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setZTestDisabled()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setZTestDisabled(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setZWriteDisabled()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setZWriteDisabled(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setUseSmallTexture()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setUseSmallTexture(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setUseSmallViewport()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setUseSmallViewport(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setUseSmallVBO()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setUseSmallVBO(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setClearColorDisabled()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setClearColorDisabled(true)
    GUIGMControlPanel:hide()
end

function GMHelper:DisableGraphicAPI()
    Blockman.disableGraphicAPI()
end

function GMHelper:DisableGraphicAPIAndTestCPU()
    GUIGMControlPanel:hide()
    LuaTimer:schedule(
        function()
            Blockman.disableGraphicAPI()
            PerformanceStatistics.SetCPUTimerEnabled(true)
            PerformanceStatistics.SetGPUTimerEnabled(false)
            LuaTimer:schedule(
                function()
                    PerformanceStatistics.PrintResults(30)
                end,
                5100
            )
        end,
        200
    )
end

function GMHelper:DisableGraphicAPIAndTestGPU()
    GUIGMControlPanel:hide()
    LuaTimer:schedule(
        function()
            Blockman.disableGraphicAPI()
            PerformanceStatistics.SetCPUTimerEnabled(false)
            PerformanceStatistics.SetGPUTimerEnabled(true)
            LuaTimer:schedule(
                function()
                    PerformanceStatistics.PrintResults(30)
                end,
                5100
            )
        end,
        200
    )
end

function GMHelper:DisableGraphicAPIAndDrawCallTest()
    GUIGMControlPanel:hide()
    LuaTimer:schedule(
        function()
            Blockman.disableGraphicAPI()
            PerformanceStatistics.SetEnabledRenderFrameTimer(true)
        end,
        200
    )
end

function GMHelper:openScreenRecord()
    local names = {"Main-PoleControl-Move", "Main-PoleControl", "Main-FlyingControls", "Main-Fly"}
    local window = GUISystem.Instance():GetRootWindow()
    window:SetXPosition({0, 10000})
    local Main = GUIManager:getWindowByName("Main")
    local count = Main:GetChildCount()
    for i = 1, count do
        local child = Main:GetChildByIndex(i - 1)
        local name = child:GetName()
        if not TableUtil.tableContain(names, name) then
            child:SetXPosition({0, 10000})
            child:SetYPosition({0, 10000})
        end
    end
    ClientHelper.putFloatPrefs("MainControlKeyAlphaNormal", 0)
    ClientHelper.putFloatPrefs("MainControlKeyAlphaPress", 0)
    GUIManager:getWindowByName("Main-Fly"):SetProperty("NormalImage", "")
    GUIManager:getWindowByName("Main-Fly"):SetProperty("PushedImage", "")
    GUIManager:getWindowByName("Main-PoleControl-BG"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-PoleControl-Center"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-Up"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-Drop"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-Down"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-Break-Block-Progress-Nor"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-Break-Block-Progress-Pre"):SetProperty("ImageName", "")
    Main:SetXPosition({0, -10000})
    ClientHelper.putBoolPrefs("RenderHeadText", false)
    PlayerManager:getClientPlayer().Player:setActorInvisible(true)
end

function GMHelper:changeLuaHotUpdate(update)
    startLuaHotUpdate()
    HU.CanUpdate = update
end

function GMHelper:changeOpenEventDialog(isOpen)
    GUIGMMain:changeOpenEventDialog(isOpen)
end

function GMHelper:showUserRegion()
    UIHelper.showToast("GameID = " .. Game:getRegionId() .. ", Player = " .. Game:getUserRegion())
end

function GMHelper:setOutputUIName(text)
    GUISystem.Instance():SetOutputUIName(not GUISystem.Instance():IsOutputUIName())
    text:SetText("打印UI(" .. (GUISystem.Instance():IsOutputUIName() and "开)" or "关)"))
end

function GMHelper:telnetClient()
    if not Platform.isWindow() then
        return
    end
    local misc = require("misc")
    local debugport = require "engine_base.debug.DebugPort"
    misc.win_exec("telnet.exe", "127.0.0.1 " .. debugport.port, nil, nil, true)
end

function GMHelper:telnetServer()
    if not Platform.isWindow() then
        return
    end
    local misc = require("misc")
    local debugport = require "engine_base.debug.DebugPort"
    misc.win_exec("telnet.exe", "127.0.0.1 " .. debugport.port, 1, 1, true)
end

function GMHelper:setGlobalShowText()
    Root.Instance():setShowText(not Root.Instance():isShowText())
end

function GMHelper:copyClientLog()
    if Platform.isWindow() then
        return
    end
    local path = Root.Instance():getWriteablePath() .. "client.log"
    local file = io.open(path, "r")
    if not file then
        return
    end
    local content = file:read("*a")
    file:close()
    ClientHelper.onSetClipboard(content)
    UIHelper.showToast("Successfully copy!")
end

function GMHelper:sendConnectorChatMsg(msgCount)
    if isClient or isStaging then
        local ChatService = T(Global, "ChatService")
        for i = 1, msgCount do
            ChatService:sendMsgToLangGroup(Define.ChatMsgType.TextMsg, {content = "Test:" .. i})
        end
    end
end

function GMHelper:queryBoolKey()
    GMHelper:openInput(
        {""},
        function(key)
            CustomDialog.builder().setContentText(key .. "=" .. tostring(ClientHelper.getBoolForKey(key))).setHideLeftButton(

            ).show()
            GUIGMControlPanel:hide()
        end
    )
end

function GMHelper:queryStringKey()
    GMHelper:openInput(
        {""},
        function(key)
            CustomDialog.builder().setContentText(key .. "=" .. ClientHelper.getStringForKey(key)).setHideLeftButton().setRightText(
                "复制到粘贴板"
            ).setRightClickListener(
                function()
                    ClientHelper.onSetClipboard(ClientHelper.getStringForKey(key))
                    UIHelper.showToast("Successfully copy!")
                end
            ).show()
            GUIGMControlPanel:hide()
        end
    )
end

function GMHelper:makeGmButtonTran()
    GUIGMMain:setTransparent()
end

function GMHelper:setRenderMainScreenSeparate(enable)
    Root.Instance():setRenderMainScreenSeparate(enable)
end

function GMHelper:setEnableMergeBlock(enable)
    Root.Instance():setEnableMergeBlock(true)
    UIHelper.showToast("1")
end

function GMHelper:AnvilToObj()
    local centerPos = VectorUtil.newVector3()
    local chunkWidth = 32
    AnvilToObj.doTranslate(centerPos, chunkWidth)
end

function GMHelper:inTheAirCheat()
    LuaTimer:scheduleTimer(
        function()
            local moveDir = VectorUtil.newVector3(0.0, 3.0, 0.0)
            PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
        end,
        5,
        20
    )
end

function GMHelper:GoTO10BlocksDown()
    LuaTimer:scheduleTimer(
        function()
            local moveDir = VectorUtil.newVector3(0.0, 0.0, 1.0)
            PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
        end,
        5,
        20
    )
end

function GMHelper:GoTO10Blocks()
    LuaTimer:scheduleTimer(
        function()
            local moveDir = VectorUtil.newVector3(1.0, 0.0, 0.0)
            PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
        end,
        5,
        20
    )
end

function GMHelper:testModiyScript()
    ClientHttpRequest.reportScriptModifyCheat()
end

function GMHelper:setShowGunFlameCoordinate(isOpen)
    Blockman.Instance():setShowGunFlameCoordinate(isOpen)
    if isOpen then
        GUIGMControlPanel:setBackgroundColor(Color.TRANS)
    else
        GUIGMControlPanel:setBackgroundColor({0, 0, 0, 0.784314})
    end
end

function GMHelper:changeGunFlameParam(key, value)
    ClientHelper.putFloatPrefs(key, ClientHelper.getFloatPrefs(key) + value)
end

function GMHelper:copyShowGunFlameParam(view)
    local front = ClientHelper.getFloatPrefs("GunFlameFrontOff" .. view)
    local right = ClientHelper.getFloatPrefs("GunFlameRightOff" .. view)
    local down = ClientHelper.getFloatPrefs("GunFlameDownOff" .. view)
    local scale = ClientHelper.getFloatPrefs("GunFlameScale" .. view)
    front = math.floor(front * 100) / 100
    right = math.floor(right * 100) / 100
    down = math.floor(down * 100) / 100
    scale = math.floor(scale * 100) / 100
    local param = front .. "#" .. right .. "#" .. down .. "#" .. scale
    ClientHelper.onSetClipboard(param)
    UIHelper.showToast("Successfully copy!")
end

function GMHelper:testinValidEffect()
    local templateName = "01_face_boy.mesh"
    local position = VectorUtil.newVector3(100.0, 10.0, 100.0)
    WorldEffectManager.Instance():addSimpleEffect(templateName, position, 1, 1, 1, 1, 1)
    UIHelper.showToast("Success")
end

function GMHelper:outputItemLangFile()
    if not isClient then
        return
    end
    local items = {}
    for id = 1, 6000 do
        local item = Item.getItemById(id)
        if item then
            local lang = Lang:getItemName(id, 0)
            if lang == "" then
                lang = item:getUnlocalizedName()
            end
            items[tostring(id)] = lang
        end
    end
    local file = io.open(GameType .. "_item_name.json", "w")
    file:write(json.encode(items))
    file:close()
end

function GMHelper:NormalFly(text)
    A = not A
    ClientHelper.putBoolPrefs("EnableDoubleJumps", true)
    PlayerManager:getClientPlayer().doubleJumpCount = 999999999e9
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    ClientHelper.putBoolPrefs("EnableDoubleJumps", false)
    PlayerManager:getClientPlayer().doubleJumpCount = 0
    UIHelper.showToast("[OFF]")
end

function GMHelper:Reach()
    A = not A
    ClientHelper.putFloatPrefs("BlockReachDistance", 999999999e9)
    ClientHelper.putFloatPrefs("EntityReachDistance", 7)
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    ClientHelper.putFloatPrefs("BlockReachDistance", 6.5)
    ClientHelper.putFloatPrefs("EntityReachDistance", 5)
    UIHelper.showToast("[OFF]")
end

function GMHelper:ViewBobbing()
    A = not A
    ClientHelper.putBoolPrefs("IsViewBobbing", false)
    if A then
        UIHelper.showToast("[OFF]")
        return
    end
    ClientHelper.putBoolPrefs("IsViewBobbing", true)
    UIHelper.showToast("[ON]")
end

function GMHelper:BlockmanCollision()
    A = not A
    ClientHelper.putBoolPrefs("IsCreatureCollision", true)
    ClientHelper.putBoolPrefs("IsBlockmanCollision", true)
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    ClientHelper.putBoolPrefs("IsBlockmanCollision", false)
    UIHelper.showToast("[OFF]")
    ClientHelper.putBoolPrefs("IsCreatureCollision", false)
end

function GMHelper:RenderWorld()
    GMHelper:openInput(
        {""},
        function(Number)
            ClientHelper.putIntPrefs("BlockRenderDistance", Number)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:Fog()
    A = not A
    ClientHelper.putBoolPrefs("DisableFog", true)
    if A then
        UIHelper.showToast("[OFF]")
        return
    end
    ClientHelper.putBoolPrefs("DisableFog", false)
    UIHelper.showToast("[ON]")
end

function GMHelper:SeperateCamera()
    A = not A
    ClientHelper.putBoolPrefs("IsSeparateCamera", true)
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    ClientHelper.putBoolPrefs("IsSeparateCamera", false)
    UIHelper.showToast("[ON]")
end

function GMHelper:QuickBlock()
    GMHelper:openInput(
        {""},
        function(Number)
            ClientHelper.putIntPrefs("QuicklyBuildBlockNum", Number)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:ArmSpeed()
    GMHelper:openInput(
        {""},
        function(Number)
            ClientHelper.putIntPrefs("ArmSwingAnimationEnd", Number)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:CameraFunct()
    GMHelper:openInput(
        {""},
        function(Number)
            ClientHelper.putFloatPrefs("ThirdPersonDistance", Number)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:CloudsOFF()
    ClientHelper.putBoolPrefs("DisableRenderClouds", true)
    UIHelper.showToast("Success")
    GUIGMControlPanel:hide()
end

function GMHelper:BowSpeed()
    ClientHelper.putFloatPrefs("BowPullingSpeedMultiplier", 1000)
    ClientHelper.putFloatPrefs("BowPullingFOVMultiplier", 0)
    UIHelper.showToast("Success")
    GUIGMControlPanel:hide()
end

function GMHelper:Paracute()
    PlayerManager:getClientPlayer().Player:startParachute()
end

function GMHelper:HeadText()
    A = not A
    ClientHelper.putBoolPrefs("RenderHeadText", true)
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    ClientHelper.putBoolPrefs("RenderHeadText", false)
    UIHelper.showToast("[OFF]")
end

function GMHelper:changePlayerActor(vals)
    if isGameStart then
        if vals == 1 then
            ClientHelper.putStringPrefs("BoyActorName", "boy.actor")
            ClientHelper.putStringPrefs("GirlActorName", "boy.actor")
        else
            ClientHelper.putStringPrefs("BoyActorName", "girl.actor")
            ClientHelper.putStringPrefs("GirlActorName", "girl.actor")
        end
    else
        if vals == 1 then
            ClientHelper.putStringPrefs("BoyActorName", "boy.actor")
            ClientHelper.putStringPrefs("GirlActorName", "boy.actor")
        else
            ClientHelper.putStringPrefs("BoyActorName", "girl.actor")
            ClientHelper.putStringPrefs("GirlActorName", "girl.actor")
        end
    end
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        if player.Player then
            player.Player.m_isPeopleActor = false
            EngineWorld:restorePlayerActor(player)
        end
    end
    UIHelper.showToast("Success")
    GUIGMControlPanel:hide()
end

function GMHelper:BanClickCD()
    A = not A
    ClientHelper.putBoolPrefs("banClickCD", true)
    UIHelper.showToast("[ON]")
    if A then
        ClientHelper.putBoolPrefs("banClickCD", false)
        UIHelper.showToast("[OFF]")
    end
end

function GMHelper:BWBanClickCD()
   PlayerManager:getClientPlayer().Player:setIntProperty("bedWarAttackCD", 0)
   ClientHelper.putBoolPrefs("banClickCD", true)
end

function GMHelper:ShowAllCobtrolXD()
    RootGuiLayout.Instance():showMainControl()
end

function GMHelper:PersonView()
    GMHelper:openInput(
        {""},
        function(Number)
            Blockman.Instance():setPersonView(Number)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:BreakParticles()
    GMHelper:openInput(
        {""},
        function(Number)
            ClientHelper.putIntPrefs("BlockDestroyEffectSize", Number)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:JailBreakBypass()
    RootGuiLayout.Instance():showMainControl()
    GUIGMControlPanel:hide()
end

function GMHelper:SpeedLineMode()
    local strength = 1
    local interval = 0.01
    Blockman.Instance().m_gameSettings:setPatternSpeedLine(strength, interval)
    UIHelper.showToast("[ON]")
    GUIGMControlPanel:hide()
end

function GMHelper:SpeedLineModeDisable()
    local strength = 0
    local interval = 0
    Blockman.Instance().m_gameSettings:setPatternSpeedLine(strength, interval)
    UIHelper.showToast("[OFF]")
    GUIGMControlPanel:hide()
end

function GMHelper:THNoClip()
    A = not A
    for blockId = 3, 133 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 3, 133 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:PatternTorchMode()
    local strength = 1
    Blockman.Instance().m_gameSettings:setPatternTorchStrength(strength)
    UIHelper.showToast("[ON]")
    GUIGMControlPanel:hide()
end

function GMHelper:PatternTorchModeOFF()
    local strength = 0
    Blockman.Instance().m_gameSettings:setPatternTorchStrength(strength)
    UIHelper.showToast("[OFF]")
    GUIGMControlPanel:hide()
end

function GMHelper:CameraFlipModeRESET()
    Blockman.Instance().m_gameSettings:setFovSetting(1)
    GUIGMControlPanel:hide()
end

function GMHelper:BW()
    GMHelper:openInput(
        {""},
        function(Number)
            ClientHelper.putIntPrefs("ClientHelper.RunLimitCheck", Number)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:BWV2()
    ClientHelper.putIntPrefs("ClientHelper.RunLimitCheck", 999999999e9)
    UIHelper.showToast("Success")
end

function GMHelper:BlinkOP()
    A = not A
    ClientHelper.putBoolPrefs("SyncClientPositionToServer", false)
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    ClientHelper.putBoolPrefs("SyncClientPositionToServer", true)
    UIHelper.showToast("[OFF]")
end

function GMHelper:CameraFlipModeON()
    Blockman.Instance().m_gameSettings:setFovSetting(90)
    GUIGMControlPanel:hide()
end

function GMHelper:DestroyQuick()
    cBlockManager.cGetBlockById(66):setNeedRender(false)
    cBlockManager.cGetBlockById(253):setNeedRender(false)
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setHardness(0)
            UIHelper.showToast("Success [NO OFF]")
            GUIGMControlPanel:hide()
        end
    end
end

function GMHelper:Unknown1()
    GUIManager:hideWindowByName("Main.binary")
    GUIManager:hideWindowByName("Main.json")
    GUIGMControlPanel:hide()
end

function GMHelper:HideHP()
    GUIManager:getWindowByName("PlayerInfo-Health"):SetVisible(false)
end

function GMHelper:ShowHP()
    GUIManager:getWindowByName("PlayerInfo-Health"):SetVisible(true)
end

function GMHelper:Unknown2()
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            Blockman.Instance():setBloomEnable(true)
            Blockman.Instance():enableFullscreenBloom(true)
            Blockman.Instance():setBlockBloomOption(100)
            Blockman.Instance():setBloomIntensity(100)
            Blockman.Instance():setBloomSaturation(100)
            Blockman.Instance():setBloomThreshold(100)
            UIHelper.showToast("Success [NO OFF]")
            GUIGMControlPanel:hide()
        end
    end
end

function GMHelper:Unknown3()
    GUIManager:showWindowByName("PlayerInventory-DesignationTab")
    GUIManager:getWindowByName("PlayerInventory-DesignationTab"):SetVisible(true)
    GUIManager:showWindowByName("PlayerInventory-MainInventoryTab")
    GUIManager:getWindowByName("PlayerInventory-MainInventoryTab"):SetVisible(true)
    GUIManager:getWindowByName("PlayerInventory-MainInventoryTab"):SetArea({1, 1}, {1, 0}, {0, 1}, {0, 1})
    GUIManager:getWindowByName("PlayerInventory-DesignationTab"):SetArea({0, 0}, {0, 0}, {0.3, 0}, {0.3, 0})
    GUIManager:getWindowByName("PlayerInventory-ToggleInventoryButton"):SetVisible(true)
    GUIManager:showWindowByName("PlayerInventory-ToggleInventoryButton")
    GUIGMControlPanel:hide()
end

function GMHelper:Freecam()
    GUIManager:getWindowByName("Main-HideAndSeek-Operate"):SetVisible(true)
    GUIGMControlPanel:hide()
end

function GMHelper:Throwpot()
    A = not A
    GUIManager:showWindowByName("Main-throwpot-Controls")
    GUIManager:getWindowByName("Main-throwpot-Controls"):SetVisible(false)
    if A then
        GUIManager:showWindowByName("Main-throwpot-Controls")
        GUIManager:getWindowByName("Main-throwpot-Controls"):SetVisible(true)
    end
    GUIGMControlPanel:hide()
end

function GMHelper:SetBobbing()
    GMHelper:openInput(
        {""},
        function(Number)
            ClientHelper.putFloatPrefs("PlayerBobbingScale", Number)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:OffChat()
    GUIManager:getWindowByName("Main-Chat-Message"):SetVisible(false)
    GUIManager:getWindowByName("Main-Chat-Message"):SetVisible(false)
end

function GMHelper:OnChat()
    GUIManager:getWindowByName("Main-Chat-Message"):SetVisible(true)
    GUIManager:getWindowByName("Main-Chat-Message"):SetVisible(true)
end

function GMHelper:Noclip()
    A = not A
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:THNoClip()
    A = not A
    for blockId = 3, 133 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 3, 133 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:NoObsidian1()
    A = not A
    for blockId = 49, 50 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 49, 50 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:NoOakPlanks1()
    A = not A
    for blockId = 5, 6 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 5, 6 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:NoGlass1()
    A = not A
    for blockId = 94, 95 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 94, 95 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:NoEndStone1()
    A = not A
    for blockId = 120, 121 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 120, 121 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:NoWool1()
    A = not A
    for blockId = 34, 35 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 34, 35 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:NoBomb1()
    A = not A
    for blockId = 593, 594 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 593, 594 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:NoIDoor1()
    A = not A
    for blockId = 241, 242 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 241, 242 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:NoQuartz1()
    A = not A
    for blockId = 155, 156 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    for blockId = 155, 156 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    end
    UIHelper.showToast("[OFF]")
end

function GMHelper:JumpHeight()
    GMHelper:openInput(
        {""},
        function(Number)
            local player = PlayerManager:getClientPlayer()
            if player and player.Player then
                player.Player:setFloatProperty("JumpHeight", Number)
                UIHelper.showToast("Success")
            end
        end
    )
end

function GMHelper:addCurrencyCustom(player)
    GMHelper:openInput(
        player,
        {"100"},
        function(currency)
            currency = tonumber(currency) or 0
            player:addCurrency(currency, "GM")
        end
    )
end

function GMHelper:GUIOpener()
    GMHelper:openInput(
        {".json"},
        function(Number)
            GUIManager:showWindowByName(Number)
        end
    )
end

function GMHelper:GUIViewOFF()
    GMHelper:openInput(
        {".json"},
        function(Number)
            GUIManager:hideWindowByName(Number)
        end
    )
end

function GMHelper:InsideGUI()
    GMHelper:openInput(
        {"", ""},
        function(Number, Exe)
            GUIManager:getWindowByName(Number):SetVisible(Exe)
        end
    )
end

function GMHelper:ChangeNick()
    GMHelper:openInput(
        {""},
        function(Nick)
            PlayerManager:getClientPlayer().Player:setShowName(Nick)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:FlyParachute()
    local moveDir = VectorUtil.newVector3(0.0, 1.35, 0.0)
    local player = PlayerManager:getClientPlayer()
    player.Player:setAllowFlying(true)
    player.Player:setFlying(true)
    player.Player:moveEntity(moveDir)
    PlayerManager:getClientPlayer().Player:startParachute()
    UIHelper.showToast("Success")
end

function GMHelper:AdvancedUp()
    GMHelper:openInput(
        {""},
        function(Num)
            local moveDir = VectorUtil.newVector3(0.0, Num, 0.0)
            PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
        end
    )
end

function GMHelper:AdvancedIn()
    GMHelper:openInput(
        {""},
        function(Num)
            local moveDir = VectorUtil.newVector3(Num, 0.0, 0.0)
            PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
        end
    )
end

function GMHelper:AdvancedOn()
    GMHelper:openInput(
        {""},
        function(Num)
            local moveDir = VectorUtil.newVector3(0.0, 0.0, Num)
            PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
        end
    )
end

function GMHelper:AdvancedDirect()
    GMHelper:openInput(
        {"", "", ""},
        function(Num, Num2, Num3)
            local moveDir = VectorUtil.newVector3(Num, Num2, Num3)
            PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
        end
    )
end

function GMHelper:tpPos()
    GMHelper:openInput(
        {"", "", ""},
        function(Num, Num2, Num3)
            local playerPos = VectorUtil.newVector3(Num, Num2, Num3)
            local moveDir = VectorUtil.newVector3(1.0, 1.0, 1.0)
            PlayerManager:getClientPlayer().Player:setPosition(playerPos)
            PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
        end
    )
end

function GMHelper:HideHoldItem()
    A = not A
    PlayerManager:getClientPlayer():setHideHoldItem(true)
    UIHelper.showToast("[ON]")
    if A then
        PlayerManager:getClientPlayer():setHideHoldItem(false)
        UIHelper.showToast("[OFF]")
    end
end

function GMHelper:MineReset()
    local playerPos = VectorUtil.newVector3(536, 2.78, -136)
    local moveDir = VectorUtil.newVector3(0.0, 0.0, 0.0)
    PlayerManager:getClientPlayer().Player:setPosition(playerPos)
    PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
    UIHelper.showToast("Success")
end

function GMHelper:DeveloperFLY()
    local moveDir = VectorUtil.newVector3(0.0, 1.35, 0.0)
    local player = PlayerManager:getClientPlayer()
    player.Player:setAllowFlying(true)
    player.Player:setFlying(true)
    player.Player:moveEntity(moveDir)
    UIHelper.showToast("Success")
end

function GMHelper:SetFOV()
    GMHelper:openInput(
        {""},
        function(data)
            Blockman.Instance().m_gameSettings:setFovSetting(data)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:SharpFly()
    A = not A
    ClientHelper.putBoolPrefs("DisableInertialFly", true)
    UIHelper.showToast("[ON]")
    if A then
        ClientHelper.putBoolPrefs("DisableInertialFly", false)
        UIHelper.showToast("[OFF]")
    end
end

function GMHelper:WaterPush()
    A = not A
    local entity = PlayerManager:getClientPlayer().Player
    entity:setBoolProperty("ignoreWaterPush", true)
    UIHelper.showToast("[ON]")
    if A then
        entity:setBoolProperty("ignoreWaterPush", false)
        UIHelper.showToast("[OFF]")
    end
end

function GMHelper:ReachSet()
    GMHelper:openInput(
        {""},
        function(Float)
            ClientHelper.putFloatPrefs("EntityReachDistance", Float)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:changeScale()
    GMHelper:openInput(
        {""},
        function(Scale)
            local entity = PlayerManager:getClientPlayer().Player
            entity:setScale(Scale)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:BlockOFF()
    GMHelper:openInput(
        {""},
        function(Numer)
            local blockId = Numer
            local block = BlockManager.getBlockById(blockId)
            block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    )
end

function GMHelper:BlockON()
    GMHelper:openInput(
        {""},
        function(Numer)
            local blockId = Numer
            local block = BlockManager.getBlockById(blockId)
            block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
    )
end

function GMHelper:SpeedManager(vals)
    PlayerManager:getClientPlayer().Player:setSpeedAdditionLevel(vals)
    UIHelper.showToast("Success")
end

function GMHelper:SpeedManagerSet()
   GMHelper:openInput(
        {""},
        function(vals)
            PlayerManager:getClientPlayer().Player:setSpeedAdditionLevel(vals)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:SpeedUp()
    ClientHelper.putIntPrefs("SpeedAddMax", 20000000)
    UIHelper.showToast("[SUCCESS]")
end

function GMHelper:XRayManagerON()
    GMHelper:openInput(
        {""},
        function(Numer)
            cBlockManager.cGetBlockById(Numer):setNeedRender(false)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:XRayManagerOFF()
    GMHelper:openInput(
        {""},
        function(Numer)
            cBlockManager.cGetBlockById(Numer):setNeedRender(true)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:OFFDARK()
    cBlockManager.cGetBlockById(66):setNeedRender(false)
    cBlockManager.cGetBlockById(253):setNeedRender(false)
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setLightValue(150, 150, 150)
            UIHelper.showToast("Success")
            GUIGMControlPanel:hide()
        end
    end
end

function GMHelper:SpawnNPC()
    GMHelper:openInput(
        {".actor"},
        function(actor)
            local pos = PlayerManager:getClientPlayer():getPosition()
            local yaw = PlayerManager:getClientPlayer():getYaw()
            EngineWorld:addActorNpc(
                pos,
                yaw,
                actor,
                function(entity)
                end
            )
        end
    )
end

function GMHelper:spawnCar()
    GMHelper:openInput(
        {""},
        function(ID)
            local pos = PlayerManager:getClientPlayer():getPosition()
            Blockman.Instance():getWorld():addVehicle(pos, ID, 5)
            UIHelper.showToast("^00FFEECar Spawn Success")
        end
    )
end

function GMHelper:TeleportByUID()
    GMHelper:openInput(
        {""},
        function(ID)
            local player = PlayerManager:getClientPlayer().Player
            local Dplayer = PlayerManager:getPlayerByUserId(ID)
            if Dplayer then
                player:setPosition(Dplayer:getPosition())
            end
        end
    )
end

function GMHelper:NoFall()
    A = not A
    ClientHelper.putIntPrefs("SprintLimitCheck", 7)
    if A then
        UIHelper.showToast("[ON]")
        return
    end
    ClientHelper.putIntPrefs("SprintLimitCheck", 0)
    UIHelper.showToast("[OFF]")
end

function GMHelper:ChangeActorForMe()
    local entity = PlayerManager:getClientPlayer().Player
    GMHelper:openInput(
        {".actor"},
        function(actor)
            Blockman.Instance():getWorld():changePlayerActor(entity, actor)
            Blockman.Instance():getWorld():changePlayerActor(entity, actor)
            entity.m_isPeopleActor = false
            EngineWorld:restorePlayerActor(entity)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:AfkMode()
    A = not A
    PlayerManager:getClientPlayer().Player.m_rotateSpeed = 4
    GUIGMControlPanel:hide()
    UIHelper.showToast("[ON]")
    if A then
        PlayerManager:getClientPlayer().Player.m_rotateSpeed = 0
        GUIGMControlPanel:hide()
        UIHelper.showToast("[OFF]")
    end
end

function GMHelper:DevnoClip()
    A = not A
    PlayerManager:getClientPlayer().Player.noClip = true
    UIHelper.showToast("[ON]")
    if A then
        PlayerManager:getClientPlayer().Player.noClip = false
        UIHelper.showToast("[OFF]")
    end
end

function GMHelper:StepHeight()
    GMHelper:openInput(
        {""},
        function(data)
            PlayerManager:getClientPlayer().Player.stepHeight = data
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:SpYaw()
    A = not A
    PlayerManager:getClientPlayer().Player.spYaw = true
    UIHelper.showToast("[ON]")
    if A then
        PlayerManager:getClientPlayer().Player.spYaw = false
        UIHelper.showToast("[OFF]")
    end
end

function GMHelper:SpYawSet()
    GMHelper:openInput(
        {""},
        function(data)
            PlayerManager:getClientPlayer().Player.spYawRadian = data
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:HairSet()
    GMHelper:openInput(
        {""},
        function(Data)
            PlayerManager:getClientPlayer().Player.m_isEquipWing = true
            PlayerManager:getClientPlayer().Player.m_isClothesChange = true
            PlayerManager:getClientPlayer().Player.m_isClothesChanged = true
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:SetHideAndShowArmor()
    A = not A
    LogicSetting.Instance():setHideArmor(true)
    UIHelper.showToast("[ON]")
    if A then
        LogicSetting.Instance():setHideArmor(false)
        UIHelper.showToast("[OFF]")
    end
end

function GMHelper:SetAlpha()
    GMHelper:openInput(
        {"Gui Name", "Alpha"},
        function(GUI, Number)
            GUIManager:getWindowByName(GUI):SetAlpha(Number)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:ChangeHair()
    GMHelper:openInput(
        {""},
        function(Kelg)
            local player = PlayerManager:getClientPlayer().Player
            player.m_outLooksChanged = true
            player.m_hairID = Kelg
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:ChangeFace()
    GMHelper:openInput(
        {""},
        function(Kelg)
            local player = PlayerManager:getClientPlayer().Player
            player.m_outLooksChanged = true
            player.m_faceID = Kelg
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:ChangeTops()
    GMHelper:openInput(
        {""},
        function(Kelg)
            local player = PlayerManager:getClientPlayer().Player
            player.m_outLooksChanged = true
            player.m_topsID = Kelg
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:ChangePants()
    GMHelper:openInput(
        {""},
        function(Kelg)
            local player = PlayerManager:getClientPlayer().Player
            player.m_outLooksChanged = true
            player.m_pantsID = Kelg
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:ChangeShoes()
    GMHelper:openInput(
        {""},
        function(Kelg)
            local player = PlayerManager:getClientPlayer().Player
            player.m_outLooksChanged = true
            player.m_shoesID = Kelg
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:ChangeGlasses()
    GMHelper:openInput(
        {""},
        function(Kelg)
            local player = PlayerManager:getClientPlayer().Player
            player.m_outLooksChanged = true
            player.m_glassesId = Kelg
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:ChangeScarf()
    GMHelper:openInput(
        {""},
        function(Kelg)
            local player = PlayerManager:getClientPlayer().Player
            player.m_outLooksChanged = true
            player.m_scarfId = Kelg
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:ChangeWing()
    GMHelper:openInput(
        {""},
        function(Kelg)
            local player = PlayerManager:getClientPlayer().Player
            player.m_outLooksChanged = true
            player.m_wingId = Kelg
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:ShowRegion()
    UIHelper.showToast("RegionID = " .. Game:getRegionId())
end

function GMHelper:GameID()
    UIHelper.showToast("GameID = " .. CGame.Instance():getGameType())
end

function GMHelper:LogInfo()
    local content = HostApi.getClientInfo()
    ClientHelper.onSetClipboard(content)
    UIHelper.showToast("Success")
end

function GMHelper:GetAllInfoT()
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        MsgSender.sendMsg(
            "^FF0000INFO : " ..
                string.format(
                    "^FF0000Username : %s {} ID : %s {} Gender : %s",
                    player:getName(),
                    player.userId,
                    player.Player:getSex()
                )
        )
    end
end

function GMHelper:spawnCar()
    GMHelper:openInput(
        {""},
        function(ID)
            local pos = PlayerManager:getClientPlayer():getPosition()
            local yaw = PlayerManager:getClientPlayer():getYaw()
            Blockman.Instance():getWorld():addVehicle(pos, ID, yaw)
            UIHelper.showToast("Success")
        end
    )
end

function GMHelper:SpawnItem()
    GMHelper:openInput(
        {"ID", "Count"},
        function(Id, Count)
            local position = PlayerManager:getClientPlayer():getPosition()
            EngineWorld:addEntityItem(Id, Count, 0, 600, position, VectorUtil.ZERO)
        end
    )
end

function GMHelper:SetBlockToAir()
    GMHelper:openInput(
        {"X", "Y", "Z"},
        function(X, Y, Z)
            local blockPos = VectorUtil.newVector3(X, Y, Z)
            EngineWorld:setBlockToAir(blockPos)
        end
    )
end

function GMHelper:SpawnBlock()
    GMHelper:openInput(
        {""},
        function(martin)
            local blockPos = PlayerManager:getClientPlayer():getPosition()
            EngineWorld:setBlock(blockPos, martin)
        end
    )
end

function GMHelper:BlockReachSet()
    GMHelper:openInput(
        {""},
        function(Float)
            ClientHelper.putFloatPrefs("BlockReachDistance", Float)
            UIHelper.showToast("done")
        end
    )
end

function GMHelper:equipWings(type)
    local player = PlayerManager:getClientPlayer().Player
    player.m_outLooksChanged = true
    player.m_wingId = type
    UIHelper.showToast("Success")
end

function GMHelper:Tracer()
    A = not A
    LuaTimer:cancel(TracerLocal)
    UIHelper.showToast("OFF")
    if A then
        local me = PlayerManager:getClientPlayer()
        TracerLocal = LuaTimer:scheduleTimer(function()
            PlayerManager.getClientPlayer().Player:deleteAllGuideArrow()
            local others = PlayerManager:getPlayers()
            for _, c_player in pairs(others) do
                if c_player ~= me then
                    me.Player:addGuideArrow(c_player:getPosition())
                end
            end
        end, 500, -1)
        UIHelper.showToast("ON")
    end
end

function GMHelper:BW()
    ClientHelper.putIntPrefs("ClientHelper.RunLimitCheck", 0)
    UIHelper.showToast("^FF00EESuccess")
end

function GMHelper:BWV2()
    ClientHelper.putIntPrefs("ClientHelper.RunLimitCheck", 999999999e9)
    UIHelper.showToast("^FF00EESuccess")
end

function GMHelper:QuickHacks()
    local moveDir = VectorUtil.newVector3(0.0, 1.35, 0.0)
    local player = PlayerManager:getClientPlayer()
    player.Player:setAllowFlying(true)
    player.Player:setFlying(true)
    player.Player:moveEntity(moveDir)
    PlayerManager:getClientPlayer().Player:startParachute()

    cBlockManager.cGetBlockById(66):setNeedRender(false)
    cBlockManager.cGetBlockById(253):setNeedRender(false)
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setHardness(0)
        end
    end

    ClientHelper.putBoolPrefs("banClickCD", true)
    PlayerManager:getClientPlayer().Player:setSpeedAdditionLevel(2000)
    ClientHelper.putFloatPrefs("EntityReachDistance", 7)
    ClientHelper.putBoolPrefs("IsSeparateCamera", true)
    UIHelper.showToast("^FF00EESuccess")
end

function GMHelper:FightMode()
    A = not A
    ClientHelper.putFloatPrefs("EntityReachDistance", 5)
    PlayerManager:getClientPlayer().doubleJumpCount = 1
    LuaTimer:cancel(FightLocal)
    UIHelper.showToast("OFF")
    
    if A then
        FightLocal = LuaTimer:scheduleTimer(function()
            ClientHelper.putFloatPrefs("EntityReachDistance", 6)
            PlayerManager:getClientPlayer().doubleJumpCount = 2
            UIHelper.showToast("ON")
        end)
    end
end

function GMHelper:Scaffold()
    A = not A
    LuaTimer:cancel(ScaffoldLocal)
    UIHelper.showToast("OFF")
    
    if A then
        ScaffoldLocal = LuaTimer:scheduleTimer(function()
            local pos = PlayerManager:getClientPlayer():getPosition()
            EngineWorld:setBlock(VectorUtil.newVector3(pos.x, pos.y - 2, pos.z), 46)
            EngineWorld:setBlock(VectorUtil.newVector3(pos.x - 1, pos.y - 2, pos.z), 46)
            EngineWorld:setBlock(VectorUtil.newVector3(pos.x, pos.y - 2, pos.z - 1), 46)
        end, 0.2, 99999999999999999999999999)
        UIHelper.showToast("ON")
    end
end

function GMHelper:AutoClick()
    A = not A
    LuaTimer:cancel(ClickLocal)
    UIHelper.showToast("[OFF] SpamClick")
    
    if A then
        ClickLocal = LuaTimer:scheduleTimer(function()
            CGame.Instance():handleTouchClick(800, 360)
            UIHelper.showToast("[On] SpamClick")
        end, 0.35, -1)
    end
end

function GMHelper:SpamChat(vals)
    A = not A
    LuaTimer:cancel(ChatLocal)
    UIHelper.showToast("OFF")
    
    if A then
        ChatLocal =
            LuaTimer:scheduleTimer(
            function()
                GUIManager:getWindowByName("Chat-Input-Box"):SetProperty("Text", vals)
            end,
            5,
            99999999999e9
        )
        UIHelper.showToast("ON")
    end
end

function GMHelper:RespawnSpam()
    A = not A
    LuaTimer:cancel(RespawnLocal)
    UIHelper.showToast("OFF")
    if A then
        WarnHP = 25
        WarnHP = tonumber(WarnHP)
        RespawnLocal =
            LuaTimer:scheduleTimer(
            function()
                local player = PlayerManager:getClientPlayer()
                local HP = player.Player:getHealth()
                if HP <= WarnHP then
                    local playerPos = PlayerManager:getClientPlayer():getPosition()
                    local playerPosN = VectorUtil.newVector3(playerPos.x, 0, playerPos.z)
                    player.Player:setPosition(playerPosN)
                    PacketSender:getSender():sendRebirth()
                end
            end,
            0.9,
            999999999e9
        )
        UIHelper.showToast("ON")
        GUIGMControlPanel:hide()
    end
end

function GMHelper:RespawnNew()
    WarnHP = 25
    WarnHP = tonumber(WarnHP)
    local player = PlayerManager:getClientPlayer()
    local HP = player.Player:getHealth()
    if HP <= WarnHP then
        local playerPos = PlayerManager:getClientPlayer():getPosition()
        local playerPosN = VectorUtil.newVector3(playerPos.x, 0, playerPos.z)
        player.Player:setPosition(playerPosN)
        PacketSender:getSender():sendRebirth()
    end
    UIHelper.showToast("Success")
end

function GMHelper:TeleportNear()
    A = not A
    LuaTimer:cancel(NearLocal)
    UIHelper.showToast("OFF")
    
    if A then
        local me = PlayerManager:getClientPlayer()
        local moveDir = VectorUtil.newVector3(1.0, 1.0, 1.0)
        NearLocal =
            LuaTimer:scheduleTimer(
            function()
                local others = PlayerManager:getPlayers()
                for _, c_player in pairs(others) do
                    if c_player ~= me then
                        me.Player:setPosition(c_player:getPosition())
                        me.Player:moveEntity(moveDir)
                    end
                end
            end,
            119,
            -1
        )
        UIHelper.showToast("ON")
        GUIGMControlPanel:hide()
    end
end

function GMHelper:SetHitbox()
    local player = PlayerManager:getClientPlayer().Player
    player:setWidth(10)
    UIHelper.showToast("^FF00EESuccess: Hitbox Set to " .. 10)
end