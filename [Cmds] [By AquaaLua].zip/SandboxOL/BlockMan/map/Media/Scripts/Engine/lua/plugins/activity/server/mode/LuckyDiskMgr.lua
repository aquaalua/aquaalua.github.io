
---@class LuckyDiskDBData
local initLuckyDiskData = {
    storeList = {}, --当前随机出来的物品
    curSelectId = {},
    refreshTimes = 0,
    buyTimes = 1,
    startDayTime = 0,
}

---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")

---@type LuckyDiskConfig
local LuckyDiskConfig = Plugins.Require("activity", "common.config.LuckyDiskConfig")

---@type SBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "server.mode.BaseActivityMgr")

---@class SLuckyDiskMgr : SBaseActivityMgr
local LuckyDiskMgr = class("SLuckyDiskMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.LuckyDisk, LuckyDiskMgr, LuckyDiskConfig)

----------------------------------------------------------------------------------
---@param mgrConfig LuckyDiskConfigData
function LuckyDiskMgr:initActivity(mgrConfig)
    ---@private
    self.config = mgrConfig
end

---@param player SBasePlayer
function LuckyDiskMgr:initPlayerCache(player, data)
    data = data or {}
    local cache = {}
    for key, default in pairs(TableUtil.copyTable(initLuckyDiskData)) do
        cache[key] = data[key] or default
    end
    self:setPlayerCache(player, cache)
    if cache.startDayTime < DateUtil.getUTCDayStartTime(os.time()) then
        -- 重新刷新
        self:setPlayerCache(player, cache)
        self:luckyDiskDataRefresh(player)
    end

    cache = self:getPlayerCache(player)
    if not next(cache.storeList) then
        -- 避免刷不到数据
        cache.refreshTimes = 0
        self:setPlayerCache(player, cache)
        self:luckyDiskDataRefresh(player)
    end
end
-------------------------------------功能相关---------------------------------------------------
---@return LuckyDiskRewardLevelConfig
function LuckyDiskMgr:getRewardLevel()
    local rewardLevelCfg = self.config.rewardLevelCfg
    local totalWeight = 0
    for _, v in pairs(rewardLevelCfg) do
        totalWeight = v.weight + totalWeight
    end
    local num = math.random(1, totalWeight)
    local index = 0
    local curWeight = 0
    for i, v in pairs(rewardLevelCfg) do
        curWeight = v.weight + curWeight
        if curWeight >= num then
            index = i
            break
        end
    end
    return rewardLevelCfg[index]
end

---@return LuckyDiskRefreshPriceConfig
function LuckyDiskMgr:getRefreshPricesCfg(refreshTime)
    local refreshPriceCfg = self.config.refreshPriceCfg
    if refreshTime > #refreshPriceCfg then
        return refreshPriceCfg[#refreshPriceCfg]
    end
    for _, v in pairs(refreshPriceCfg) do
        if refreshTime == v.times then
            return v
        end
    end
end

---@return LuckyDiskBuyPricesConfig
function LuckyDiskMgr:getBuyPricesCfg(refreshTime)
    local buyPriceCfg = self.config.buyPriceCfg
    if refreshTime > #buyPriceCfg then
        return buyPriceCfg[#buyPriceCfg]
    end
    for _, v in pairs(buyPriceCfg) do
        if refreshTime == v.times then
            return v
        end
    end
end

---@return LuckyDiskRewardConfig[]
function LuckyDiskMgr:getRewardCfg()
    return self.config.rewardCfg
end

---@return LuckyDiskRewardConfig
function LuckyDiskMgr:getRewardCfgById(id)
    for _, v in pairs(self:getRewardCfg()) do
        if id == v.id then
            return v
        end
    end
end

function LuckyDiskMgr:checkHasNormalReward()
    if not self.normalRewardCfg then
        self.normalRewardCfg = {}
        self.normalWeightSum = 0
        local rewardCfg = self:getRewardCfg()
        for _, v in pairs(rewardCfg) do
            if v.isCore == 1 then
                table.insert(self.normalRewardCfg, v)
                self.normalWeightSum = self.normalWeightSum + v.weight
            end
        end
    end
end

function LuckyDiskMgr:checkHasCoreReward()
    if not self.coreRewardCfg then
        self.coreRewardCfg = {}
        self.coreWeightSum = 0
        local rewardCfg = self:getRewardCfg()
        for _, v in pairs(rewardCfg) do
            if v.isCore == 2 then
                table.insert(self.coreRewardCfg, v)
                self.coreWeightSum = self.coreWeightSum + v.weight
            end
        end
    end
end

function LuckyDiskMgr:getRandomCoreItem(num)
    self:checkHasCoreReward()
    local result = {}
    local itemNum = num
    while (itemNum > 0) do
        local rate = math.random(1, self.coreWeightSum)
        local sum = 0
        for _, data in pairs(self.coreRewardCfg) do
            sum = BaseUtil:incNumber(sum, data.weight)
            if sum >= rate then
                local notRepeat = true
                for _, itemId in pairs(result) do
                    if itemId == data.id then
                        notRepeat = false
                        break
                    end
                end
                if notRepeat then
                    table.insert(result, data.id)
                    itemNum = itemNum - 1
                    break
                end
            end
        end
    end
    return result
end

function LuckyDiskMgr:getRandomCommonItem(num)
    self:checkHasNormalReward()
    local itemNum = num
    local result = {}
    while (itemNum > 0) do
        local rate = math.random(1, self.normalWeightSum)
        local sum = 0
        for _, data in pairs(self.normalRewardCfg) do
            sum = BaseUtil:incNumber(sum, data.weight)
            if sum >= rate then
                local notRepeat = true
                for _, itemId in pairs(result) do
                    if itemId == data.id then
                        notRepeat = false
                        break
                    end
                end
                if notRepeat then
                    table.insert(result, data.id)
                    itemNum = itemNum - 1
                    break
                end
            end
        end
    end
    return result
end

function LuckyDiskMgr:sortPoolItem(coreItem, commonItem)
    local allItem = {}
    for _, item in pairs(coreItem) do
        table.insert(allItem, item)
    end
    for _, item in pairs(commonItem) do
        table.insert(allItem, item)
    end
    local cfg = self:getRewardCfgById(allItem[2])
    if cfg.isCore == 2 then
        local id = allItem[2]
        allItem[2] = allItem[4]
        allItem[4] = id
    end
    return allItem
end

---@param player SBasePlayer
function LuckyDiskMgr:luckyDiskDataRefresh(player)
    local cache = self:getPlayerCache(player)
    local rewardLv = self:getRewardLevel()
    local coreItem = self:getRandomCoreItem(rewardLv.number)
    local commonItem = self:getRandomCommonItem(6 - rewardLv.number)
    cache.storeList = self:sortPoolItem(coreItem, commonItem)
    cache.curSelectId = {}
    cache.startDayTime = DateUtil.getUTCDayStartTime(os.time())
    cache.refreshTimes = cache.refreshTimes + 1
    cache.buyTimes = 1
    self:setPlayerCache(player, cache)

    player:sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "luckyDiskDataRefresh",
    })
end

---@param player SBasePlayer
function LuckyDiskMgr:refreshPool(player)
    local cache = self:getPlayerCache(player)
    if cache.buyTimes >= 6 then
        self:luckyDiskDataRefresh(player)
        return
    end
    local refreshTimes = cache.refreshTimes
    local refreshCfg = self:getRefreshPricesCfg(refreshTimes)
    self:payMoney(player, refreshCfg.uniqueId, refreshCfg.type, refreshCfg.price, function()
         self:luckyDiskDataRefresh(player)
    end)
end

---@param player SBasePlayer
function LuckyDiskMgr:randomReward(player)
    local cache = self:getPlayerCache(player)
    cache.buyTimes = cache.buyTimes + 1
    local tmpStoreList = TableUtil.copyTable(cache.storeList)
    for i = #tmpStoreList, 1, -1 do
        for _, id in pairs(cache.curSelectId) do
            if tmpStoreList[i] == id then
                table.remove(tmpStoreList, i)
            end
        end
    end
    local totalSecondWeight = 0
    for i, v in pairs(tmpStoreList) do
        local cfg = self:getRewardCfgById(v)
        if cfg then
            totalSecondWeight = totalSecondWeight + cfg.secondWeight
        end
    end
    local randNum = math.random(1, totalSecondWeight)
    local curSecondWeight = 0
    local num = 0
    for i, v in pairs(tmpStoreList) do
        local cfg = self:getRewardCfgById(v)
        if cfg then
            curSecondWeight = curSecondWeight + cfg.secondWeight
            if curSecondWeight >= randNum then
                num = i
                break
            end
        end
    end
    local id = tmpStoreList[num]
    table.insert(cache.curSelectId, id)
    local rewardCfg = self:getRewardCfgById(id)
    local realReward = self:receiveReward(player, rewardCfg.reward)
    if realReward then
        ReportEvent.activity_lucky_disk_buy(player, self.mainConfig.id, rewardCfg.reward.rewardId)
        player:sendPacket({
            pid = "GameActivityShowReward",
            rewards = {
                { rewardId = realReward.realRewardId or realReward.rewardId, num = rewardCfg.reward.num }
            },
        })
    end
    self:setPlayerCache(player, cache)
end

---@param player SBasePlayer
function LuckyDiskMgr:buy(player)
    local cache = self:getPlayerCache(player)
    if cache.buyTimes > 6 then
        self:luckyDiskDataRefresh(player)
        return
    end
    local buyPriceCfg = self:getBuyPricesCfg(cache.buyTimes)
    self:payMoney(player, buyPriceCfg.uniqueId, buyPriceCfg.type, buyPriceCfg.price, function()
        self:randomReward(player)
    end)
end

return LuckyDiskMgr