---@class GUIFishBagItemWindow : IGUIWindow
local GUIFishBagItemWindow = class("GUIFishBagItemWindow", IGUIWindow)
---@type FishingConfig
local FishingConfig = T(Global, "FishingConfig")

---@private
function GUIFishBagItemWindow:ctor(...)
	self.super.ctor(self, "FishBagItem.json", ...)
end

---@private
function GUIFishBagItemWindow:onLoad()
	self.siBg = self:getChildWindowByName("FishBagItem", GUIType.StaticImage)
	self.siIcon = self:getChildWindowByName("FishBagItem-Icon", GUIType.StaticImage)
	self.stNum = self:getChildWindowByName("FishBagItem-Num", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIFishBagItemWindow:initView()
end

---@private
function GUIFishBagItemWindow:initEvent()
	self.siBg:registerEvent(GUIEvent.Click, function()
		if not self.configData or not self.configData.showDetailId then
			return
		end
		GUICommonActivityRewardDetail:show(self.configData.showDetailId)
	end)
end

---@param data table
function GUIFishBagItemWindow:onDataChanged(data)
	---@type FishConfigData
	local config = FishingConfig:getFishConfig(data.id)
	if not config then
		return
	end
	self.configData = config
	self.stNum:SetText("x" .. data.num)
	self.siIcon:SetImage(config.image)
	self.siBg:SetImage(config.isRare and "set:bed_war_fishing.json image:img_0_fish_bg_1" or "set:bed_war_fishing.json image:img_0_fish_bg")
end

return GUIFishBagItemWindow
