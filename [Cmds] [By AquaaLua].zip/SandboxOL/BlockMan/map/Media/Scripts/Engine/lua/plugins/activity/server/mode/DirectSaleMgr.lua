
---@class DirectSaleDBData
local initDirectSaleDBData = {
    haveBuy = false,
}

---@type DirectSaleConfig
local DirectSaleConfig = Plugins.Require("activity", "common.config.DirectSaleConfig")

---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@type SBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "server.mode.BaseActivityMgr")

---@class SDirectSaleMgr : SBaseActivityMgr
local DirectSaleMgr = class("SDirectSaleMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.DirectSale, DirectSaleMgr, DirectSaleConfig)

----------------------------------------------------------------------------------
---@param mgrConfig DirectSaleConfigData
function DirectSaleMgr:initActivity(mgrConfig)
    self.config = mgrConfig
end

---@param player SBasePlayer
function DirectSaleMgr:initPlayerCache(player, data)
    data = data or {}
    local cache = {}
    for key, default in pairs(initDirectSaleDBData) do
        cache[key] = data[key] or default
    end
    self:setPlayerCache(player, cache)
end

-------------------------------------功能相关---------------------------------------------------
------@param player SBasePlayer
function DirectSaleMgr:buyDirectSale(player)
    ---@type DirectSaleDBData
    local cache = self:getPlayerCache(player)
    if cache.haveBuy then
        return
    end
    self:payMoney(player, self.config.uniqueId, self.config.moneyType, self.config.price, function()
        cache.haveBuy = true
        self:setPlayerCache(player, cache)

        local results = {}
        local rewards = DirectSaleConfig:getRewardGroup(self.config.rewardGroupId)
        for _, cfg in pairs(rewards) do
            local reward = DirectSaleConfig:getRewardById(cfg.id)
            if reward then
                local realReward = self:receiveReward(player, reward.reward)
                if realReward then
                    local newRewardId = realReward.realRewardId or realReward.rewardId
                    if not results[newRewardId] then
                        results[newRewardId] = { rewardId = newRewardId, num = reward.reward.num }
                    else
                        results[newRewardId].num = results[newRewardId].num + reward.reward.num
                    end
                end
            end
        end

        local rewardList = {}
        for i, v in pairs(results) do
            table.insert(rewardList, v)
        end
        player:sendPacket({
            pid = "GameActivityShowReward",
            rewards = rewardList,
        })
    end)
end

---@param player SBasePlayer
function DirectSaleMgr:resetDirectSaleActivity(player)
    local cache = {}
    for key, default in pairs(initDirectSaleDBData) do
        cache[key] = default
    end
    self:setPlayerCache(player, cache)
end

return DirectSaleMgr