---@class UIChristmasGiftTaskLayout : IGUILayout
local UIChristmasGiftTaskLayout = class("UIChristmasGiftTaskLayout", IGUILayout)

local PosGuideSize = {
    x = 60,
    y = 65
}
local CurPosGuideScale = 1
local onEnlargeScaleTip = false
local enlargeScaleChangeTimes = 20

---@private
function UIChristmasGiftTaskLayout:ctor(parent)
    self.super.ctor(self, "ChristmasGiftTask.json", parent)
end

---@private
function UIChristmasGiftTaskLayout:isDelayLoad()
    return true
end

---@private
function UIChristmasGiftTaskLayout:onLoad()
    self.siPosGuideBg = self:getChildWindow("ChristmasGiftTask-PosGuide-Bg", GUIType.StaticImage)
    self.siPosGuideTop = self:getChildWindow("ChristmasGiftTask-PosGuide-Top", GUIType.StaticImage)
    self.siPosGuideBottom = self:getChildWindow("ChristmasGiftTask-PosGuide-Bottom", GUIType.StaticImage)
    self.siPosGuideLeft = self:getChildWindow("ChristmasGiftTask-PosGuide-Left", GUIType.StaticImage)
    self.siPosGuideRight = self:getChildWindow("ChristmasGiftTask-PosGuide-Right", GUIType.StaticImage)
    self.stPosGuideText = self:getChildWindow("ChristmasGiftTask-PosGuide-Text", GUIType.StaticText)
    self.siPosGuideIcon = self:getChildWindow("ChristmasGiftTask-PosGuide-Icon", GUIType.StaticImage)
    self.llTipBg = self:getChildWindow("ChristmasGiftTask-Tip-Bg", GUIType.Layout)
    self.stTpText = self:getChildWindow("ChristmasGiftTask-Tp-Text", GUIType.StaticText)
    self.siTipEffect = self:getChildWindow("ChristmasGiftTask-Tip-Effect", GUIType.StaticImage)
    self:initView()
    self:initEvent()

    self.siPosGuideBg:SetVisible(false)
    self.llTipBg:SetVisible(false)
end

---@private
function UIChristmasGiftTaskLayout:initView()
    self.stTpText:SetText(Lang:getString("Christmas_Gift_Send"))
    self.llTipBg:SetWidth({ 0, 215 + self.stTpText:GetTextWidth() })
end

---@private
function UIChristmasGiftTaskLayout:initEvent()

end

---@private
function UIChristmasGiftTaskLayout:showTip()
    self.llTipBg:SetVisible(true)
    self.siTipEffect:PlayEffect1()
    LuaTimer:cancel(self.tipKey)
    self.tipKey = LuaTimer:scheduleTimer(function()
        self.llTipBg:SetVisible(false)
    end, 1500, 1)
end

------------------------ 坐标引导 --------------------------------
---@param screenPos Vector2
---@param direction number
---@param scale number
function UIChristmasGiftTaskLayout:setPosWeakGuidePos(screenPos, direction, scale)
    LuaTimer:cancel(self.changeGuidePosKey)
    CurPosGuideScale = scale
    if not onEnlargeScaleTip then
        self.siPosGuideBg:SetWidth({ 0, PosGuideSize.x * CurPosGuideScale })
        self.siPosGuideBg:SetHeight({ 0, PosGuideSize.y * CurPosGuideScale })
    end

    self.siPosGuideBg:SetXPosition({ screenPos.x - 0.5, 0 })
    self.siPosGuideBg:SetYPosition({ screenPos.y - 0.5, 0 })

    self.siPosGuideTop:SetVisible(false)
    self.siPosGuideBottom:SetVisible(false)
    self.siPosGuideLeft:SetVisible(false)
    self.siPosGuideRight:SetVisible(false)
    self.stPosGuideText:SetVisible(false)
    if direction == Define.Direction.Top then
        self.siPosGuideTop:SetVisible(true)
    elseif direction == Define.Direction.Bottom then
        self.siPosGuideBottom:SetVisible(true)
    elseif direction == Define.Direction.Left then
        self.siPosGuideLeft:SetVisible(true)
    elseif direction == Define.Direction.Right then
        self.siPosGuideRight:SetVisible(true)
    else
        self.stPosGuideText:SetVisible(true)
    end
end

function UIChristmasGiftTaskLayout:setPosWeakGuide()
    LuaTimer:cancel(self.changeGuidePosKey)
    self.siPosGuideBg:SetVisible(true)
end

function UIChristmasGiftTaskLayout:hidePosWeakGuidePos()
    LuaTimer:cancel(self.changeGuidePosKey)
    self.siPosGuideBg:SetVisible(false)
end

function UIChristmasGiftTaskLayout:enlargeScaleTip()
    LuaTimer:cancel(self.changePosGuideScaleKey)
    onEnlargeScaleTip = true
    local times = 1
    self.changePosGuideScaleKey = LuaTimer:scheduleTimer(function()
        local scale = math.sin((times) / enlargeScaleChangeTimes * math.pi) * 0.6
        self.siPosGuideBg:SetWidth({ 0, PosGuideSize.x * (CurPosGuideScale + scale) })
        self.siPosGuideBg:SetHeight({ 0, PosGuideSize.y * (CurPosGuideScale + scale) })

        if times == enlargeScaleChangeTimes then
            onEnlargeScaleTip = false
        end
        times = times + 1
    end, 30, enlargeScaleChangeTimes)
end
------------------------ end --------------------------------

return UIChristmasGiftTaskLayout
