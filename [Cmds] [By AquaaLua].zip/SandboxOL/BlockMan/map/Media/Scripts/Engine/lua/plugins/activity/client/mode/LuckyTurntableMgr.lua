---@type LuckyTurntableConfig
local LuckyTurntableConfig = Plugins.Require("activity", "common.config.LuckyTurntableConfig")

---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")

---@class CLuckyTurntableMgr : CBaseActivityMgr
local LuckyTurntableMgr = class("CLuckyTurntableMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.LuckyTurntable, LuckyTurntableMgr, LuckyTurntableConfig)

----------------------------------------------------------------------------------
---@param mgrConfig LuckyTurntableData
function LuckyTurntableMgr:initActivity(mgrConfig)
    self.config = mgrConfig
end

---@param player SBasePlayer
---@param cache LuckyDiskDBData
function LuckyTurntableMgr:setPlayerCache(player, cache)
    self.dataCache = cache
    if self.cacheCallBack then
        self.cacheCallBack()
    end
end

---@return LuckyDiskDBData
function LuckyTurntableMgr:getPlayerCache()
    return self.dataCache or {
        lastLotteryDay = 0,
        lotteryTimes = 0,
    }
end

---@return LuckyTurntableRewardData[]
function LuckyTurntableMgr:getRewardCfg()
    return self.config.rewardCfg
end

function LuckyTurntableMgr:getLotteryPrice()
    local price = self.config.price
    local cache = self:getPlayerCache()
    if cache.lastLotteryDay < DateUtil.getUTCDayStartTime(os.time()) then
        price = math.floor(price / 2)
    end
    return price
end

function LuckyTurntableMgr:tryBuy()
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "buy",
    })
end

return LuckyTurntableMgr
