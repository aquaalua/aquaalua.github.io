---
--- Created by Jimmy.
--- DateTime: 2018/3/8 0008 10:16
---
DateUtil = {}

---获取在本年第几周的key(string)，格式：年周，例子：202201
function DateUtil.getYearWeek(time)
    local week = DateUtil.getWeeksOfYear(time)
    if week >= 10 then
        return os.date("%Y", time) .. week
    else
        return os.date("%Y", time) .. "0" .. week
    end
end

---获取在本年第几周(int)
function DateUtil.getWeeksOfYear(time)
    if time == nil then
        time = os.time()
    end
    local firstYearTime = os.time({ day = 1, month = 1, year = os.date("%Y", time) })
    local firstYearDate = os.date("*t", firstYearTime)
    local date = os.date("*t", time)
    local start_wday = firstYearDate.wday - 1
    local yday = date.yday
    if (start_wday + yday) % 7 == 0 then
        return (start_wday + yday) / 7
    else
        return NumberUtil.getIntPart((start_wday + yday) / 7) + 1
    end
end

function DateUtil.getWeekDay(time)
    if time == nil then
        time = os.time()
    end
    return os.date("*t", time).wday
end

function DateUtil.getYearDay(time)
    if time == nil then
        time = os.time()
    end
    return os.date("%Y%j", time)
end

function DateUtil.getDate(time)
    if time == nil then
        time = os.time()
    end
    return os.date("%Y-%m-%d", time)
end

function DateUtil.getDateString(time)
    if time == nil then
        time = os.time()
    end
    return os.date("%Y-%m-%d %X", time)
end

---获取本月（time）最后的时间戳
function DateUtil.getMonthLastTime(time)
    if time == nil then
        time = os.time()
    end
    local date = os.date("*t", time)
    if date.month >= 12 then
        time = os.time({ year = date.year + 1, month = 1, day = 1, hour = 0, minute = 0, second = 0 })
    else
        time = os.time({ year = date.year, month = date.month + 1, day = 1, hour = 0, minute = 0, second = 0 })
    end
    return time + (os.time(os.date("*t")) - os.time(os.date("*t")))
end

---获取本周（time）最后的时间戳
function DateUtil.getWeekLastTime(time, real)
    time = DateUtil.getDayLastTime(time, true)
    local date = os.date("*t", time)
    local wday = date.wday
    time = time + (7 - wday + 1) * 86400
    if real then
        return time - 1
    end
    return time + 86399
end

---获取当天（time）最后的时间戳
function DateUtil.getDayLastTime(time, real)
    if time == nil then
        time = os.time()
    end
    local date = os.date("*t", time + 86400)
    time = os.time({ year = date.year, month = date.month, day = date.day, hour = 0, minute = 0, second = 0 })
    if real then
        return time - 1 ---卡在23:59:59，不要跳到隔天00:00:00，否则DateUtil.getWeekLastTime会计算错误
    end
    return time + 86399
end

---获取当天（time）剩余的秒数
function DateUtil.getDayLeftSeconds(time)
    time = time or os.time()
    return DateUtil.getDayLastTime(time, true) - time
end

---获取本周（time）剩余的秒数
function DateUtil.getWeekLeftSeconds(time)
    time = time or os.time()
    return DateUtil.getWeekLastTime(time, true) - time
end

function DateUtil.getWeekSeconds()
    return 604800
end

function DateUtil.getDaySeconds()
    return 86400
end

local function checkTime(text, append, format, pattern, split)
    split = split or ":"
    if string.find(format, pattern) ~= nil then
        if #text ~= 0 then
            text = text .. split
        end
        if append < 10 then
            text = text .. "0" .. append
        else
            text = text .. append
        end
    end
    return text
end

---获取格式化后的时间 默认(HH:mm:ss)
---@param seconds number 秒数
---@param format string 格式化规则
function DateUtil.getFormatTime(seconds, format, split)
    format = format or "HH:mm:ss"
    local text = ""
    local hour = math.floor(seconds / 3600)
    local minute = math.floor((seconds % 3600) / 60)
    local second = math.floor(seconds % 60)
    text = checkTime(text, hour, format, "HH", split)
    text = checkTime(text, minute, format, "mm", split)
    text = checkTime(text, second, format, "ss", split)
    return text
end

function DateUtil.getFormatTimeWithDay(seconds)
    local text = ""
    local day = math.floor(seconds / (3600 * 24))
    local hour = math.floor((seconds % (3600 * 24)) / 3600)
    local minute = math.floor((seconds % 3600) / 60)
    local second = seconds % 60
    if day > 0 then
        text = text .. day .. "D "
    end
    if hour < 10 then
        text = text .. "0" .. hour .. ":"
    else
        text = text .. hour .. ":"
    end
    if minute < 10 then
        text = text .. "0" .. minute .. ":"
    else
        text = text .. minute .. ":"
    end
    if second < 10 then
        text = text .. "0" .. second
    else
        text = text .. second
    end
    return text
end

---@param seconds number 秒数
function DateUtil.getTimeByTwoPara(seconds)
    local text = ""
    local day = math.floor(seconds / (3600 * 24))
    local hour = math.floor((seconds % (3600 * 24)) / 3600)
    local minute = math.floor((seconds % 3600) / 60)
    local second = seconds % 60
    if day >= 1 then
        text = text .. day .. "d"
        if hour >= 1 then
            text = text .. " " .. hour .. "h"
        end
    elseif hour >= 1 then
        text = text .. hour .. "h"
        if minute >= 1 then
            text = text .. " " .. minute .. "min"
        end
    elseif minute >= 1 then
        text = text .. minute .. "min"
        if second >= 1 then
            text = text .. " " .. second .. "s"
        end
    else
        text = text .. " " .. second .. "s"
    end
    return text
end

---获取北京跟当前服务器时间戳的差值
local function getBeiJingDiffTime()
    return os.time(os.date("*t")) - os.time(os.date("!*t")) - 28800
end

---根据date获取北京时间戳
---@param date table 某个北京时间日期的table
---eg: { year = 2020, month = 1, day = 20, hour = 1, min = 1, sec = 0 }
function DateUtil.date2BeiJingTime(date)
    date.isdst = false
    return os.time(date) + getBeiJingDiffTime()
end

---获取最近的格林威治一天最后的时间
function DateUtil.getGreenwichDayLastTime(time)
    if time == nil then
        time = os.time()
    end
    local date = os.date("!*t", time + 86400)
    time = os.time({ year = date.year, month = date.month, day = date.day, hour = 0, minute = 0, second = 0 })
    return time + (os.time(os.date("*t")) - os.time(os.date("!*t")))
end

---获取最近的格林威治一周最后的时间
function DateUtil.getGreenwichWeekLastTime(time)
    if time == nil then
        time = os.time()
    end
    local date = os.date("!*t", time)
    time = os.time({ year = date.year, month = date.month, day = date.day, hour = 0, minute = 0, second = 0 })
    time = time + (os.time(os.date("*t")) - os.time(os.date("!*t")))
    local wday = date.wday
    if wday == 1 then
        wday = 7
    else
        wday = wday - 1
    end
    --time是今天0点，要加完整一天再加周剩余天
    time = time + (7 - wday + 1) * 86400
    return time
end

---获取最近的格林威治一月最后的时间
function DateUtil.getGreenwichMonthLastTime(time)
    if time == nil then
        time = os.time()
    end
    local date = os.date("!*t", time)
    if date.month >= 12 then
        time = os.time({ year = date.year + 1, month = 1, day = 1, hour = 0, minute = 0, second = 0 })
    else
        time = os.time({ year = date.year, month = date.month + 1, day = 1, hour = 0, minute = 0, second = 0 })
    end
    return time + (os.time(os.date("*t")) - os.time(os.date("!*t")))
end

return DateUtil