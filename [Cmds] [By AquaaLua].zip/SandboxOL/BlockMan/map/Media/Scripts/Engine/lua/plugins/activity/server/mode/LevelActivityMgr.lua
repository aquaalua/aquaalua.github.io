
---@class LevelActivityDBData
local initLevelActivityData = {
    level = 0,
    records = {},
    haveBuy = false,
    lastDateOpenUI = 0,
}

---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@type LevelActivityConfig
local LevelActivityConfig = Plugins.Require("activity", "common.config.LevelActivityConfig")

---@type SBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "server.mode.BaseActivityMgr")

---@class SLevelActivityMgr : SBaseActivityMgr
local LevelActivityMgr = class("SLevelActivityMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.LevelActivity, LevelActivityMgr, LevelActivityConfig)

----------------------------------------------------------------------------------
---@param mgrConfig LevelActivityConfigData
function LevelActivityMgr:initActivity(mgrConfig)
    self.config = mgrConfig
end

---@param player SBasePlayer
function LevelActivityMgr:initPlayerCache(player, data)
    data = data or {}
    local cache = {}
    for key, default in pairs(initLevelActivityData) do
        cache[key] = data[key] or default
    end
    self:setPlayerCache(player, cache)
end

-------------------------------------功能相关---------------------------------------------------
---@param player SBasePlayer
function LevelActivityMgr:buyPrivilege(player)
    ---@type LevelActivityDBData
    local cache = self:getPlayerCache(player)
    if cache.haveBuy then
        return
    end
    self:payMoney(player, self.config.uniqueId, self.config.moneyType, self.config.price, function()
        cache.haveBuy = true
        self:setPlayerCache(player, cache)
        ReportEvent.activity_level_buy(player, self.mainConfig.id)
    end)
end

---@param player SBasePlayer
function LevelActivityMgr:tryGetReward(player, packet)
    ---@type LevelActivityDBData
    local cache = self:getPlayerCache(player)
    if not cache.haveBuy then
        return
    end

    local results = {}
    local function tryDoReward(rewardId)
        if TableUtil.tableContain(cache.records, rewardId) then
            return
        end
        local reward = LevelActivityConfig:getRewardById(rewardId)
        if not reward then
            return
        end
        if cache.level < reward.level then
            return
        end
        local realReward = self:receiveReward(player, reward.reward)
        table.insert(cache.records, rewardId)
        if realReward then
            local newRewardId = realReward.realRewardId or realReward.rewardId
            if not results[newRewardId] then
                results[newRewardId] = { rewardId = newRewardId, num = reward.reward.num }
            else
                results[newRewardId].num = results[newRewardId].num + reward.reward.num
            end
        end
    end
    if packet.rewardId <= 0 then
        local rewards = LevelActivityConfig:getRewardGroup(self.config.rewardGroupId)
        for _, reward in pairs(rewards) do
            if reward.level <= cache.level then
                tryDoReward(reward.id)
            end
        end
    else
        tryDoReward(packet.rewardId)
    end

    local rewards = {}
    for i, v in pairs(results) do
        table.insert(rewards, v)
    end
    local tableSize = TableUtil.getTableSize(rewards)
    if tableSize > 0 then
        player:sendPacket({
            pid = "GameActivityShowReward",
            rewards = rewards,
        })
        self:setPlayerCache(player, cache)
    end
end

---@param player SBasePlayer
function LevelActivityMgr:updateLevel(player, level)
    local cache = self:getPlayerCache(player)
    cache.level = level
    self:setPlayerCache(player, cache)
end

---@param player SBasePlayer
function LevelActivityMgr:updateLastOpenUIDate(player)
    local t = os.date("*t")
    local timestamp = DateUtil.date2BeiJingTime({ year = t.year, month = t.month, day = t.day, hour = 0, min = 0, sec = 0 })
    local cache = self:getPlayerCache(player)
    if cache.lastDateOpenUI ~= timestamp then
        cache.lastDateOpenUI = timestamp
        self:setPlayerCache(player, cache)
        ReportEvent.activity_level_open_ui(player, self.mainConfig.id)
    end
end

---@param player SBasePlayer
function LevelActivityMgr:resetLevelActivity(player)
    local cache = {}
    for key, default in pairs(initLevelActivityData) do
        cache[key] = default
        if key == "level" then
            cache[key] = player:getLevelInfo()
        end
    end
    self:setPlayerCache(player, cache)
end

return LevelActivityMgr