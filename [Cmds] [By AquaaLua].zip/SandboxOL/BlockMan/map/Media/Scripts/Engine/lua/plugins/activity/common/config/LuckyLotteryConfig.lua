---@class LuckyLotteryConfig
local LuckyLotteryConfig = {}
---@type LuckyLotteryData[]
local ConfigList = {}
---@type table<number, LuckyPriceData[]>
local PriceGroups = {}
---@type table<number, LuckyValueData[]>
local LuckyValueGroup = {}

local function initCfg()
    ConfigList = {}
    PriceGroups = {}
    LuckyValueGroup = {}
end

local function initConfig()
    local settings = FileUtil.getConfigFromCsv("plugins/activity/LuckyLottery.csv", 3, true)
    for _, item in pairs(settings) do
        if item.titleLang == "#" then
            item.titleLang = ""
        end
        if item.descLang == "#" then
            item.descLang = ""
        end
        local bgColor = StringUtil.split(item.bgColor, "#")
        local topColor = StringUtil.split(item.topColor, "#")
        local bottomColor = StringUtil.split(item.bottomColor, "#")
        local effectColor = StringUtil.split(item.effectColor, "#")
        ---@class LuckyLotteryData
        local data = {
            id = tonumber(item.id),
            mainShowImage = item.mainShowImage,
            rewardGroupId = tonumber(item.rewardGroupId),
            priceGroupId = tonumber(item.priceGroupId),
            valueGroupId = tonumber(item.valueGroupId),
            ticketTipType = tonumber(item.ticketTipType or 0),
            ticketTipParam = item.ticketTipParam or "#",
            uiJson = item.uiJson,
            limit = tonumber(item.limit or -1),
            bgColor = bgColor,
            topColor = topColor,
            bottomColor = bottomColor,
            effectColor = effectColor,
            exchangeStoreGroup = tonumber(item.exchangeStoreGroup),
        }
        if #data.uiJson < 5 then
            data.uiJson = nil
        end
        table.insert(ConfigList, data)
    end
end

local function initValue()
    local config = FileUtil.getConfigFromCsv("plugins/activity/LuckyValue.csv", 3, true)
    for _, item in pairs(config) do
        ---@type LuckyValueData[]
        local group = LuckyValueGroup[tostring(item.groupId)] or {}
        ---@class LuckyValueData
        local data = {}
        data.luckyValue = tonumber(item.luckyValue)
        data.luckyStars = tonumber(item.luckyStars)
        data.grandPrizeWeights = tonumber(item.grandPrizeWeights)
        table.insert(group, data)
        LuckyValueGroup[tostring(item.groupId)] = group
    end

    for _, group in pairs(LuckyValueGroup) do
        table.sort(group, function(a, b)
            return a.luckyValue < b.luckyValue
        end)
    end
end

local function initPrice()
    local config = FileUtil.getConfigFromCsv("plugins/activity/LuckyLotteryPrice.csv", 3, true)
    for _, item in pairs(config) do
        ---@type LuckyPriceData[]
        local group = PriceGroups[tostring(item.groupId)] or {}
        ---@class LuckyPriceData
        local price = {
            groupSeq = tonumber(item.groupSeq),
            uniqueId = tonumber(item.uniqueId) or 0,
            moneyType = tonumber(item.moneyType) or -1,
            price = tonumber(item.price) or 999,
            ticketType = tonumber(item.ticketType) or 1,
            ticketPrice = tonumber(item.ticketPrice) or 999,
            times = tonumber(item.times) or 1,
            priceLang = item.priceLang,
            tipLang = item.tipLang or "#",
            discountPrice = tonumber(item.discountPrice) or 999,
            discountType = tonumber(item.discountType) or 0,
            discountCycle = tonumber(item.discountCycle) or 0
        }
        group[price.groupSeq] = price
        PriceGroups[tostring(item.groupId)] = group
    end
end

local function init()
    initCfg()
    initConfig()
    initPrice()
    initValue()
end

function LuckyLotteryConfig:getConfigList()
    return ConfigList
end

function LuckyLotteryConfig:getActivityById(id)
    for _, config in pairs(ConfigList) do
        if config.id == id then
            return config
        end
    end
end

function LuckyLotteryConfig:getPriceConfigByGroupId(groupId)
    return PriceGroups[tostring(groupId)]
end

function LuckyLotteryConfig:getDisCountPrice(priceGroupId, type, discountCd)
    local priceConfigGroup = LuckyLotteryConfig:getPriceConfigByGroupId(priceGroupId)
    local priceConfig = priceConfigGroup[type]
    local realPrice = priceConfig.price
    if discountCd ~= nil and priceConfig.discountPrice < priceConfig.price and discountCd <= 0 then
        realPrice = priceConfig.discountPrice
    end
    return realPrice
end

function LuckyLotteryConfig:getWeightByLuckyValue(groupId, luckyValue)
    local weight = 0
    local LuckyValue = LuckyValueGroup[tostring(groupId)]
    for _, luckyLevel in pairs(LuckyValue) do
        if luckyValue >= luckyLevel.luckyValue then
            weight = luckyLevel.grandPrizeWeights
        else
            return weight
        end
    end
    return weight
end

--function LuckyLotteryConfig:getStarsByLuckyValue(groupId, luckyValue)
--    local luckyStar = 0
--    local LuckyValue = LuckyValueGroup[tostring(groupId)]
--    for _, luckyLevel in pairs(LuckyValue) do
--        if luckyValue >= luckyLevel.luckyValue then
--            luckyStar = luckyLevel.luckyStars
--        else
--            return luckyStar
--        end
--    end
--    return luckyStar
--end

function LuckyLotteryConfig:getMaxLuckyStars(groupId)
    local luckyStar = 1
    local LuckyValue = LuckyValueGroup[tostring(groupId)]
    for _, luckyLevel in pairs(LuckyValue) do
        if luckyStar < luckyLevel.luckyStars then
            luckyStar = luckyLevel.luckyStars
        end
    end
    if luckyStar > 3 then
        luckyStar = 3
        LogUtil.logError("LuckyLotteryConfig:getMaxLuckyStars: star can not great than 3 ...")
    end
    return luckyStar
end

function LuckyLotteryConfig:getMaxLuckyValue(groupId)
    local LuckyValue = LuckyValueGroup[tostring(groupId)]
    return LuckyValue[#LuckyValue].luckyValue
end

init()

return LuckyLotteryConfig