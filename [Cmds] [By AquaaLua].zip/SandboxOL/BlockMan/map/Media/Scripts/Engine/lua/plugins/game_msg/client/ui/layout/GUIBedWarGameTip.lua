local TipSoundType = {
    ["1008001"] = 1,
    ["1008010"] = 1,
    ["1008014"] = 1,
    ["1008019"] = 1,
    ["1008022"] = 2,
}

local offSetKey
---@param self UIGameTipLayout
local function offsetTimer(self, itemHeight, offsetValue)
    LuaTimer:cancel(offSetKey)
    if self.itemOffSet > itemHeight then
        offSetKey = LuaTimer:scheduleTimer(function()
            for _, tip in pairs(self.command) do
                local Y = tip.root:GetYPosition()
                tip.root:SetYPosition({ 0, Y[2] - offsetValue })
            end
            self.itemOffSet = self.itemOffSet - offsetValue
        end, 20, (self.itemOffSet - itemHeight) / offsetValue)
    end
end

---@class UIGameTipLayout : IGUILayout
local UIGameTipLayout = class("UIGameTips", IGUILayout)
---@type GameSystemTipConfig
local GameSystemTipConfig = T(Global, "GameSystemTipConfig")
---@type CommandSettingConfig
local CommandSettingConfig = T(Global, "CommandSettingConfig")
---@type CommandEffectConfig
local CommandEffectConfig = T(Global, "CommandEffectConfig")

UIGameTipLayout.itemOffSet = 0
UIGameTipLayout.command = {}
UIGameTipLayout.broadCastList = {}

UIGameTipLayout.SystemMapping = {
    GuideTip = "1",
    TeamTip = "2",
    GameTip = "3",
    ChatTip = "4",
}

function UIGameTipLayout:ctor()
    if GameType == "g1046" or GameType == "g1064" or GameType == "g1008" or GameType == "g1061" or GameType == "g1062" or GameType == "g1065" then
        self.super.ctor(self, "BedWarGameTips.json")
    else
        self.super.ctor(self, "BedWarGameTips.json", GUIManager:getMainControl())
    end
end

function UIGameTipLayout:onCreate()
    self:registerEvent(Events.ReceiveGameSystemMsgEvent, function(data)
        print("ReceiveGameSystemMsgEvent ")
        self:show()
        self:onGetSystemTip(data.data)
    end)

    self:registerEvent(Events.ReceiveGameTeamChatMsgEvent, function(data)
        print("ReceiveGameTeamChatMsgEvent ")
        self:show()

        --- 系统消息
        local tipType = data.data.tipType
        if tipType then
            self:onGetSystemTip(data.data)
        else
            self:onGetChat(data)
        end
    end)

    self:registerEvent(Events.ReceiveGameAllChatMsgEvent, function(data)
        print("ReceiveGameAllChatMsgEvent ")
        self:show()
        self:onGetChat(data)
    end)

    self:registerEvent(Events.ReceiveGameCommandMsgEvent, function(data)
        print("ReceiveGameCommandMsgEvent ")
        self:show()
        self:onGetCommand(data.senderId, data.data.commandId)
    end)

    self:registerEvent(Events.ReceiveGameKillMsgEvent, function(data)
        print("ReceiveGameKillMsgEvent ")
        self:show()
        self:onGetKillBroadCast(data.data)
    end)

    self:registerEvent(Events.ReceiveGameBottomTipMsgEvent, function(data)
        print("ReceiveGameBottomTipMsgEvent ")
        self:show()
        self:onShowBottomTip(data.data)
    end)
end

function UIGameTipLayout:isDelayLoad()
    return true
end

function UIGameTipLayout:onLoad()
    self.llOrder = self:getChildWindow("BedWarGameTips-order", GUIType.Layout)
    self.llTeamTip = self:getChildWindow("BedWarGameTips-team_tip", GUIType.Layout)
    self.llChat = self:getChildWindow("BedWarGameTips-chat", GUIType.Layout)
    self.llGameTip = self:getChildWindow("BedWarGameTips-game_tip", GUIType.Layout)
    self.llGuideTip = self:getChildWindow("BedWarGameTips-guide_tip", GUIType.Layout)
    self.llNewKillBroadCast = self:getChildWindow("BedWarGameTips-new_kill", GUIType.Layout)
    self.siBottomTipBg = self:getChildWindow("BedWarGameTips-bottom_tip", GUIType.StaticImage)

    self.stGameText = self:getChildWindow("BedWarGameTips-game_text", GUIType.StaticText)
    self.stTeamText = self:getChildWindow("BedWarGameTips-content", GUIType.StaticText)
    self.stTeamTitle = self:getChildWindow("BedWarGameTips-title", GUIType.StaticText)
    self.stGuideText = self:getChildWindow("BedWarGameTips-guide_text", GUIType.StaticText)
    self.stBottomTip = self:getChildWindow("BedWarGameTips-bottom_tip_text", GUIType.StaticText)

    self.llChat:SetVisible(false)
    self.llTeamTip:SetVisible(false)
    self.llGameTip:SetVisible(false)
    self.llGuideTip:SetVisible(false)
    self.siBottomTipBg:SetVisible(false)
    if GameType == "g1046" then
        self:setAlwaysOnTop(true)
    end
    self:initChatList()
    self:initKillBroadCast()
end

function UIGameTipLayout:initChatList()
    if self.gvChatItems ~= nil then
        return
    end
    if GameType == "g1064" then
        self.llChat:SetHorizontalAlignment(HorizontalAlignment.Right)
        self.llChat:SetVerticalAlignment(VerticalAlignment.Top)
        self.llChat:SetYPosition({ 0, 160 })
        self.llChat:SetWidth({ 0, 280 })
        self.llChat:SetHeight({ 0, 81 })
        self.llChat:SetBackgroundColor({ 0, 0, 0, 0.5 })
    end
    self.gvChatItems = IGUIGridView.new("BedWarChatList-Item", self.llChat)
    self.gvChatItems:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.gvChatItems:setConfig(0, 0, 1)
    self.gvChatItems.root:SetTouchable(false)
    self.ContentSize = self.llChat:GetPixelSize().x
    self.ScrollOffset = self.llChat:GetPixelSize().y
end

function UIGameTipLayout:initKillBroadCast()
    ---@type GUINewKillBroadCastItem
    self.llNewKillBroadCastItem = UIHelper.newGameGUIWindow("GUINewKillBroadCastItem")
    self.llNewKillBroadCastItem.root:SetArea({ -1, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.llNewKillBroadCastItem.root:SetVisible(false)
    self.llNewKillBroadCast:AddChildWindow(self.llNewKillBroadCastItem.root)
end

---@private
function UIGameTipLayout:onGetSystemTip(data)
    --- 系统消息
    local tipType = data.tipType
    local tipText = data.tipText or ""
    local tipStr = ""
    if tipType then
        tipStr = Lang:getTipString(tipType, tipText)
    else
        tipStr = Lang:getString(tipText)
    end
    local config = GameSystemTipConfig:getConfigByTipType(tipType)
    if not config then
        LogUtil.logWarning("Lack SystemTip Config, tipType:" .. (tipType or ""))
        return
    end
    for _, box in pairs(config.tipBox) do
        if box == UIGameTipLayout.SystemMapping.GuideTip then
            self:showGuideTip(tipStr)
        elseif box == UIGameTipLayout.SystemMapping.TeamTip then
            self:showTeamTip(tipStr)
        elseif box == UIGameTipLayout.SystemMapping.GameTip then
            self:showGameTip(tipStr)
        elseif box == UIGameTipLayout.SystemMapping.ChatTip then
            self:showChat(0, {content = tipStr}, Define.MessageType.System, Define.ChatMsgType.TextMsg)
        end
    end
    self:playTipSound(tipType)
end

---@private
function UIGameTipLayout:showGuideTip(tipStr)
    self.stGuideText:SetText(tipStr)
    self.llGuideTip:SetVisible(true)
    LuaTimer:cancel(self.guideTipKey)
    self.guideTipKey = LuaTimer:schedule(function()
        self.llGuideTip:SetVisible(false)
    end, 5000)
end

---@private
function UIGameTipLayout:showTeamTip(tipStr)
    self.llTeamTip:SetVisible(true)
    self.stTeamText:SetText(tipStr)
    self.stTeamTitle:SetText(Lang:getString("bed_war_danger"))
    LuaTimer:cancel(self.teamTipKey)
    self.teamTipKey = LuaTimer:schedule(function()
        self.llTeamTip:SetVisible(false)
    end, 3000)
end

function UIGameTipLayout:showGameTip(tipStr)
    if not self:isLoad() then
        self:show()
    end
    self.stGameText:SetText(tipStr)
    self.llGameTip:SetVisible(true)
    LuaTimer:cancel(self.systemTipKey)
    self.systemTipKey = LuaTimer:schedule(function()
        self.stGameText:SetText("")
        self.llGameTip:SetVisible(false)
    end, 5000)
end

---@private
function UIGameTipLayout:showChat(sendId, data, channelId, type)
    local senderInfo = GameInfoManager:getPlayerInfo(sendId)
    if senderInfo and senderInfo:getValue("mute_voice") == "1" then
        return
    end
    self:addChatItem(sendId, data, channelId, type)
end

---@private
function UIGameTipLayout:onGetChat(data)
    self:showChat(data.senderId, data.data, data.channelId, data.type)
end

function UIGameTipLayout:addTextChatItem(sendId, data, channelId, type)
    ---@type GUIChatItem
    local chatItem = UIHelper.newGameGUIWindow("GUIChatItem")
    chatItem:setWidth({ 0, self.ContentSize })
    local name = ""
    local height = 30
    local teamId
    local info = GameInfoManager:getPlayerInfo(sendId)
    if sendId == 0 or not info then
        height = chatItem:onGetSystemTip(data.content)
    else
        name = info:getValue("userName")
        teamId = info:getValue("teamId")
        if tostring(teamId) == "0" then
            height = chatItem:onGetChat(TextFormat.colorWrite, name, data.content, channelId)
        else
            height = chatItem:onGetChat(TeamColor:getTeamColor(teamId), name, data.content, channelId)
        end
    end

    return chatItem, height
end

function UIGameTipLayout:addChatItem(sendId, data, channelId, type)
    --print("========== ", sendId, data, channelId, type)
    local chatItem = nil
    local height = 0
    if type == Define.ChatMsgType.TextMsg then
        chatItem, height = self:addTextChatItem(sendId, data, channelId, type)
    end

    if chatItem then
        self.ScrollOffset = self.ScrollOffset - height
        if self.ScrollOffset < 0 then
            LuaTimer:schedule(function()
                self.gvChatItems.root:SetScrollOffset(self.ScrollOffset)
            end, 1)
        end
        chatItem:setHeight({ 0, height })

        --GameMsgRecord:addChatRecord(name, text)

        self.gvChatItems:addItem(chatItem)
        self.llChat:SetVisible(true)
        LuaTimer:cancel(self.showChatKey)
        self.showChatKey = LuaTimer:schedule(function()
            self.llChat:SetVisible(false)
        end, 10000)
    end
end

function UIGameTipLayout:onGetCommand(senderId, commandId)
    local config = CommandSettingConfig:getConfigById(commandId)
    if not config then
        return
    end
    ---@type GUICommandTip
    local commandItem = UIHelper.newGameGUIWindow("GUICommandTip")
    commandItem:setWidth({ 0, 380 })
    commandItem:setHeight({ 0, 66 })

    local commandIndex = commandItem:init(senderId, config.id, config)
    self.llOrder:AddChildWindow(commandItem.root)
    self.command[tostring(commandIndex)] = commandItem
    self.llOrder:SetVisible(true)

    ---新控件偏移量
    commandItem.root:SetYPosition({ 0, self.itemOffSet })
    ---控件滑动增量
    self.itemOffSet = self.itemOffSet + 80
    ---设置控件5秒后自动销毁
    LuaTimer:schedule(function()
        GUIManager:destroyGUIWindow(commandItem.root)
        self.command[tostring(commandIndex)] = nil
        offsetTimer(self, 80, 4)
        if self:getCurrCommandNum() == 0 then
            self.itemOffSet = 0
        end
    end, config.duration * 1000)
    offsetTimer(self, 160, 4)

    ---信号特效
    local effectConfig = CommandEffectConfig:getConfigById(config.effectId)
    if not effectConfig then
        return
    end
    ---@type CBasePlayer
    local sender = PlayerManager:getPlayerByUserId(senderId)
    if not sender then
        return
    end
    local getFountPosition = function(footPos, yaw)
        local leftYaw = yaw
        local x = -math.sin(leftYaw * MathUtil.DEG2RAD)
        local z = math.cos(leftYaw * MathUtil.DEG2RAD)
        return VectorUtil.newVector3(footPos.x + x * 0.3, footPos.y, footPos.z + z * 0.3)
    end
    ---设置特效
    local leftHandPos = getFountPosition(sender:getPosition(), sender:getYaw())
    CommandEffectConfig:shootFlares(senderId, effectConfig.id, leftHandPos)
end

function UIGameTipLayout:getCurrCommandNum()
    return TableUtil.getTableSize(self.command)
end

---@private
function UIGameTipLayout:onGetKillBroadCast(data)
    table.insert(self.broadCastList, data)
    local killerInfo = GameInfoManager:getPlayerInfo(data.killerId)
    local deadInfo = GameInfoManager:getPlayerInfo(data.deadId)
    if killerInfo and deadInfo then
        if tonumber(killerInfo:getValue("teamId")) == 0 or tonumber(deadInfo:getValue("teamId")) == 0 then
            return
        end
        local text = TeamColor:getTeamColor(killerInfo:getValue("teamId")) .. killerInfo:getValue("userName") .. "\t" ..
                TeamColor:getTeamColor(deadInfo:getValue("teamId")) .. deadInfo:getValue("userName")
        local tipStr = Lang:getTipString(1008005, text)
        self:addChatItem(0, {content = tipStr}, Define.MessageType.System, Define.ChatMsgType.TextMsg)
    end
    if TableUtil.getTableSize(self.broadCastList) == 1 then
        self:onBroadCastStart()
    end
end

function UIGameTipLayout:onBroadCastStart()
    if self:getCurrCommandNum() >= 1 or self.broadCastKey ~= nil then
        LuaTimer:schedule(function()
            self:onBroadCastStart()
        end, 1000)
    else
        self.llNewKillBroadCastItem:showKillBroadCast(self.broadCastList[1])
        self.broadCastKey = LuaTimer:schedule(function()
            table.remove(self.broadCastList, 1)
            self.broadCastKey = nil
            if TableUtil.getTableSize(self.broadCastList) > 0 then
                self:onBroadCastStart()
            end
        end, 3500)
    end
end

function UIGameTipLayout:onShowBottomTip(content)
    LuaTimer:cancel(self.bottomTipTimer)
    self.bottomTipTimer = LuaTimer:scheduleTimer(function()
        self.siBottomTipBg:SetVisible(false)
    end, content.time or 3000)
    local text = Lang:getString(content.text)
    self.stBottomTip:SetText(text)
    self.siBottomTipBg:SetVisible(true)
end

function UIGameTipLayout:playTipSound(tipType)
    if TipSoundType[tipType] == 1 then
        SoundUtil.playSound(SoundConfig.levelUpStore)
    elseif TipSoundType[tipType] == 2 then
        SoundUtil.playSound(SoundConfig.selfBedBreak)
    end
end

return UIGameTipLayout

