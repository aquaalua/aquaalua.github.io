---@type ClientReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@param event number event [event name]
---@param event_map table event_map [eg {key1 = value1,key2 = value2, ...}]
local function newDesign(event, event_map)
    local new_map = {}
    for key, value in pairs(event_map) do
        new_map["activity_" .. key] = value
    end
    ---@type BedWarUserInfo
    local cache = UserInfoCache:GetCache(Game:getPlatformUserId())
    local days = cache[Define.PlayerCustomInfo.PlayDays] or 1
    local isNew = days == 1
    new_map.is_new = isNew
    GameAnalytics:newDesign(event, new_map)
end

function ReportEvent.display_discount_shop_panel(activityId)
    local map = {
        id = tonumber(activityId),
    }
    newDesign("display_discount_shop_panel", map)
end

function ReportEvent.activity_get_all_reward(activityId)
    local map = {
        id = tonumber(activityId),
    }
    newDesign("activity_get_all_reward", map)
end

function ReportEvent.limited_gift_click(activityId, isCanReceive)
    local map = {
        id = tonumber(activityId),
        limited_gift_consumed = isCanReceive
    }
    newDesign("limited_gift_click", map)
end