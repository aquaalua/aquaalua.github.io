---@class LuckyDiskConfig
local LuckyDiskConfig = T(Global, "LuckyDiskConfig")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")

---@type LuckyDiskRewardLevelConfig[]
local RewardLevelConfig = {}
---@type LuckyDiskRefreshPriceConfig[]
local RefreshPriceConfig = {}
---@type LuckyDiskBuyPricesConfig[]
local BuyPricesConfig = {}
---@type LuckyDiskRewardConfig[]
local RewardConfig = {}

local function initConfig()
    local settings = FileUtil.getConfigFromCsv("plugins/activity/LuckyDiskRewardLevel.csv", 3, true)
    for _, item in pairs(settings) do
        ---@class LuckyDiskRewardLevelConfig
        local data = {
            id = tonumber(item.id),
            activityId = tonumber(item.activityId),
            number = tonumber(item.number),
            weight = tonumber(item.weight),
        }
        table.insert(RewardLevelConfig, data)
    end

    settings = FileUtil.getConfigFromCsv("plugins/activity/LuckyDiskRefreshPrices.csv", 3, true)
    for _, item in pairs(settings) do
        ---@class LuckyDiskRefreshPriceConfig
        local data = {
            id = tonumber(item.id),
            activityId = tonumber(item.activityId),
            times = tonumber(item.times),
            type = tonumber(item.type),
            price = tonumber(item.price),
            uniqueId = tonumber(item.uniqueId),
        }
        table.insert(RefreshPriceConfig, data)
    end

    settings = FileUtil.getConfigFromCsv("plugins/activity/LuckyDiskPrices.csv", 3, true)
    for _, item in pairs(settings) do
        ---@class LuckyDiskBuyPricesConfig
        local data = {
            id = tonumber(item.id),
            activityId = tonumber(item.activityId),
            times = tonumber(item.times),
            type = tonumber(item.type),
            price = tonumber(item.price),
            uniqueId = tonumber(item.uniqueId),
        }
        table.insert(BuyPricesConfig, data)
    end

    settings = FileUtil.getConfigFromCsv("plugins/activity/LuckyDiskRewardSetting.csv", 3, true)
    for _, item in pairs(settings) do
        ---@type CommonActivityRewardData
        local rewardCfg = CommonActivityConfig:getRewardById(item.rewardId)
        if rewardCfg then
            ---@type CommonActivityRewardData
            local reward = TableUtil.copyTable(rewardCfg)
            reward.num = tonumber(item.num)
            ---@class LuckyDiskRewardConfig
            local data = {
                id = tonumber(item.id),
                activityId = tonumber(item.activityId),
                groupSeq = tonumber(item.groupSeq),
                reward = reward,
                isCore = tonumber(item.isCore),
                weight = tonumber(item.weight),
                secondWeight = tonumber(item.secondWeight),
            }
            table.insert(RewardConfig, data)
        end
    end
end

function LuckyDiskConfig:getActivityById(activityId)
    local rewardLevelCfg = {}
    local refreshPriceCfg = {}
    local buyPriceCfg = {}
    local rewardCfg = {}
    for _, v in pairs(RewardLevelConfig) do
        if v.activityId == activityId then
            table.insert(rewardLevelCfg, v)
        end
    end
    for _, v in pairs(RefreshPriceConfig) do
        if v.activityId == activityId then
            table.insert(refreshPriceCfg, v)
        end
    end
    for _, v in pairs(BuyPricesConfig) do
        if v.activityId == activityId then
            table.insert(buyPriceCfg, v)
        end
    end
    for _, v in pairs(RewardConfig) do
        if v.activityId == activityId then
            table.insert(rewardCfg, v)
        end
    end
    table.sort(rewardLevelCfg, function(a, b)
        return a.id < b.id
    end)
    table.sort(refreshPriceCfg, function(a, b)
        return a.id < b.id
    end)
    table.sort(buyPriceCfg, function(a, b)
        return a.id < b.id
    end)
    table.sort(rewardCfg, function(a, b)
        return a.id < b.id
    end)
    ---@class LuckyDiskConfigData
    local data = {
        rewardLevelCfg = rewardLevelCfg,
        refreshPriceCfg = refreshPriceCfg,
        buyPriceCfg = buyPriceCfg,
        rewardCfg = rewardCfg,
    }
    return data
end

initConfig()

return LuckyDiskConfig