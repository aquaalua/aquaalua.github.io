---@class DirectSaleConfig
local DirectSaleConfig = T(Global, "DirectSaleConfig")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")

---@type LevelActivityConfigData[]
local ConfigList = {}
---@type table<string, LevelActivityRewardData[]>
local RewardGroups = {}
---@type table<string, LevelActivityRewardData>
local Rewards = {}

local function initConfig()
    local settings = FileUtil.getConfigFromCsv("plugins/activity/DirectSale.csv", 3, true)
    for _, item in pairs(settings) do
        ---@class DirectSaleConfigData
        local data = {
            id = tonumber(item.id),
            rewardGroupId = item.rewardGroupId,
            price = tonumber(item.price),
            originPrice = tonumber(item.originPrice),
            moneyType = tonumber(item.moneyType),
            uniqueId = tonumber(item.uniqueId),
        }
        table.insert(ConfigList, data)
    end

    settings = FileUtil.getConfigFromCsv("plugins/activity/DirectSaleRewardGroup.csv", 3, true)
    for _, item in pairs(settings) do
        ---@type DirectSaleRewardData[]
        local group = RewardGroups[tostring(item.groupId)] or {}
        ---@type CommonActivityRewardData
        local rewardCfg = CommonActivityConfig:getRewardById(item.rewardId)
        if rewardCfg then
            ---@class DirectSaleRewardData
            local data = {
                id = tonumber(item.id),
                reward = rewardCfg,
                groupSeq = tonumber(item.groupSeq),
                level = tonumber(item.level),
            }
            Rewards[tostring(item.id)] = data
            table.insert(group, data)
        end
        RewardGroups[tostring(item.groupId)] = group
    end
    for _, group in pairs(RewardGroups) do
        table.sort(group, function(a, b)
            return a.groupSeq < b.groupSeq
        end)
    end
end

---@return DirectSaleConfigData
function DirectSaleConfig:getActivityById(activityId)
    for _, config in pairs(ConfigList) do
        if config.id == activityId then
            return config
        end
    end
end

---@return DirectSaleRewardData[]
function DirectSaleConfig:getRewardGroup(groupId)
    return RewardGroups[tostring(groupId)] or {}
end

---@return DirectSaleRewardData
function DirectSaleConfig:getRewardById(rewardId)
    return Rewards[tostring(rewardId)]
end

initConfig()

return DirectSaleConfig