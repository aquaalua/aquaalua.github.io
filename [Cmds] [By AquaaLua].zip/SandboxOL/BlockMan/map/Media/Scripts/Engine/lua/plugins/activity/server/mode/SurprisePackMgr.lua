
---@class SurprisePackDBData
local initSurprisePackDBData = {
    consumeDiamond = 0,
    receiveId = 0,
    haveReceive = false,
}

---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@type SurprisePackConfig
local SurprisePackConfig = Plugins.Require("activity", "common.config.SurprisePackConfig")

---@type SBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "server.mode.BaseActivityMgr")

---@class SSurprisePackMgr : SBaseActivityMgr
local SurprisePackMgr = class("SSurprisePackMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.SurprisePack, SurprisePackMgr, SurprisePackConfig)
----------------------------------------------------------------------------------
---@param mgrConfig SurprisePackConfigData
function SurprisePackMgr:initActivity(mgrConfig)
    self.config = mgrConfig
end

---@param player SBasePlayer
function SurprisePackMgr:initPlayerCache(player, data)
    data = data or {}
    local cache = {}
    for key, default in pairs(initSurprisePackDBData) do
        cache[key] = data[key] or default
    end
    self:setPlayerCache(player, cache)
end

-------------------------------------功能相关---------------------------------------------------
---@param player SBasePlayer
function SurprisePackMgr:tryGetReward(player, packet)
    local results = {}
    ---@type SurprisePackDBData
    local cache = self:getPlayerCache(player)
    if cache.haveReceive then
        return
    end
    if cache.consumeDiamond < self.config.consumeDiamond then
        return
    end
    local rewardIndex = packet.rewardIndex
    local rewards = SurprisePackConfig:getRewardGroup(self.config.rewardGroupId)
    if not rewards or not rewards[rewardIndex] or not rewards[rewardIndex].reward then
        return
    end
    local reward = rewards[rewardIndex].reward
    local realReward = self:receiveReward(player, reward)
    if realReward then
        self:updateReceiveId(player, rewardIndex)
        table.insert(results, { rewardId = realReward.realRewardId or realReward.rewardId, isGrandPrize = reward.isGrandPrize })
    end
    player:sendPacket({
        pid = "GameActivityShowReward",
        rewards = results,
    })

    -- 埋点
    ReportEvent.limited_gift_get(player, self.mainConfig.id, rewardIndex)
end

---@param player SBasePlayer
function SurprisePackMgr:updateConsumeDiamond(player, num)
    local cache = self:getPlayerCache(player)
    cache.consumeDiamond = num
    self:setPlayerCache(player, cache)
end

---@param player SBasePlayer
function SurprisePackMgr:updateReceiveId(player, id)
    local cache = self:getPlayerCache(player)
    cache.receiveId = id
    cache.haveReceive = true
    self:setPlayerCache(player, cache)
end

---@param player SBasePlayer
function SurprisePackMgr:diamondConsume(player, diamonds)
    local cache = self:getPlayerCache(player)
    cache.consumeDiamond = cache.consumeDiamond + diamonds
    self:setPlayerCache(player, cache)
end

---@param player SBasePlayer
function SurprisePackMgr:resetSurprisePackActivity(player)
    local cache = {}
    for key, default in pairs(initSurprisePackDBData) do
        cache[key] = default
    end
    self:setPlayerCache(player, cache)
end

return SurprisePackMgr