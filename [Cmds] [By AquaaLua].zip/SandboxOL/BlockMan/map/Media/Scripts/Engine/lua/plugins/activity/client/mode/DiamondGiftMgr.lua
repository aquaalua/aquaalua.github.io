---@type DiamondGiftRewardConfig
local DiamondGiftRewardConfig = Plugins.Require("activity", "common.config.DiamondGiftRewardConfig")

---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")

---@class CDiamondGiftMgr : CBaseActivityMgr
local CDiamondGiftMgr = class("CDiamondGiftMgr", BaseActivityMgr)

---@type EventUtil
local EventUtil = T(Global, "EventUtil")

---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@type ActivityTalentRank
local ActivityTalentRank = Plugins.Require("activity", "common.config.ActivityTalentRank")

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.DiamondGiftReward, CDiamondGiftMgr, DiamondGiftRewardConfig)
----------------------------------------------------------------------------------
---@param mgrConfig LevelActivityConfigData
function CDiamondGiftMgr:initActivity(mgrConfig)
    EventUtil.goObjEvent(self)
    self.config = mgrConfig
    self.dataCache = {buyTimes = {}}
end

---@param player SBasePlayer
---@param cache LevelActivityDBData
function CDiamondGiftMgr:setPlayerCache(player, cache)
    self.dataCache = cache
    self:checkRedDot()
    self:emitEvent("cacheDataChange")

    if self.cacheCallBack then
        self.cacheCallBack()
    end
end

---@return LevelActivityDBData
function CDiamondGiftMgr:getPlayerCache()
    return self.dataCache or {
        buyTimes = {}
    }
end

function CDiamondGiftMgr:getBuyTimes(id)
    local cache = self:getPlayerCache()
    return cache.buyTimes[tostring(id)] or 0
end

function CDiamondGiftMgr:checkHasFreeReward()
    local rewardList = DiamondGiftRewardConfig:getAllConfig(self.mainConfig.activityId)

    local cache = self:getPlayerCache()
    local buyTimes = cache.buyTimes
    for i, reward in pairs(rewardList) do
        --- 免费 并且 次数小于最大次数
        if reward.price == 0 and (not buyTimes[tostring(reward.id)] or buyTimes[tostring(reward.id)] < reward.times ) then
            return true
        end
    end
    return false
end


function CDiamondGiftMgr:checkRedDot()
    if self:checkHasFreeReward() then
        UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity .. "_" .. self.mainConfig.id, 1)
    else
        UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity .. "_" .. self.mainConfig.id, 0)
    end
end

-------------------------------------功能相关---------------------------------------------------
function CDiamondGiftMgr:tryGetReward(rewardId)
    if not self:getPlayerCache().haveBuy then
        return
    end
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "tryGetReward",
        rewardId = rewardId,
    })
end

function CDiamondGiftMgr:onBuyPrivilege(id)
    local buyFunc = function()
        PlayerManager:getClientPlayer():sendPacket({
            pid = "ToActivityPacket",
            id = id,
            activityId = self.mainConfig.id,
            funcName = "buyGoods"
        })
    end

    local config = DiamondGiftRewardConfig:getConfigById(id)
    if config.price ~= 0 and (config.moneyType == CurrencyId.Diamonds or config.moneyType == CurrencyId.GCube) then
        PayHelper.checkMoney(config.moneyType, config.price, function(canBuy)
            if canBuy then
                CustomDialog.builder().setTitleText("DiamondGift.buyPop.title")
                            .setRightText(Lang:getString("gui_dialog_tip_btn_sure"))
                            .setContentText(Lang:getString("DiamondGift.buyPop.content"))
                            .setRightClickListener(
                        function()
                            CustomDialog.hide()
                            buyFunc()
                        end).show()
            end
        end)
    else
        buyFunc()
    end
    return true
end

function CDiamondGiftMgr:getConfigById(id)
    local currId = id
    local index = 1
    if not id then
        local configList = DiamondGiftRewardConfig:getAllConfig(self.mainConfig.activityId)
        local cache = self:getPlayerCache()
        local buyTimes = cache.buyTimes
        for i, cfg in ipairs(configList) do
            if not buyTimes[tostring(cfg.id)] or buyTimes[tostring(cfg.id)] < cfg.times then
                if i < #configList then
                    index = i + 1
                    currId = configList[index].id
                else
                    index = i
                    currId = cfg.id
                end
                break
            end
        end
    end
    local config = DiamondGiftRewardConfig:getConfigById(currId)
    return config, currId
end

function CDiamondGiftMgr:updateLastOpenUIDate()
    --PlayerManager:getClientPlayer():sendPacket({
    --    pid = "ToActivityPacket",
    --    activityId = self.mainConfig.id,
    --    funcName = "updateLastOpenUIDate"
    --})
end

function CDiamondGiftMgr:getTalentRankData(id)
    local currId = id
    local index = 1

    local configList = DiamondGiftRewardConfig:getAllConfig(self.mainConfig.activityId)
    local cache = self:getPlayerCache()
    local buyTimes = cache.buyTimes
    for i, cfg in ipairs(configList) do
        if currId then
            if cfg.id == currId then
                index = i
                break
            end
        else
            if not buyTimes[tostring(cfg.id)] or buyTimes[tostring(cfg.id)] < cfg.times then
                if i < #configList then
                    index = i + 1
                    currId = configList[index].id
                else
                    index = i
                    currId = cfg.id
                end
                break
            end
        end
    end
    ---@type CTalentController
    local CTalentController = T(Global, "CTalentController")
    return ActivityTalentRank:getTalentRankData(index, CTalentController:getCurTalentTotalLevel()), currId
end

------------------------------------协议相关----------------------------------------
function CDiamondGiftMgr:buyGiftCallback(player, packet)
    local resultInfo = packet.resultInfo

    if resultInfo.result then
        local text = ""
        GameActivityShowReward.builder()
                              .setBottomTip(text)
                              .setRewardView(resultInfo.results)
                              .setHideLeftButton()
                              .setRightButton("common.activity.sure")
                              .setRightClickListener(function()
        end)
                              .show()
    else
    end
end

return CDiamondGiftMgr