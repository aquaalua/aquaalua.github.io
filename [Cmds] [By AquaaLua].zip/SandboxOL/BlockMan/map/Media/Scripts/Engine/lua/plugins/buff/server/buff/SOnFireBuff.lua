local PlayerListener = T(Global, "PlayerListener")

---@type SBaseBuff
local SBaseBuff = Plugins.Require("buff", "server.buff.SBaseBuff")

---@class SOnFireBuff : SBaseBuff
local SOnFireBuff = class("SOnFireBuff", SBaseBuff)

function SOnFireBuff.syncAllPlayer()
    return true
end

function SOnFireBuff:onCreate()
    self.harmValue = tonumber(self.config.param[1])
    self.replyHpDebuff = tonumber(self.config.param[2]) / 100.0
    self.addTick = tonumber(self.config.param[3])
    local player = PlayerManager:getPlayerByUserId(self.targetId)
    player.subReplyFire = self.replyHpDebuff
    self:calcLessEndTime()
end

function SOnFireBuff:onTick()
    SBaseBuff.onTick(self)
    if self.curTick % self.addTick == 0 then
        ---@type SBasePlayer
        local player = PlayerManager:getPlayerByUserId(self.targetId)
        if player then
            if player:getHealth() > 0 then
                player:subHealth(self.harmValue)
            end
        end
    end
end

function SOnFireBuff:onRemove()
    local player = PlayerManager:getPlayerByUserId(self.targetId)
    player.subReplyFire = nil
end

function SOnFireBuff:onTimesUp()
    local player = PlayerManager:getPlayerByUserId(self.targetId)
    player.subReplyFire = nil
end

return SOnFireBuff