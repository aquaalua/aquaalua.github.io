---@type SBasePlayer
local handler = T(Global, "PacketHandlers")

---@type SMainActivity
local MainActivity = Plugins.Require("activity", "server.MainActivity")

function handler:ToActivityPacket(packet)
    local activityMgr = MainActivity:getActivity(packet.activityId)
    if activityMgr and activityMgr[packet.funcName] then
        activityMgr[packet.funcName](activityMgr, self, packet)
    else
        LogUtil.logError(string.format("ToActivityPacket Error ,activityMgr not exist , activityId = %d", packet.activityId))
    end
end