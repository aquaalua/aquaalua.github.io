---@class LuckyTurntableDBData
local initLuckyTurntableData = {
    lastLotteryDay = 0,
    lotteryTimes = 0,
    haveGot = {},
}

---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@type LuckyTurntableConfig
local LuckyTurntableConfig = Plugins.Require("activity", "common.config.LuckyTurntableConfig")

---@type SBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "server.mode.BaseActivityMgr")

---@class SLuckyTurntableMgr : SBaseActivityMgr
local LuckyTurntableMgr = class("SLuckyDiskMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.LuckyTurntable, LuckyTurntableMgr, LuckyTurntableConfig)

----------------------------------------------------------------------------------
---@param mgrConfig LuckyTurntableData
function LuckyTurntableMgr:initActivity(mgrConfig)
    self.config = mgrConfig
end

---@param player SBasePlayer
function LuckyTurntableMgr:initPlayerCache(player, data)
    data = data or {}
    local cache = {}
    for key, default in pairs(TableUtil.copyTable(initLuckyTurntableData)) do
        cache[key] = data[key] or default
    end
    self:setPlayerCache(player, cache)
end

-------------------------------------功能相关---------------------------------------------------

---@return LuckyDiskRewardConfig[]
function LuckyTurntableMgr:getRewardCfg()
    return self.config.rewardCfg
end

---@param player SBasePlayer
function LuckyTurntableMgr:randomReward(player)
    local cache = self:getPlayerCache(player)
    cache.lotteryTimes = cache.lotteryTimes + 1
    cache.lastLotteryDay = DateUtil.getUTCDayStartTime(os.time())
    local haveGot = cache.haveGot

    local excessWeights = 0
    local overflow = {}
    for _, reward in pairs(self.config.rewardCfg) do
        if reward.limitCount and haveGot[tostring(reward.id)] and haveGot[tostring(reward.id)] >= reward.limitCount then
            excessWeights = excessWeights + reward.weight
            overflow[tostring(reward.id)] = true
        end
    end

    local random = HostApi.random("LuckyTurntable", 1, self.config.weights - excessWeights + 1)
    local weights = 0
    ---@type LuckyTurntableRewardData
    local select
    for _, reward in pairs(self.config.rewardCfg) do
        if not overflow[tostring(reward.id)] then
            weights = weights + reward.weight
            if weights >= random then
                select = reward
                if reward.limitCount then
                    if haveGot[tostring(reward.id)] then
                        haveGot[tostring(reward.id)] = haveGot[tostring(reward.id)] + 1
                    else
                        haveGot[tostring(reward.id)] = 1
                    end
                end
                break
            end
        end
    end

    local rewardCfg = select
    local realReward = self:receiveReward(player, rewardCfg.reward)
    if realReward then
        ReportEvent.activity_lucky_disk_buy(player, self.mainConfig.id, rewardCfg.reward.rewardId)
        player:sendPacket({
            pid = "GameActivityShowReward",
            rewards = {
                { rewardId = realReward.realRewardId or realReward.rewardId, num = rewardCfg.reward.num }
            },
        })
    end
    cache.haveGot = haveGot
    self:setPlayerCache(player, cache)
end

function LuckyTurntableMgr:getLotteryPrice(player)
    local price = self.config.price
    local cache = self:getPlayerCache(player)
    if cache.lastLotteryDay < DateUtil.getUTCDayStartTime(os.time()) then
        price = math.floor(price / 2)
    end
    return price
end

---@param player SBasePlayer
function LuckyTurntableMgr:buy(player)
    local cache = self:getPlayerCache(player)
    local haveGot = cache.haveGot
    local excessWeights = 0
    for _, reward in pairs(self.config.rewardCfg) do
        if reward.limitCount and haveGot[tostring(reward.id)] and haveGot[tostring(reward.id)] >= reward.limitCount then
            excessWeights = excessWeights + reward.weight
        end
    end
    if excessWeights >= self.config.weights then
        return
    end

    self:payMoney(player, self.config.uniqueId, self.config.type, self:getLotteryPrice(player), function()
        self:randomReward(player)
    end)
end

return LuckyTurntableMgr