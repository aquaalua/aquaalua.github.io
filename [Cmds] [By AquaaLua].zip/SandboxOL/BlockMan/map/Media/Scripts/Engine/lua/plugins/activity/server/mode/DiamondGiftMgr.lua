---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

local initData = {
    buyTimes = {}
}

---@type DiamondGiftRewardConfig
local DiamondGiftRewardConfig = Plugins.Require("activity", "common.config.DiamondGiftRewardConfig")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")
---@type EmojiConfig
local EmojiConfig = T(Global, "EmojiConfig")

---@type SBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "server.mode.BaseActivityMgr")

---@class SDiamondGiftMgr : SBaseActivityMgr
local SDiamondGiftMgr = class("SDiamondGiftMgr", BaseActivityMgr)

---@type EventUtil
local EventUtil = T(Global, "EventUtil")

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.DiamondGiftReward, SDiamondGiftMgr, DiamondGiftRewardConfig)

----------------------------------------------------------------------------------
---@param mgrConfig RandomStoreConfigData
function SDiamondGiftMgr:initActivity(mgrConfig)
    EventUtil.goObjEvent(self)
    ---@type RandomStoreGroupData[]
    self.config = mgrConfig
end

---@param player SBasePlayer
function SDiamondGiftMgr:initPlayerCache(player, data)
    if not data or data.activityId ~= self.mainConfig.activityId then
        data = {}
    end
    local cache = {}
    for key, default in pairs(initData) do
        cache[key] = data[key] or TableUtil.cloneData(default)
    end
    cache.activityId = self.mainConfig.activityId
    self:setPlayerCache(player, cache)
end

---@param player SBasePlayer
function SDiamondGiftMgr:initMgrDBDataFinished(player)
    ---@type RandomStoreDBData
    local cache = self:getPlayerCache(player)
    self:setPlayerCache(player, cache)
end

-------------------------------------功能相关---------------------------------------------------
---@param player SBasePlayer
function SDiamondGiftMgr:buyGoods(player, packet)
    local id = packet.id
    local cfg = DiamondGiftRewardConfig:getConfigById(id)
    ---@type RandomStoreDBData
    local cache = self:getPlayerCache(player)

    if not cfg then
        LogUtil.logError("buy error, no random store config", StringUtil.v2s(packet))
        return
    end

    if player.isTryBugDiamondGift then
        return
    end

    cache.buyTimes[tostring(id)] = cache.buyTimes[tostring(id)] or 0
    local times = cache.buyTimes[tostring(id)] or 0
    if times >= cfg.times then

        return
    end

    player.isTryBugDiamondGift = true

    self:payMoney(player, cfg.uniqueId, cfg.moneyType, cfg.price, function()
        player.isTryBugDiamondGift = nil
        cache.buyTimes[tostring(id)] = cache.buyTimes[tostring(id)] + 1
        self:setPlayerCache(player, cache)

        local rewardList = self:getRewardGroupById(cfg.rewardGroupId)

        --LogUtil.logInfo("rewardList ", cfg.rewardGroupId, StringUtil.v2s(rewardList, 2))
        local results = {}
        for i, reward in ipairs(rewardList) do
            local realReward = self:receiveReward(player, reward.reward)
            --LogUtil.logInfo("send reward ", StringUtil.v2s(reward.reward, 4), StringUtil.v2s(realReward, 4))
            if realReward then
                table.insert(results, { rewardId = realReward.rewardId, isGrandPrize = reward.reward.isGrandPrize })
            end
        end

        local resultInfo = {
            results = results,
            id = id,
            result = true,
        }

        player:sendPacket({
            pid = "ToActivityPacket",
            activityId = self.mainConfig.id,
            funcName = "buyGiftCallback",
            resultInfo = resultInfo
        })

    end, function()
        player.isTryBugDiamondGift = nil

        player:sendPacket({
            pid = "ToActivityPacket",
            activityId = self.mainConfig.id,
            funcName = "buyGiftCallback",
            resultInfo = {
                id = id,
                result = false,
            }
        })
    end)
end

return SDiamondGiftMgr