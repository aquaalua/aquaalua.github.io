---@class GameMsgRecord
local GameMsgRecord = T(Global, "GameMsgRecord")
---指令列表
local OrderList = {}
---聊天记录
local ChatRecord = {}

local function initChatRecord(name, text)
    local chat = {
        name = name,
        text = text,
    }
    return chat
end

local function initOrderRecord(orderIndex, text)
    local order = {
        index = orderIndex,
        text = text,
    }
    return order
end

function GameMsgRecord:addChatRecord(name, text)
    local record = initChatRecord(name, text)
    table.insert(ChatRecord, record)
    return #ChatRecord
end

function GameMsgRecord:addOrderList(teamId, orderId)
    local record = initOrderRecord(teamId, orderId)
    if OrderList[tostring(teamId)] == nil then
        OrderList[tostring(teamId)] = {}
    end
    table.insert(OrderList[tostring(teamId)], record)
    return #OrderList[tostring(teamId)]
end