
---@class RandomStoreDBData
local initRandomStoreData = {
    storeList = {},
    buyRecord = {},
    randomRecord = {},
    refreshTime = 0
}

---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@type RandomStoreConfig
local RandomStoreConfig = Plugins.Require("activity", "common.config.RandomStoreConfig")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")
---@type EmojiConfig
local EmojiConfig = T(Global, "EmojiConfig")

---@type SBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "server.mode.BaseActivityMgr")

---@class SRandomStoreMgr : SBaseActivityMgr
local RandomStoreMgr = class("SRandomStoreMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.RandomStore, RandomStoreMgr, RandomStoreConfig)

----------------------------------------------------------------------------------
---@param mgrConfig RandomStoreConfigData
function RandomStoreMgr:initActivity(mgrConfig)
    ---@type RandomStoreGroupData[]
    self.config = mgrConfig
end

local function canBuyDress(player, item)
    local realReward = CommonActivityConfig:getRewardById(item.rewardId)
    if realReward.type == "CustomShop" then
        local goods = CustomShopConfig:getGoodsConfig(realReward.realId)
        local group = player.custom_goods[tostring(goods.TabId)] or {}
        for _, _goods in pairs(group) do
            if _goods[CustomGoodsIndex.Id] == goods.Id then
                if _goods[CustomGoodsIndex.Time] == -1 then
                    return false ---已购买，无需购买
                end
            end
        end
    elseif realReward.type == "RewardSetting" then
        local rewardConfig = RewardConfig:getRewardById(realReward.realId)
        if not rewardConfig then
            return false
        end
        if rewardConfig.RewardType == Define.RewardType.HEAD_IMAGE then
            if player.headImageData and TableUtil.tableContain(player.headImageData, rewardConfig.RewardId) then
                LogUtil.logInfo("false head image", item.rewardId)
                return false
            end
        elseif rewardConfig.RewardType == Define.RewardType.EMOJI then
            local cfg = EmojiConfig:getCfgByRewardId(rewardConfig.RewardId)
            if not cfg then
                return false
            end
            local id = tostring(cfg.id)
            if player.emojiData and player.emojiData[id] then
                LogUtil.logInfo("false emoji", item.rewardId)
                return false
            end
        elseif rewardConfig.RewardType == Define.RewardType.HEAD_FRAME then
            if player.headFrameData and TableUtil.tableContain(player.headFrameData, rewardConfig.RewardId) then
                LogUtil.logInfo("false head frame", item.rewardId)
                return false
            end
        elseif rewardConfig.RewardType == Define.RewardType.BACKGROUND then
            if player.backgroundData and TableUtil.tableContain(player.backgroundData, rewardConfig.RewardId) then
                LogUtil.logInfo("false background", item.rewardId)
                return true
            end
        end
    end
    return true
end

local function rand(player, cache, groupId, count, noRecord)
    local pool = {}
    for _, item in pairs(RandomStoreConfig:getGroupPool(groupId) or {}) do
        if not cache.buyRecord[tostring(item.id)] and canBuyDress(player, item) then
            if noRecord or not cache.randomRecord[tostring(item.id)] then
                if noRecord and cache.randomRecord[tostring(item.id)] then
                    cache.randomRecord[tostring(item.id)] = nil
                end
                table.insert(pool, TableUtil.copyTable(item))
            end
        end
    end
    local randomList = RandomStoreConfig:randomWeightsPool(pool, count, true)
    for _, item in pairs(randomList or {}) do
        cache.randomRecord[tostring(item.id)] = 1
        table.insert(cache.storeList, {
            id = item.id,
            buyCount = 0
        })
    end
    return randomList and #randomList or 0
end

---@param player SBasePlayer
function RandomStoreMgr:initPlayerCache(player, data)
    if not data or data.activityId ~= self.mainConfig.activityId then
        data = {}
    end
    local cache = {}
    for key, default in pairs(initRandomStoreData) do
        cache[key] = data[key] or TableUtil.cloneData(default)
    end
    cache.activityId = self.mainConfig.activityId
    self:setPlayerCache(player, cache)
end

---@param player SBasePlayer
function RandomStoreMgr:initMgrDBDataFinished(player)
    ---@type RandomStoreDBData
    local cache = self:getPlayerCache(player)
    --如果玩家的刷新时间小于当天0时，就重刷
    if cache.refreshTime < DateUtil.getGreenwichDayLastTime() - 86400 then
    --if cache.refreshTime < DateUtil.getGreenwichDayLastTime() then
        cache.refreshTime = os.time()
        cache.storeList = {}
        --todo 重刷
        for _, group in pairs(self.config) do
            local retCount = rand(player, cache, group.groupId, group.randomCount)
            --随机出来的结果不够，就继续随机
            if retCount < group.randomCount then
                rand(player, cache, group.groupId, group.randomCount - retCount, true)
            end
        end
    end
    self:setPlayerCache(player, cache)
end

-------------------------------------功能相关---------------------------------------------------
---@param player SBasePlayer
function RandomStoreMgr:buyGoods(player, packet)
    local id = packet.id
    local cfg, index
    ---@type RandomStoreDBData
    local cache = self:getPlayerCache(player)
    for i, info in pairs(cache.storeList) do
        if info.id == id then
            cfg = RandomStoreConfig:getRewardById(info.id)
            if info.buyCount >= cfg.limitCount then
                LogUtil.logError("buy count limit", StringUtil.v2s(info))
                return
            end
            index = i
            break
        end
    end
    if not cfg then
        LogUtil.logError("buy error, no random store config", StringUtil.v2s(packet))
        return
    end
    local groupCfg = RandomStoreConfig:getGroupCfg(cfg.groupId)
    self:payMoney(player, groupCfg.uniqueId, cfg.moneyType, cfg.price, function()
        cache.storeList[index].buyCount = cache.storeList[index].buyCount + 1
        if not cfg.canReBuy then
            cache.buyRecord[tostring(id)] = 1
        end
        self:setPlayerCache(player, cache)

        local reward = TableUtil.copyTable(CommonActivityConfig:getRewardById(cfg.rewardId))
        reward.num = cfg.rewardCount
        local realReward = self:receiveReward(player, reward)
        if realReward then
            player:sendPacket({
                pid = "GameActivityShowReward",
                rewards = {
                    { rewardId = realReward.realRewardId or realReward.rewardId, num = reward.num }
                },
            })
            self:setPlayerCache(player, cache)
        end
        ReportEvent.activity_random_store_buy(player, self.mainConfig.activityId, cfg.rewardId)
    end)
end

---@param player SBasePlayer
function RandomStoreMgr:updateLastOpenUIDate(player)
    local t = os.date("*t")
    local timestamp = DateUtil.date2BeiJingTime({ year = t.year, month = t.month, day = t.day, hour = 0, min = 0, sec = 0 })
    local cache = self:getPlayerCache(player)
    if cache.lastDateOpenUI ~= timestamp then
        cache.lastDateOpenUI = timestamp
        self:setPlayerCache(player, cache)
        ReportEvent.activity_level_open_ui(player, self.mainConfig.id)
    end
end

return RandomStoreMgr