--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
ItemID = {}

ItemID.NULL                 = 0
ItemID.SHOVEL_IRON          = 256
ItemID.PICKAXE_IRON         = 257
ItemID.AXE_IRON             = 258
ItemID.FLINT_AND_STEEL      = 259
ItemID.APPLE_RED            = 260
ItemID.BOW                  = 261
ItemID.ARROW                = 262
ItemID.COAL                 = 263
ItemID.DIAMOND              = 264
ItemID.INGOT_IRON           = 265
ItemID.INGOT_GOLD           = 266
ItemID.SWORD_IRON           = 267
ItemID.SWORD_WOOD           = 268
ItemID.SHOVEL_WOOD          = 269
ItemID.PICKAXE_WOOD         = 270
ItemID.AXE_WOOD             = 271
ItemID.SWORD_STONE          = 272
ItemID.SHOVEL_STONE         = 273
ItemID.PICKAXE_STONE        = 274
ItemID.AXE_STONE            = 275
ItemID.SWORD_DIAMOND        = 276
ItemID.SHOVEL_DIAMOND       = 277
ItemID.PICKAXE_DIAMOND      = 278
ItemID.AXE_DIAMOND          = 279
ItemID.STICK                = 280
ItemID.BOWL_EMPTY           = 281
ItemID.BOWL_SOUP            = 282
ItemID.SWORD_GOLD           = 283
ItemID.SHOVEL_GOLD          = 284
ItemID.PICK_AXE_GOLD        = 285
ItemID.AXE_GOLD             = 286
ItemID.SILK                 = 287
ItemID.FEATHER              = 288
ItemID.GUN_POWDER           = 289
ItemID.HOE_WOOD             = 290
ItemID.HOE_STONE            = 291
ItemID.HOE_IRON             = 292
ItemID.HOE_DIAMOND          = 293
ItemID.HOE_GOLD             = 294
ItemID.SEEDS                = 295
ItemID.WHEAT                = 296
ItemID.BREAD                = 297
ItemID.HELMET_LEATHER       = 298
ItemID.PLATE_LEATHER        = 299
ItemID.LEGS_LEATHER         = 300
ItemID.BOOTS_LEATHER        = 301
ItemID.HELMET_CHAIN         = 302
ItemID.PLATE_CHAIN          = 303
ItemID.LEGS_CHAIN           = 304
ItemID.BOOTS_CHAIN          = 305
ItemID.HELMET_IRON          = 306
ItemID.PLATE_IRON           = 307
ItemID.LEGS_IRON            = 308
ItemID.BOOTS_IRON           = 309
ItemID.HELMET_DIAMOND       = 310
ItemID.PLATE_DIAMOND        = 311
ItemID.LEGS_DIAMOND         = 312
ItemID.BOOTS_DIAMOND        = 313
ItemID.HELMET_GOLD          = 314
ItemID.PLATE_GOLD           = 315
ItemID.LEGS_GOLD            = 316
ItemID.BOOTS_GOLD           = 317
ItemID.FLINT                = 318
ItemID.PORK_RAW             = 319
ItemID.PORK_COOKED          = 320
ItemID.PAINTING             = 321
ItemID.APPLE_GOLD           = 322
ItemID.SIGN                 = 323
ItemID.DOOR_WOOD            = 324
ItemID.BUCKET_EMPTY         = 325
ItemID.BUCKET_WATER         = 326
ItemID.BUCKET_LAVA          = 327
ItemID.BLOCKMAN_EMPTY       = 328
ItemID.SADDLE               = 329
ItemID.DOOR_IRON            = 330
ItemID.RED_STONE            = 331
ItemID.SNOWBALL             = 332
ItemID.BOAT                 = 333
ItemID.LEATHER              = 334
ItemID.BUCKET_MILK          = 335
ItemID.BRICK                = 336
ItemID.CLAY                 = 337
ItemID.REED                 = 338
ItemID.PAPER                = 339
ItemID.BOOK                 = 340
ItemID.SLIME_BALL           = 341
ItemID.BLOCKMAN_CRATE       = 342
ItemID.BLOCKMAN_POWERED     = 343
ItemID.EGG                  = 344
ItemID.COMPASS              = 345
ItemID.FISHING_ROD          = 346
ItemID.POCKET_SUNDIAL       = 347
ItemID.GLOW_STONE           = 348
ItemID.FISH_RAW             = 349
ItemID.FISH_COOKED          = 350
ItemID.DYE_POWDER           = 351
ItemID.BONE                 = 352
ItemID.SUGAR                = 353
ItemID.CAKE                 = 354
ItemID.BED                  = 355
ItemID.RED_STONE_REPEATER   = 356
ItemID.COOKIE               = 357
ItemID.IMAP                 = 358
ItemID.SHEARS               = 359
ItemID.MELON                = 360
ItemID.PUMPKIN_SEEDS        = 361
ItemID.MELON_SEEDS          = 362
ItemID.BEEF_RAW             = 363
ItemID.BEEF_COOKED          = 364
ItemID.CHICKEN_RAW          = 365
ItemID.CHICKEN_COOKED       = 366
ItemID.ROTTEN_FLESH         = 367
ItemID.ENDER_PEARL          = 368
ItemID.BLAZE_ROD            = 369
ItemID.GHAST_TEAR           = 370
ItemID.GOLD_NUGGET          = 371
ItemID.NETHER_STALK_SEEDS   = 372
ItemID.POTION               = 373
ItemID.GLASS_BOTTLE         = 374
ItemID.SPIDER_EYE           = 375
ItemID.FERMENTED_SPIDER_EYE = 376
ItemID.BLAZE_POWDER         = 377
ItemID.MAGMA_CREAM          = 378
ItemID.BREWING_STAND        = 379
ItemID.CAULDRON             = 380
ItemID.EYE_OF_ENDER         = 381
ItemID.SPECKLED_MELON       = 382
ItemID.MONSTER_PLACER       = 383
ItemID.EXP_BOTTLE           = 384
ItemID.FIREBALL_CHARGE      = 385
ItemID.WRITABLE_BOOK        = 386
ItemID.WRITTEN_BOOK         = 387
ItemID.EMERALD              = 388
ItemID.ITEM_FRAME           = 389
ItemID.FLOWER_POT           = 390
ItemID.CARROT               = 391
ItemID.POTATO               = 392
ItemID.BAKED_POTATO         = 393
ItemID.POISONOUS_POTATO     = 394
ItemID.EMPTY_MAP            = 395
ItemID.GOLDEN_CARROT        = 396
ItemID.SKULL                = 397
ItemID.CARROT_ON_STICK      = 398
ItemID.NETHER_STAR          = 399
ItemID.PUMPKIN_PIE          = 400
ItemID.FIREWORK             = 401
ItemID.FIREWORK_CHARGE      = 402
ItemID.ENCHANTED_BOOK       = 403
ItemID.COMPARATOR           = 404
ItemID.NETHERRACK_BRICK     = 405
ItemID.NETHER_QUARTZ        = 406
ItemID.BLOCKMAN_TNT         = 407
ItemID.BLOCKMAN_HOPPER      = 408

ItemID.RABBIT_COOKED        = 412

ItemID.IRON_HORSE_ARMOR     = 417
ItemID.GOLDEN_HORSE_ARMOR   = 418
ItemID.DIAMOND_HORSE_ARMOR  = 419
ItemID.LEAD                 = 420
ItemID.NAME_TAG             = 421
ItemID.GRENADE              = 425

ItemID.HAND_CUFFS           = 451
ItemID.TELEPORTHOME			= 462

ItemID.GOLD_HEART           = 498
ItemID.GOLD_SHOES           = 499
ItemID.GOLD_ARROW           = 500
ItemID.QUESTION_MARK        = 501
ItemID.PROP_GOLD            = 502
ItemID.PROP_EXP             = 503

ItemID.PROP_RSTEP           = 504
ItemID.PROP_IGNORE          = 505
ItemID.FLARE_BOMB			= 506
ItemID.RESCUE				= 507
ItemID.GOLD_APPLE			= 508
ItemID.CURRENCY_MONEY       = 509

ItemID.POTION_INVISIBILITY  		= 512
ItemID.POTION_LONGINVISIBILITY 		= 513
ItemID.POTION_JUMP  				= 514
ItemID.POTION_LONGJUMP  			= 515
ItemID.POTION_STRONGJUMP  			= 516
ItemID.POTION_HEAL  				= 517
ItemID.POTION_STRONGHEAL  			= 518
ItemID.POTION_MOVESPEED  			= 519
ItemID.POTION_LONGMOVESPEED 		= 520
ItemID.POTION_STRONGMOVESPEED  		= 521
ItemID.POTION_POISON  				= 522
ItemID.POTION_LONGPOISON  			= 523
ItemID.POTION_STRONGPOISON  		= 524
ItemID.POTION_NIGHTVISION  			= 525
ItemID.POTION_LONGNIGHTVISION  		= 526
ItemID.POTION_SPLASH_HEAL  			= 527
ItemID.POTION_SPLASH_STRONG_HEAL  	= 528
ItemID.POTION_SPLASH_POISON  		= 529
ItemID.POTION_SPLASH_LONGPOISON  	= 530
ItemID.POTION_SPLASH_STRONGPOISON  	= 531

ItemID.GRENADE_TREMOR       = 769
ItemID.FROZEN_BALL          = 770

ItemID.HAND_GRENADE			= 2001
ItemID.EXPLOSION_ARROW		= 2002
ItemID.AXE_PURPLE			= 2247
ItemID.SHOVEL_PURPLE		= 2248
ItemID.PICKAXE_PURPLE		= 2249
ItemID.HOE_PURPLE			= 2252
ItemID.STAR_GUN				= 2337

ItemID.VIRUSCRYSTAL			= 3458
ItemID.LIFECRYSTAL			= 3459

---@param self Item | number
Item.isBlockItem = function(self)
    if type(self) == "number" then
        self = Item.getItemById(self)
    end
    if not self then
        return false
    end
    local class = self:getClassName()
    if class == "ItemBlock"
            or class == "ItemCloth"
            or class == "ItemStone"
            or class == "ItemPiston"
            or class == "ItemBlockImp"
            or class == "ItemMultiTextureTile" then
        return true
    end
    return false
end

--endregion
