---@class UIChickenBoxLayout : IGUILayout
local UIChickenBoxLayout = class("UIChickenBoxLayout", IGUILayout)
---@type CChickenBoxMgr
local CChickenBoxMgr = T(Global, "CChickenBoxMgr")

---@private
function UIChickenBoxLayout:ctor(parent)
    self.super.ctor(self, "ChickenBox.json", parent)
end

---@private
function UIChickenBoxLayout:isDelayLoad()
    return true
end

---@private
function UIChickenBoxLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIChickenBoxLayout:initCreateEvent()

end

---@private
function UIChickenBoxLayout:onLoad()
    self.llResourceBox = self:getChildWindow("ChickenBox-Resource-Box", GUIType.Layout)
    self.llResourceItems = self:getChildWindow("ChickenBox-Resource-Items", GUIType.Layout)
    self.btnResourceClose = self:getChildWindow("ChickenBox-Resource-Close", GUIType.Button)
    self.stResourceName = self:getChildWindow("ChickenBox-Resource-Name", GUIType.StaticText)

    self.llDropBox = self:getChildWindow("ChickenBox-Drop-Box", GUIType.Layout)
    self.llDropItems = self:getChildWindow("ChickenBox-Drop-Items", GUIType.Layout)
    self.btnDropClose = self:getChildWindow("ChickenBox-Drop-Close", GUIType.Button)
    self.stDropName = self:getChildWindow("ChickenBox-Drop-Name", GUIType.StaticText)

    self.llResourceBox:SetVisible(false)
    self.llDropBox:SetVisible(false)
    self:initView()
    self:initEvent()
end

---@private
function UIChickenBoxLayout:initView()
    self.gvBoxList = IGUIGridView.new("ChickenBox-Resource-Box-List", self.llResourceItems)
    self.gvBoxList:setArea({ 0, 0 }, { 0, 0 }, { 1.0, 0 }, { 1.0, 0 })
    self.gvBoxList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.gvBoxList:setConfig(12, 12, 2)
    local width = (self.gvBoxList:getWidth() - 12) / 2
    ---@type ChickenResourceBoxItemAdapter
    self.resourceBoxAdapter = UIHelper.newGameAdapter("ChickenResourceBoxItemAdapter")
    self.resourceBoxAdapter:setItemSize(width, 91)
    self.gvBoxList:setAdapter(self.resourceBoxAdapter)

    self.gvItemList = IGUIGridView.new("ChickenBox-Resource-Item-List", self.llDropItems)
    self.gvItemList:setArea({ 0, 0 }, { 0, 0 }, { 1.0, 0 }, { 1.0, 0 })
    self.gvItemList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.gvItemList:setConfig(12, 12, 1)
    ---@type ChickenResourceBoxItemAdapter
    self.dropItemAdapter = UIHelper.newGameAdapter("ChickenResourceBoxItemAdapter")
    self.dropItemAdapter:setItemSize(self.gvItemList:getWidth(), 91)
    self.gvItemList:setAdapter(self.dropItemAdapter)
end

---@private
function UIChickenBoxLayout:initEvent()
    self.btnResourceClose:registerEvent(GUIEvent.ButtonClick, function()
        self.llResourceBox:SetVisible(false)
        CChickenBoxMgr:removeOpenSeqBox()
    end)

    self.btnDropClose:registerEvent(GUIEvent.ButtonClick, function()
        self.llDropBox:SetVisible(false)
    end)
end

function UIChickenBoxLayout:openResourceBoxList(data)
    if not self.llResourceBox then
        return
    end
    if #data <= 2 then
        self.llResourceBox:SetHeight({ 0, 150 })
    elseif #data <= 4 then
        self.llResourceBox:SetHeight({ 0, 240 })
    else
        self.llResourceBox:SetHeight({ 0, 270 })
    end

    self.llResourceBox:SetVisible(true)
    self.resourceBoxAdapter:setData(data, true)
end

function UIChickenBoxLayout:closeResourceBoxList()
    if not self.llResourceBox then
        return
    end
    self.llResourceBox:SetVisible(false)
end

function UIChickenBoxLayout:openGroundItemList(data)
    if not self.llDropBox then
        return
    end
    if #data <= 1 then
        self.llDropBox:SetHeight({ 0, 150 })
    elseif #data <= 2 then
        self.llDropBox:SetHeight({ 0, 240 })
    else
        self.llDropBox:SetHeight({ 0, 270 })
    end

    self.llDropBox:SetVisible(true)
    self.dropItemAdapter:setData(data, true)
end

function UIChickenBoxLayout:closeGroundItemList()
    if not self.llDropBox then
        return
    end
    self.llDropBox:SetVisible(false)
end

return UIChickenBoxLayout