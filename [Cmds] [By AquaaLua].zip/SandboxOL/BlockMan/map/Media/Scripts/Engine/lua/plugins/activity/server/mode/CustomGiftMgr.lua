
---@class CustomGiftDBData
local initCustomGiftDBData = {
    chooseData = {},
    buyCountRecord = {}
}

---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")
---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")
---@type CustomGiftConfig
local CustomGiftConfig = Plugins.Require("activity", "common.config.CustomGiftConfig")
---@type SBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "server.mode.BaseActivityMgr")

---@class SCustomGiftMgr : SBaseActivityMgr
local SCustomGiftMgr = class("SCustomGiftMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.CustomGift, SCustomGiftMgr, CustomGiftConfig)

----------------------------------------------------------------------------------
---@param mgrConfig RandomStoreConfigData
function SCustomGiftMgr:initActivity(mgrConfig)
    ---@type RandomStoreGroupData[]
    self.config = mgrConfig
end

---@param player SBasePlayer
function SCustomGiftMgr:initPlayerCache(player, data)
    if not data or data.activityId ~= self.mainConfig.activityId then
        data = {}
    end
    local cache = {}
    for key, default in pairs(initCustomGiftDBData) do
        cache[key] = data[key] or TableUtil.cloneData(default)
    end
    cache.activityId = self.mainConfig.activityId
    self:setPlayerCache(player, cache)
end

---@param player SBasePlayer
function SCustomGiftMgr:initMgrDBDataFinished(player)
    ---@type RandomStoreDBData
    local cache = self:getPlayerCache(player)
    self:setPlayerCache(player, cache)
end
-------------------------------------功能相关---------------------------------------------------

function SCustomGiftMgr:C2SSubmitChooseResult(player, data)
    local chooseChangeData = data.chooseChangeData
    local cache = self:getPlayerCache(player)
    local chooseData = cache.chooseData
    if not chooseData then
        chooseData = {}
        cache.chooseData = chooseData
    end
    local giftChooseData = chooseData[chooseChangeData.giftId]
    if not giftChooseData then
        giftChooseData = {}
        chooseData[chooseChangeData.giftId] = giftChooseData
    end
    for cellId, index in pairs(chooseChangeData.cellIndexMap or {}) do
        giftChooseData[cellId] = index
    end
    self:setPlayerCache(player, cache)
end

---@param player SBasePlayer
function SCustomGiftMgr:C2SBuyCustomGift(player, packet)
    local giftId = packet.giftId
    local giftConfig = CustomGiftConfig:getCustomGiftCfgById(packet.activityId, giftId)
    if not giftConfig then
        LogUtil.logWarning("not giftConfig giftId: ", giftId)
        return
    end
    local cache = self:getPlayerCache(player)
    local buyCount = cache.buyCountRecord[giftId] or 0
    if buyCount >= giftConfig.limitBuyCount then
        LogUtil.logWarning(" buy limit count giftId :", giftId)
        return
    end
    cache.buyCountRecord[giftId] = buyCount + 1
    self:payMoney(player, giftConfig.orderId, Define.Money.DIAMOND, giftConfig.price, function()
        local rewardList = {}
        local rewardStrList = {}
        local giftChooseData = cache.chooseData[giftId] or {}
        for _, cellId in pairs(giftConfig.rewardCellList or {}) do
            local rewardIndex = giftChooseData[cellId] or 0
            local rewardData = CustomGiftConfig:getCellRewardDataByIndex(cellId, rewardIndex)
            table.insert(rewardStrList, string.format("%s,%s", rewardData.rewardId, rewardData.num))
            table.insert(rewardList, rewardData)
        end
        local showRewards = {}
        for _, rewardData in pairs(rewardList) do
            local reward = TableUtil.copyTable(CommonActivityConfig:getRewardById(rewardData.rewardId))
            reward.num = rewardData.num
            local realReward = self:receiveReward(player, reward)
            if realReward then
                table.insert(showRewards, {
                    rewardId = realReward.realRewardId or realReward.rewardId,
                    num = reward.num
                })
            end
        end
        player:sendPacket({
            pid = "GameActivityShowReward",
            rewards = showRewards,
        })
        self:setPlayerCache(player, cache)
        ReportEvent.reportEvent(player.userId, "activity_custom_gift_buy", false, {
            order_id = giftConfig.orderId,
            custom_gift_rewards = table.concat(rewardStrList, "#"),
        })
    end)
end

function SCustomGiftMgr:resetCustomGiftData(player)
    local cache = self:getPlayerCache(player)
    cache.chooseData = {}
    cache.buyCountRecord = {}
    self:setPlayerCache(player, cache)
end



return SCustomGiftMgr