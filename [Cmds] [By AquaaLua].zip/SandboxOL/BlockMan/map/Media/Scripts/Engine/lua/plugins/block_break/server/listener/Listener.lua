---@type BlockBreakManager
local BlockBreakManager = T(Global, "BlockBreakManager")
---@type BlockBreakConfig
local BlockBreakConfig = T(Global, "BlockBreakConfig")

local functionMap = {}
local function init()
    CEvents.BlockBreakWithGunEvent:registerCallBack(functionMap["BlockBreakWithGunEvent"])
end

functionMap["BlockBreakWithGunEvent"] = function(rakssid, blockId, blockPos, gunId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    if BlockBreakConfig:inSafeArea(blockPos) then
        return false
    end
    return BlockBreakManager:onPlayerShootBlock(player, blockPos, blockId, gunId)
end

init()
