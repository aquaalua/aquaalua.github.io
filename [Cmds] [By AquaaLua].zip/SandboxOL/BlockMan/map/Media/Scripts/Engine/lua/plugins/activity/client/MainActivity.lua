---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")
---@type BlindBoxLotteryConfig
local BlindBoxConfig = Plugins.Require("activity", "common.config.BlindBoxConfig")

---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")
Plugins.Require("activity", "client.mode.LuckyLotteryMgr")
Plugins.Require("activity", "client.mode.MustLotteryMgr")
Plugins.Require("activity", "client.mode.BlindBoxMgr")
Plugins.Require("activity", "client.mode.ScoreActivityMgr")
Plugins.Require("activity", "client.mode.AtLessLotteryMgr")
Plugins.Require("activity", "client.mode.DiscountShopActivityMgr")
Plugins.Require("activity", "client.mode.LimitDiscountShopMgr")
Plugins.Require("activity", "client.mode.CardLotteryMgr")
Plugins.Require("activity", "client.mode.TurntableActivityMgr")
Plugins.Require("activity", "client.mode.PicturePuzzleActivityMgr")
Plugins.Require("activity", "client.mode.TreasureBoxMgr")
Plugins.Require("activity", "client.mode.LevelActivityMgr")
Plugins.Require("activity", "client.mode.SurprisePackMgr")
Plugins.Require("activity", "client.mode.DirectSaleMgr")
Plugins.Require("activity", "client.mode.RandomStoreMgr")
Plugins.Require("activity", "client.mode.AceMinerMgr")
Plugins.Require("activity", "client.mode.DiamondConsumeRewardMgr")
Plugins.Require("activity", "client.mode.LuckyDiskMgr")
Plugins.Require("activity", "client.mode.ShopManMgr")
Plugins.Require("activity", "client.mode.LuckyTurntableMgr")
Plugins.Require("activity", "client.mode.DiamondGiftMgr")
Plugins.Require("activity", "client.mode.CustomGiftMgr")
Plugins.Require("activity", "client.mode.TreasureHuntMgr")

---@class CMainActivity
local MainActivity = {}
---@type CBaseActivityMgr[]
local CurrentActivity = {}

local RefreshFunc

function MainActivity:init(initFunc, refreshFunc)
    if initFunc then
        initFunc(self)
    end
    RefreshFunc = refreshFunc
    for _, config in pairs(CommonActivityConfig:getAllCommonMoney()) do
        if config.moneyType > 100 then
            PlayerWallet:setMoneyCount(config.moneyType, 0)
            registerMoneyIcon(config.moneyType, config.moneyIcon)
        end
    end
end

---@param activity CommonActivityData
function MainActivity:addActivity(activity)
    if not activity then
        LogUtil.logError(string.format("MainActivity:addActivity ,activity not exist"))
        return
    end
    CurrentActivity[tostring(activity.id)] = BaseActivityMgr.createMgr(activity)
    if RefreshFunc then
        RefreshFunc()
    end
end

function MainActivity:removeActivity(activityId)
    CurrentActivity[tostring(activityId)] = nil
    if RefreshFunc then
        RefreshFunc()
    end
end

---@return CBaseActivityMgr
function MainActivity:getActivity(activityId)
    return CurrentActivity[tostring(activityId)]
end

---@return CBaseActivityMgr[]
function MainActivity:getAllActivity()
    ---@type CBaseActivityMgr[]
    local mgrList = {}
    for _, activityMgr in pairs(CurrentActivity) do
        table.insert(mgrList, activityMgr)
    end
    table.sort(mgrList, function(a, b)
        return a.mainConfig.sort < b.mainConfig.sort
    end)
    return mgrList
end

function MainActivity:getActivityByClass(class)
    local activity = {}
    for _, mgr in pairs(CurrentActivity) do
        if mgr.__cname == class then
            table.insert(activity, mgr)
        end
    end
    return activity
end

function MainActivity:getRewardGroupById(groupId)
    return CommonActivityConfig:getRewardGroupById(groupId)
end

function MainActivity:getRewardById(rewardId)
    return CommonActivityConfig:getRewardById(rewardId)
end

---@return CommonActivityConfig
function MainActivity:getCommonConfig()
    return CommonActivityConfig
end

---@return BlindBoxLotteryConfig
function MainActivity:getBlindBoxConfig()
    return BlindBoxConfig
end

---@return BlindBoxLotteryConfig
function MainActivity:haveNewBox()
    ---@type CTreasureBoxMgr[]
    local activity = self:getActivityByClass("CTreasureBoxMgr")
    for _, mgr in pairs(activity) do
        ---@type TreasureBoxDBData
        local cache = mgr:getPlayerCache(PlayerManager:getClientPlayer())
        if cache.getNewBox ~= 0 then
            return cache.getNewBox
        end
    end
end

function MainActivity:customShopData()
    for _, mgr in pairs(CurrentActivity) do
        mgr:customShopData()
    end
end

return MainActivity
