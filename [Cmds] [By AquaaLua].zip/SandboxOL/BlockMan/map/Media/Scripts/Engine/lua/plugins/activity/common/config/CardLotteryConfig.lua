---@class CardLotteryConfig
local CardLotteryConfig = {}

---@type CardLotteryData[]
local ConfigList = {}
---@type table< number, CardLotterySuitData[]>
local SuitList = {}
---@type table< number, CardPriceData[]>
local PriceGroups = {}

local function initCfg()
    ConfigList = {}
    PriceGroups = {}
    SuitList = {}
end

local function initConfig()
    local path = FileUtil:getMapPath() .. "plugins/activity/CardLottery.csv"
    local file = io.open(path, "r")
    if not file then
        return
    end
    file:close()

    local settings = CsvUtil.loadCsvFile(path, 3)
    for _, item in pairs(settings) do
        ---@class CardLotteryData
        local data = {
            id = tonumber(item.id),
            suitIds = StringUtil.split(item.suitIds or "0", "#"),
            priceGroupId = tonumber(item.priceGroupId),
            mustTimes = StringUtil.split(item.mustTimes or "0", "#"),
            showRewardDetailIds = StringUtil.split(item.showRewardDetailIds or "0", "#"),
        }
        table.insert(ConfigList, data)
    end
end

local function initSuit()
    local path = FileUtil:getMapPath() .. "plugins/activity/CardLotterySuit.csv"
    local file = io.open(path, "r")
    if not file then
        return
    end
    file:close()
    local config = CsvUtil.loadCsvFile(path, 3)
    for _, item in pairs(config) do
        ---@type CardLotterySuitData[]
        local suit = SuitList[tostring(item.suitId)] or {}
        ---@class CardLotterySuitData
        local reward = {
            id = tonumber(item.id),
            suitId = tonumber(item.suitId) or 0,
            rewardId = tonumber(item.rewardId) or 1,
            weights = tonumber(item.weights) or 1, ---权重
            sort = tonumber(item.sort) or 1, ---排序权重
        }
        table.insert(suit, reward)
        SuitList[tostring(item.suitId)] = suit
    end
    for _, suit in pairs(SuitList) do
        table.sort(suit, function(item1, item2)
            return item1.sort < item2.sort
        end)
    end
end

local function initPrice()
    local path = FileUtil:getMapPath() .. "plugins/activity/CardLotteryPrice.csv"
    local file = io.open(path, "r")
    if not file then
        return
    end
    file:close()
    local config = CsvUtil.loadCsvFile(path, 3)
    for _, item in pairs(config) do
        ---@type CardPriceData[]
        local group = PriceGroups[tostring(item.groupId)] or {}
        ---@class CardPriceData
        local price = {
            id = tonumber(item.id),
            groupSeq = tonumber(item.groupSeq),
            uniqueId = tonumber(item.uniqueId) or 0,
            moneyType = tonumber(item.moneyType) or 1,
            price = tonumber(item.price) or 999,
        }
        table.insert(group, price)
        PriceGroups[tostring(item.groupId)] = group
    end
    for _, group in pairs(PriceGroups) do
        table.sort(group, function(a, b)
            return a.groupSeq < b.groupSeq
        end)
    end
end

local function init()
    initCfg()
    initConfig()
    initPrice()
    initSuit()

end

function CardLotteryConfig:getConfigList()
    return ConfigList
end

function CardLotteryConfig:getActivityById(id)
    for _, config in pairs(ConfigList) do
        if config.id == id then
            return config
        end
    end
end

function CardLotteryConfig:getSuitConfig(suitId)
    return SuitList[tostring(suitId)] or {}
end

function CardLotteryConfig:getPriceConfig(groupId, groupSeq)
    local group = PriceGroups[tostring(groupId)]
    if not group then
        return
    end
    return group[groupSeq] or group[#group]
end

init()

return CardLotteryConfig