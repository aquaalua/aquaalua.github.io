---@class AceMinerConfig
local AceMinerConfig = T(Global, "AceMinerConfig")

---@type AceMinerConfigData[]
local ConfigList = {}

local function initConfig()
    local settings = FileUtil.getConfigFromCsv("plugins/activity/AceMiner.csv", 3, true)
    for _, item in pairs(settings) do
        local rewardPool = {}
        for _, v in pairs(StringUtil.split(item.rewardPool, "#")) do
            local data = StringUtil.split(v, ",")
            local id = tonumber(data[1])
            local num = tonumber(data[2])
            local weight = tonumber(data[3])
            table.insert(rewardPool, {id = id, num = num, weight = weight})
        end

        local showRewardPool = {}
        for _, v in pairs(StringUtil.split(item.showRewardPool, "#")) do
            local data = StringUtil.split(v, ",")
            local id = tonumber(data[1])
            local num = tonumber(data[2])
            local weight = tonumber(data[3])
            table.insert(showRewardPool, {id = id, num = num, weight = weight})
        end

        ---@class AceMinerConfigData
        local data = {
            id = tonumber(item.id),
            activityId = tonumber(item.activityId),
            boxId = tonumber(item.boxId),
            boxActor = item.boxActor,
            rewardPool = rewardPool,
            showRewardPool = showRewardPool,
            count = tonumber(item.count),
            price = tonumber(item.price),
            showPrice = tonumber(item.showPrice),
            uniqueId = tonumber(item.uniqueId),
            imageWidth = tonumber(item.imageWidth),
            imageHeight = tonumber(item.imageHeight),
        }
        if not ConfigList[data.activityId] then
            ConfigList[data.activityId] = {}
        end
        ConfigList[data.activityId][data.id] = data
    end
end

---@return AceMinerConfigData
function AceMinerConfig:getActivityById(activityId)
    if not ConfigList[activityId] then
        LogUtil.logError("AceMinerConfig:getActivityById can not find cfg :", activityId)
        return
    end
    return ConfigList[activityId]
end

function AceMinerConfig:getMaxBoxNum(activityId)
    if not ConfigList[activityId] then
        LogUtil.logError("AceMinerConfig:getMaxBoxNum can not find cfg :", activityId)
        return 0
    end
    local num = 0
    for i, v in pairs(ConfigList[activityId]) do
        num = num + 1
    end
    return num
end

initConfig()

return AceMinerConfig