---@class SurprisePackConfig
local SurprisePackConfig = T(Global, "SurprisePackConfig")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")

---@type SurprisePackConfigData[]
local ConfigList = {}
---@type table<string, SurprisePackConfigData[]>
local RewardGroups = {}
---@type table<string, SurprisePackConfigData>
local Rewards = {}

local function initConfig()
    local settings = FileUtil.getConfigFromCsv("plugins/activity/SurprisePack.csv", 3, true)
    for _, item in pairs(settings) do
        ---@class SurprisePackConfigData
        local data = {
            id = tonumber(item.id),
            rewardGroupId = item.rewardGroupId,
            consumeDiamond = tonumber(item.consumeDiamond),
        }
        table.insert(ConfigList, data)
    end

    settings = FileUtil.getConfigFromCsv("plugins/activity/SurprisePackRewardGroup.csv", 3, true)
    for _, item in pairs(settings) do
        ---@type SurprisePackRewardData[]
        local group = RewardGroups[tostring(item.groupId)] or {}
        ---@type CommonActivityRewardData
        local reward = CommonActivityConfig:getRewardById(item.rewardId)
        if reward then
            ---@class SurprisePackRewardData
            local data = {
                id = tonumber(item.id),
                reward = reward,
                groupSeq = tonumber(item.groupSeq),
            }
            Rewards[tostring(item.id)] = data
            table.insert(group, data)
        end
        RewardGroups[tostring(item.groupId)] = group
    end
    for _, group in pairs(RewardGroups) do
        table.sort(group, function(a, b)
            return a.groupSeq < b.groupSeq
        end)
    end
end

---@return SurprisePackConfigData
function SurprisePackConfig:getActivityById(activityId)
    for _, config in pairs(ConfigList) do
        if config.id == activityId then
            return config
        end
    end
end

---@return SurprisePackConfigData[]
function SurprisePackConfig:getRewardGroup(groupId)
    return RewardGroups[tostring(groupId)] or {}
end

---@return SurprisePackConfigData
function SurprisePackConfig:getRewardById(rewardId)
    return Rewards[tostring(rewardId)]
end

initConfig()

return SurprisePackConfig