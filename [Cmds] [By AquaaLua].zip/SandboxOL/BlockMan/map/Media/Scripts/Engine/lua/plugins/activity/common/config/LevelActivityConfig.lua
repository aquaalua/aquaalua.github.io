---@class LevelActivityConfig
local LevelActivityConfig = T(Global, "LevelActivityConfig")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")

---@type LevelActivityConfigData[]
local ConfigList = {}
---@type table<string, LevelActivityRewardData[]>
local RewardGroups = {}
---@type table<string, LevelActivityRewardData>
local Rewards = {}

local function initConfig()
    local settings = FileUtil.getConfigFromCsv("plugins/activity/LevelActivity.csv", 3, true)
    for _, item in pairs(settings) do
        ---@class LevelActivityConfigData
        local data = {
            id = tonumber(item.id),
            rewardGroupId = item.rewardGroupId,
            price = tonumber(item.price),
            moneyType = tonumber(item.moneyType),
            uniqueId = tonumber(item.uniqueId),
        }
        table.insert(ConfigList, data)
    end

    settings = FileUtil.getConfigFromCsv("plugins/activity/LevelActivityRewardGroup.csv", 3, true)
    for _, item in pairs(settings) do
        ---@type LevelActivityRewardData[]
        local group = RewardGroups[tostring(item.groupId)] or {}
        ---@type CommonActivityRewardData
        local rewardCfg = CommonActivityConfig:getRewardById(item.rewardId)
        if rewardCfg then
            -- 策划需求: 数量和图片在LevelActivityRewardGroup.csv设置
            local reward = TableUtil.copyTable(rewardCfg)
            reward.num = tonumber(item.num)
            reward.image = item.image
            ---@class LevelActivityRewardData
            local data = {
                id = tonumber(item.id),
                reward = reward,
                groupSeq = tonumber(item.groupSeq),
                level = tonumber(item.level),
            }
            Rewards[tostring(item.id)] = data
            table.insert(group, data)
        end
        RewardGroups[tostring(item.groupId)] = group
    end
    for _, group in pairs(RewardGroups) do
        table.sort(group, function(a, b)
            return a.groupSeq < b.groupSeq
        end)
    end
end

---@return LevelActivityConfigData
function LevelActivityConfig:getActivityById(activityId)
    for _, config in pairs(ConfigList) do
        if config.id == activityId then
            return config
        end
    end
end

---@return LevelActivityRewardData[]
function LevelActivityConfig:getRewardGroup(groupId)
    return RewardGroups[tostring(groupId)] or {}
end

---@return LevelActivityRewardData
function LevelActivityConfig:getRewardById(rewardId)
    return Rewards[tostring(rewardId)]
end

initConfig()

return LevelActivityConfig