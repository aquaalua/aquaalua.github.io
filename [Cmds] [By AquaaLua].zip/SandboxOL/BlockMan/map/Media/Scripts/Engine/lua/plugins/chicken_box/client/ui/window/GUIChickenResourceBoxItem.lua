---@class GUIChickenResourceBoxItemWindow : IGUIWindow
local GUIChickenResourceBoxItemWindow = class("GUIChickenResourceBoxItemWindow", IGUIWindow)

---@type ItemDetailConfig
local ItemDetailConfig = T(Global, "ItemDetailConfig")

local QualityColorMap = {
    [1] = { 34 / 255, 152 / 255, 32 / 255, 0.6 },
    [2] = { 30 / 255, 105 / 255, 197 / 255, 0.6 },
    [3] = { 201 / 255, 34 / 255, 165 / 255, 0.6 },
    [4] = { 255 / 255, 245 / 255, 80 / 255, 0.6 },
}

---@private
function GUIChickenResourceBoxItemWindow:ctor(...)
    self.super.ctor(self, "ChickenResourceBoxItem.json", ...)
end

---@private
function GUIChickenResourceBoxItemWindow:onLoad()
    self.siImageBg = self:getChildWindowByName("ChickenResourceBoxItem-Image-BG", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("ChickenResourceBoxItem-Image", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("ChickenResourceBoxItem-Name", GUIType.StaticText)
    self.stNum = self:getChildWindowByName("ChickenResourceBoxItem-Num", GUIType.StaticText)
    self.stDesc = self:getChildWindowByName("ChickenResourceBoxItem-Desc", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIChickenResourceBoxItemWindow:initView()
    self.stName:SetText()
    self.stNum:SetText()
end

---@private
function GUIChickenResourceBoxItemWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        PlayerManager:getClientPlayer():sendPacket({
            pid = "onPickUpChickenBoxItem",
            boxId = self.data.boxId,
            itemId = self.data.itemId
        })
    end)
end

function GUIChickenResourceBoxItemWindow:onDataChanged(data)
    local config = ItemDetailConfig:getCfgByItemId(data.itemId)
    self.data = data
    self.stName:SetText(Lang:getString(config.nameLang or ""))
    if tonumber(data.itemCount) ~= 1 then
        self.stNum:SetText(data.itemCount)
    else
        self.stNum:SetText("")
    end
    self.stDesc:SetText(Lang:getString(config.descLang or ""))
    self.siImage:SetImage(config.icon or "")

    if data.status == "" then
        self.root:SetDrawColor({ 255 / 255, 225 / 255, 59 / 255, 1 })
        self.siImageBg:SetDrawColor({ 255 / 255, 225 / 255, 59 / 255, 1 })
    else
        self.root:SetDrawColor({ 0, 0, 0, 1 })
        self.siImageBg:SetDrawColor({ 0, 0, 0, 1 })
    end
    self.siImageBg:SetBackgroundColor(QualityColorMap[config.qualityType] or { 1, 1, 1, 76 / 255 })
end

return GUIChickenResourceBoxItemWindow
