---@class UIEasterEggReceiveTipLayout : IGUILayout
local UIEasterEggReceiveTipLayout = class("UIEasterEggReceiveTipLayout", IGUILayout)

---@private
function UIEasterEggReceiveTipLayout:ctor(parent)
    self.super.ctor(self, "EasterEggReceiveTip.json", parent)
end

---@private
function UIEasterEggReceiveTipLayout:isDelayLoad()
    return true
end

---@private
function UIEasterEggReceiveTipLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIEasterEggReceiveTipLayout:initCreateEvent()

end

---@private
function UIEasterEggReceiveTipLayout:onLoad()
    self.siBg = self:getChildWindow("EasterEggReceiveTip-Bg", GUIType.StaticImage)
    self.stText = self:getChildWindow("EasterEggReceiveTip-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UIEasterEggReceiveTipLayout:initView()

end

---@private
function UIEasterEggReceiveTipLayout:initEvent()

end

function UIEasterEggReceiveTipLayout:setReceiveTip(eggCount)
    self.stText:SetText(string.format(Lang:getString("ui.easter.geteggs"), eggCount))
    local textWide = self.stText:GetTextWidth()
    if textWide > 420 then
        self.siBg:SetWidth({ 0, textWide + 509 })
    else
        self.siBg:SetWidth({ 0, 929 })
    end
end

function UIEasterEggReceiveTipLayout:setContextTip(context)
    self.stText:SetText((Lang:getString(context)))
    local textWide = self.stText:GetTextWidth()
    if textWide > 420 then
        self.siBg:SetWidth({ 0, textWide + 509 })
    else
        self.siBg:SetWidth({ 0, 929 })
    end
end

return UIEasterEggReceiveTipLayout
