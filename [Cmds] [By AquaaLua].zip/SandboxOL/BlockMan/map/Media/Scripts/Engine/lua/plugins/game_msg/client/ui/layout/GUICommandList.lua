---@type CommandSettingConfig
local CommandSettingConfig = T(Global, "CommandSettingConfig")
---@class UICommandListLayout : IGUILayout
local UICommandListLayout = class("UICommandList", IGUILayout)

function UICommandListLayout:ctor(parent)
    self.super.ctor(self, "BedWarCommandList.json", parent)
end

function UICommandListLayout:isDelayLoad()
    return true
end

function UICommandListLayout:onCreate()
    local commandConfig = CommandSettingConfig:getAllConfig()
    self.commandList = {}
    for _, command in pairs(commandConfig) do
        table.insert(self.commandList, { id = command.id, canUse = command.price == 0, icon = command.icon })
    end
end

function UICommandListLayout:onLoad()
    self.llCommandList = self:getChildWindow("BedWarCommandList-list", GUIType.Layout)
    self:initRegister()
    self:initCommandList()
end

function UICommandListLayout:initCommandList()
    self.gvCommandItems = IGUIGridView.new("BedWarCommandList-Item", self.llCommandList)
    self.gvCommandItems:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.gvCommandItems:setConfig(16, 14, 3)
    local ContentSize = (self.llCommandList:GetPixelSize().x - 32) / 3
    ---@type CommandAdapter
    self.commandAdapter = UIHelper.newGameAdapter("CommandAdapter")
    self.commandAdapter:setItemSize(ContentSize, ContentSize)
    self.gvCommandItems:setAdapter(self.commandAdapter)
    self.commandAdapter:setData(self.commandList)
end

function UICommandListLayout:initRegister()
    self.root:registerEvent(GUIEvent.TouchDown, function()
        self:hide()
    end)
end

function UICommandListLayout:initCommandListData(data)
    for _, commandId in pairs(data) do
        self:onCommandStatusChange(commandId)
    end
    if self:isShow() then
        self.commandAdapter:setData(self.commandList)
    end
end

function UICommandListLayout:onShow()
    self.commandAdapter:setData(self.commandList)
end

function UICommandListLayout:onCommandStatusChange(messageId)
    for _, command in pairs(self.commandList) do
        if command.id == messageId then
            command.canUse = true
            break
        end
    end
end

function UICommandListLayout:onHide()
    if GUIMain.cbShortMessage then
        GUIMain.cbShortMessage:SetChecked(false)
    end
    if GUIBedWarToolBar.cbShortMessage then
        GUIBedWarToolBar.cbShortMessage:SetChecked(false)
    end
end

return UICommandListLayout
