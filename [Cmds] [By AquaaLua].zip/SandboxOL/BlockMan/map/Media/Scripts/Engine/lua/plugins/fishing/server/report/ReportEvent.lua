---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@param player SBasePlayer
---@param event number event [event name]
---@param event_map table event_map [eg {key1 = value1,key2 = value2, ...}]
local function newDesign(player, event, event_map)
    event_map.is_new = player.play_days <= 1
    GameAnalytics:newDesign(player.userId, event, event_map)
end

---@param player SBasePlayer
function ReportEvent.player_start_fishing(player, sealId)
    local map = {
        sealId = sealId,
    }
    newDesign(player, "player_start_fishing", map)
end

---@param player SBasePlayer
function ReportEvent.player_fishing_success(player, fishId)
    local map = {
        fishId = fishId,
    }
    newDesign(player, "player_fishing_success", map)
end

---@param player SBasePlayer
function ReportEvent.player_fish_exchange(player, fishId, count)
    local map = {
        fishId = fishId,
        count = count,
    }
    newDesign(player, "player_fish_exchange", map)
end