---@class MustLotteryConfig
local MustLotteryConfig = {}

---@type MustLotteryData[]
local ConfigList = {}
---@type table< number, MustPriceData[]>
local PriceGroups = {}

local function initCfg()
    ConfigList = {}
    PriceGroups = {}
end

local function initConfig()
    local path = FileUtil:getMapPath() .. "plugins/activity/MustLottery.csv"
    local file = io.open(path, "r")
    if not file then
        return
    end
    file:close()

    local settings = CsvUtil.loadCsvFile(path, 3)
    for _, item in pairs(settings) do
        if item.titleLang == "#" then
            item.titleLang = ""
        end
        if item.descLang == "#" then
            item.descLang = ""
        end
        ---@class MustLotteryData
        local data = {
            id = tonumber(item.id),
            rewardGroupId = tonumber(item.rewardGroupId),
            priceGroupId = tonumber(item.priceGroupId),
            deleteCount = tonumber(item.deleteCount) or 0,
            showRewardDetailIds = StringUtil.split(item.showRewardDetailIds or "0", "#"),
        }
        table.insert(ConfigList, data)
    end
end

local function initPrice()
    local path = FileUtil:getMapPath() .. "plugins/activity/MustLotteryPrice.csv"
    local file = io.open(path, "r")
    if not file then
        return
    end
    file:close()
    local config = CsvUtil.loadCsvFile(path, 3)
    for _, item in pairs(config) do
        ---@type MustPriceData[]
        local group = PriceGroups[tostring(item.groupId)] or {}
        ---@class MustPriceData
        local price = {
            id = tonumber(item.id),
            groupSeq = tonumber(item.groupSeq),
            uniqueId = tonumber(item.uniqueId) or 0,
            moneyType = tonumber(item.moneyType) or 1,
            times = tonumber(item.times) or 1,
            price = tonumber(item.price) or 999,
            discountPrice = tonumber(item.discountPrice) or tonumber(item.price),
            extraRewardId = tonumber(item.extraRewardId) or 0,
            hintLang = item.hintLang
        }
        table.insert(group, price)
        PriceGroups[tostring(item.groupId)] = group
    end
    for _, group in pairs(PriceGroups) do
        table.sort(group, function(a, b)
            return a.groupSeq < b.groupSeq
        end)
    end
end

local function init()
    initCfg()
    initConfig()
    initPrice()
end

function MustLotteryConfig:getConfigList()
    return ConfigList
end

function MustLotteryConfig:getActivityById(id)
    for _, config in pairs(ConfigList) do
        if config.id == id then
            return config
        end
    end
end

---@return MustPriceData
function MustLotteryConfig:getPriceConfig(groupId, groupSeq)
    local group = PriceGroups[tostring(groupId)]
    if not group then
        return
    end
    return group[groupSeq] or group[#group]
end

init()

return MustLotteryConfig