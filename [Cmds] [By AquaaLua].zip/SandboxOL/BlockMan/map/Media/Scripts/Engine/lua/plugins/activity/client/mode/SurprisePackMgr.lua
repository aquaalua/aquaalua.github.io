---@type SurprisePackConfig
local SurprisePackConfig = Plugins.Require("activity", "common.config.SurprisePackConfig")

---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")

---@class CSurprisePackMgr : CBaseActivityMgr
local SurprisePackMgr = class("CSurprisePackMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.SurprisePack, SurprisePackMgr, SurprisePackConfig)
----------------------------------------------------------------------------------
---@param mgrConfig SurprisePackConfigData
function SurprisePackMgr:initActivity(mgrConfig)
    self.config = mgrConfig
end

---@param player SBasePlayer
---@param cache SurprisePackDBData
function SurprisePackMgr:setPlayerCache(player, cache)
    self.dataCache = cache
    if self.cacheCallBack then
        self.cacheCallBack()
    end
    self.ready = true
end

---@return SurprisePackDBData
function SurprisePackMgr:getPlayerCache()
    return self.dataCache or {
        consumeDiamond = 0,
        receiveId = 0,
        haveReceive = false,
    }
end

-------------------------------------功能相关---------------------------------------------------
function SurprisePackMgr:tryGetReward(rewardIndex)
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "tryGetReward",
        rewardIndex = rewardIndex,
    })
end

function SurprisePackMgr:checkHasThreePet()
    local hasAll = true
    local rewards = SurprisePackConfig:getRewardGroup(self.config.rewardGroupId)
    for i, reward in pairs(rewards) do
        local realId = reward.reward.realId
        if not CustomShop:isGoodsHas(realId) then
            hasAll = false
            break
        end
    end
    return hasAll
end

function SurprisePackMgr:notifyShowIcon()
    if self.dataCache.haveReceive then
        Events.ShowSurprisePackIconEvent:invoke(self.mainConfig.activityId, false)
    else
        Events.ShowSurprisePackIconEvent:invoke(self.mainConfig.activityId, true, self.mainConfig.endTime)
    end
end

function SurprisePackMgr:showPanel()
    if not self.dataCache.haveReceive and not self.isShowWhenLogin then
        GUIManager:addShowQueue(UIGameActivitySurprisePackLayout)
        self.isShowWhenLogin = true
    end
end

function SurprisePackMgr:loadActivityEntry()
    if self.loadShopData and self.ready then
        if not self:checkHasThreePet() then
            self:notifyShowIcon()
            self:showPanel()
        end
    end
end

function SurprisePackMgr:customShopData()
    self.loadShopData = true
end

function SurprisePackMgr:tryShowPanel(registrationTimeKey)
    if registrationTimeKey and registrationTimeKey > 0 then
        local registrationDayStartTime = DateUtil.getUTCDayStartTime(registrationTimeKey)
        local curDayStartTime = DateUtil.getUTCDayStartTime(os.time())
        if (curDayStartTime - registrationDayStartTime) / 86400 < 7 then
            --注册小于7天 要弹出
            self:loadActivityEntry()
        end
    end
end

return SurprisePackMgr