---@class ActivityTalentRank
local ActivityTalentRank = T(Global, "ActivityTalentRank")

local ConfigList = {}

local function initConfig()
    local settings = FileUtil.getConfigFromCsv("plugins/activity/ActivityTalentRank.csv", 2, true)
    local configMap = {}
    for i, v in pairs(settings) do
        local data = {
            talent_upgrade = tonumber(v.n_talent_upgrade) or 0,
            overstep = tonumber(v.n_overstep) or 0,
            reward_count = tonumber(v.n_reward_count) or 0,
            id = tonumber(v.n_id) or 0,
            average_rank = tonumber(v.n_average_rank) or 0,
            talent_level = tonumber(v.n_talent_level) or 0,
        }
        local list = configMap[data.reward_count]
        if not list then
            list = {}
            configMap[data.reward_count] = list
        end
        table.insert(list, data)
    end
    for reward_count, v in pairs(configMap) do
        table.sort(v, function(a, b)
            return a.talent_level < b.talent_level
        end)

        table.insert(ConfigList, {count = reward_count, list = v})
    end

    table.sort(ConfigList, function(a, b)
        return a.count < b.count
    end)
end

function ActivityTalentRank:getTalentRankData(rewardCount, totalTalentLevel)
    local config = ConfigList[1]
    for i, info in ipairs(ConfigList) do
        if info.count > rewardCount then
            break
        else
            config = info
        end
    end

    local list = config.list
    if not list then
        LogUtil.logWarning("not talent rank data rewardCount -> ", rewardCount)
        return
    end
    for i = #list, 1, -1  do
        local data = list[i]
        if totalTalentLevel >= data.talent_level then
            return data
        end
    end
end

initConfig()

return ActivityTalentRank