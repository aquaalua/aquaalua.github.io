---@class CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")

---@type CommonActivityData[]
local Activities = {}
---@type CommonActivityMoneyData[]
local Money = {}
---@type CommonActivityRewardData[]
local Rewards = {}
---@type table<string , CommonActivityRewardWeightData[]>
local RewardGroups = {}
local Chests = {}
local ChestGroups = {}

local function initActivityConfig(config)
    for _, item in pairs(config) do
        local startTime, endTime = 0, -1
        if item.startDate ~= "#" then
            local _, _, year, month, day, hour, min, sec = string.find(item.startDate, "(%d+)-(%d+)-(%d+)-(%d+)-(%d+)-(%d+)")
            startTime = DateUtil.date2BeiJingTime({ year = year, month = month, day = day, hour = hour, min = min, sec = sec })
        end
        if item.endDate ~= "#" then
            local _, _, year, month, day, hour, min, sec = string.find(item.endDate, "(%d+)-(%d+)-(%d+)-(%d+)-(%d+)-(%d+)")
            endTime = DateUtil.date2BeiJingTime({ year = year, month = month, day = day, hour = hour, min = min, sec = sec })
        end
        if item.titleLang == "#" then
            item.titleLang = ""
        end
        if item.descLang == "#" then
            item.descLang = ""
        end
        if item.mainUIImage == "#" then
            item.mainUIImage = ""
        end

        local moneyType2Data = StringUtil.split(item.moneyType2, "#")
        local moneyType2 = {}
        for _, v in pairs(moneyType2Data) do
            table.insert(moneyType2, tonumber(v))
        end

        ---@class CommonActivityData
        local data = {
            id = tonumber(item.id),
            sort = tonumber(item.sort),
            type = tonumber(item.type),
            mould = tonumber(item.mould) or 1,
            activityId = tonumber(item.activityId),
            showInLayout = tonumber(item.showInLayout) or 1,
            startTime = startTime,
            endTime = endTime,
            tabLang = item.tabLang,
            titleLang = item.titleLang,
            descLang = item.descLang,
            tabImage = item.tabImage,
            mainUIImage = item.mainUIImage,
            chestGroupId = tonumber(item.chestGroupId),
            moneyType = tonumber(item.moneyType),
            moneyType2 = moneyType2,
            mainRewardId = tonumber(item.mainRewardId),
            mainRewardImage = item.mainRewardImage,
            imageBox = item.imageBox,
            actor = item.actor,
            actorShowSkill = item.actorShowSkill,
            actorIdleSkill = item.actorIdleSkill,
            actorBody = StringUtil.split(item.actorBody, "#"),
            actorBodyId = StringUtil.split(item.actorBodyId, "#"),
            actorScale = tonumber(item.actorScale),
            actorRotate = tonumber(item.actorRotate),
            actorYOffset = tonumber(item.actorYOffset),
            actorXOffset = tonumber(item.actorXOffset),
            actorBodyDelay = tonumber(item.actorBodyDelay) or 0,
        }
        Activities[tostring(data.id)] = data
    end
end

local function initActivityMoney(config)
    for _, item in pairs(config) do
        ---@class CommonActivityMoneyData
        local data = {
            moneyType = tonumber(item.moneyType),
            moneyIcon = item.moneyIcon,
        }
        Money[tostring(data.moneyType)] = data
    end
end

local function initChestConfig(config)
    for _, item in pairs(config) do
        local data = {}
        data.chestId = tonumber(item.chestId)
        data.times = tonumber(item.times)
        data.normalImage = item.normalImage
        data.canOpenImage = item.canOpenImage
        data.openImage = item.openImage
        data.timesImage = item.timesImage
        data.rewardGroupId = tonumber(item.rewardGroupId)
        Chests[item.chestId] = data
        local group = ChestGroups[tostring(item.chestGroupId)]
        if group then
            table.insert(group.chests, data)
        end
    end
    for _, group in pairs(ChestGroups) do
        table.sort(group.chests, function(a, b)
            return a.times < b.times
        end)
    end
end

local function initChestGroupConfig(config)
    for _, item in pairs(config) do
        ChestGroups[item.chestGroupId] = {
            background = item.background,
            refreshTime = tonumber(item.refreshTime) or -1,
            chests = {}
        }
    end
end

local function initRewardItemConfig(config)
    for _, item in pairs(config) do
        ---@class CommonActivityRewardData
        local data = {}
        data.rewardId = tonumber(item.id)                                   ---奖励id
        data.realId = item.realId                                           ---真实奖励id
        data.type = item.type                                               ---奖励类型
        data.quality = item.quality                                         ---物品品质
        data.effect = item.effect                                           ---特效名称
        data.num = tonumber(item.num)                                       ---物品数量
        data.numLang = item.numLang                                         ---物品数量多语言
        data.name = item.name                                               ---物品名
        data.image = item.image                                             ---图片
        data.imageScale = tonumber(item.imageScale) or "#"                  ---图片缩放
        data.imageXOffset = tonumber(item.imageXOffset) or "#"              ---图片X方向偏移值
        data.imageYOffset = tonumber(item.imageYOffset) or "#"              ---图片Y方向偏移值
        data.needMask = item.needMask == "#" and 0 or tonumber(item.needMask)---是否遮罩
        data.desc = item.desc                                               ---物品详情
        data.price = tonumber(item.price) or 0                              ---价格
        data.priceIcon = item.priceIcon                                     ---价格图片
        data.compensate = tonumber(item.compensate) or 0                    ---补偿物品
        data.showGrandPrize = item.showGrandPrize == "1"                    ---是否使用大奖展示
        data.upProbability = item.upProbability == "1"                      ---展示概率提升
        data.showDetailId = tonumber(item.showDetailId) or 0                ---详情显示Id
        Rewards[item.id] = data
    end
end

local function initRewardGroupConfig(config)
    for _, item in pairs(config) do
        ---@type CommonActivityRewardWeightData[]
        local group = RewardGroups[tostring(item.groupId)] or {}
        ---@type CommonActivityRewardData
        local reward = Rewards[item.rewardId]
        if reward then
            ---获取后需要移出随机池

            local timesMap = {}
            for _, times in pairs(StringUtil.split(item.timesPool, "#")) do
                timesMap[tonumber(times) or 0] = true
            end
            ---@class CommonActivityRewardWeightData
            local data = {
                ---@type CommonActivityRewardData
                reward = reward,
                groupSeq = tonumber(item.groupSeq), ---排序
                weights = tonumber(item.weights), ---权重
                isGrandPrize = item.isGrandPrize == "1", ---是否为大奖
                timesMap = timesMap, ---及N次奖池
                needRemove = item.needRemove == "1"
            }
            table.insert(group, data)
        end
        RewardGroups[tostring(item.groupId)] = group
    end
    for _, group in pairs(RewardGroups) do
        table.sort(group, function(a, b)
            return a.groupSeq < b.groupSeq
        end)
    end
end

local function init()
    Activities = {}
    Rewards = {}
    RewardGroups = {}
    ChestGroups = {}
    Chests = {}
    Coins = {}

    local path = FileUtil:getMapPath() .. "plugins/activity/CommonActivity.csv"
    local file = io.open(path, "r")
    if not file then
        return
    end
    file:close()
    initActivityConfig(CsvUtil.loadCsvFile(path, 3))

    path = FileUtil:getMapPath() .. "plugins/activity/CommonActivityMoney.csv"
    file = io.open(path, "r")
    if not file then
        return
    end
    file:close()
    initActivityMoney(CsvUtil.loadCsvFile(path, 3))

    path = FileUtil:getMapPath() .. "plugins/activity/CommonActivityChestGroup.csv"
    file = io.open(path, "r")
    if not file then
        return
    end
    file:close()
    initChestGroupConfig(CsvUtil.loadCsvFile(path, 3))

    path = FileUtil:getMapPath() .. "plugins/activity/CommonActivityChest.csv"
    file = io.open(path, "r")
    if not file then
        return
    end
    file:close()
    initChestConfig(CsvUtil.loadCsvFile(path, 3))

    path = FileUtil:getMapPath() .. "plugins/activity/CommonActivityRewardItem.csv"
    file = io.open(path, "r")
    if not file then
        return
    end
    file:close()
    initRewardItemConfig(CsvUtil.loadCsvFile(path, 3))

    path = FileUtil:getMapPath() .. "plugins/activity/CommonActivityRewardGroup.csv"
    file = io.open(path, "r")
    if not file then
        return
    end
    file:close()
    initRewardGroupConfig(CsvUtil.loadCsvFile(path, 3))
end

---@return CommonActivityData[]
function CommonActivityConfig:getAllCommonActivity()
    return Activities
end

function CommonActivityConfig:getCommonActivityById(activityId)
    return Activities[tostring(activityId)]
end

function CommonActivityConfig:getAllCommonMoney()
    return Money
end

function CommonActivityConfig:getChestGroupById(groupId)
    return ChestGroups[tostring(groupId)]
end

function CommonActivityConfig:getChestById(chestId)
    return Chests[tostring(chestId)]
end


---@class WeightsItem
---@field weights number

---@param pool WeightsItem[]
function CommonActivityConfig:randomWeightsPool(pool)
    local _pool = {}
    local weightSum = 0
    for _, item in pairs(pool) do
        weightSum = weightSum + item.weights
        table.insert(_pool, item)
    end
    if #_pool == 0 then
        return nil
    end
    local random = math.random(1, weightSum)
    local weightTag = 0
    local itemTag
    for _, item in pairs(_pool) do
        weightTag = weightTag + item.weights
        if weightTag >= random then
            itemTag = item
            break
        end
    end
    return itemTag
end

---@return CommonActivityRewardWeightData[]
function CommonActivityConfig:getRewardGroupById(groupId)
    return RewardGroups[tostring(groupId)]
end

function CommonActivityConfig:getRewardById(rewardId)
    return Rewards[tostring(rewardId)]
end

function CommonActivityConfig:getRewardByRealId(realId)
    for i, v in pairs(Rewards) do
        if v.realId == tostring(realId) then
            return v
        end
    end
end

function CommonActivityConfig:getRewardFromGroup(rewardId)
    for _, group in pairs(RewardGroups) do
        for i, reward in ipairs(group) do
            if reward.reward.rewardId == rewardId then
                return reward
            end
        end
    end
    return nil
end

init()

return CommonActivityConfig