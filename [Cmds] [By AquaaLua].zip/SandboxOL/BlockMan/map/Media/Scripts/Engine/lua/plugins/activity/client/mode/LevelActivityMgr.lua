---@type LevelActivityConfig
local LevelActivityConfig = Plugins.Require("activity", "common.config.LevelActivityConfig")

---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")

---@class LevelActivityMgr : CBaseActivityMgr
local LevelActivityMgr = class("CLevelActivityMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.LevelActivity, LevelActivityMgr, LevelActivityConfig)
----------------------------------------------------------------------------------
---@param mgrConfig LevelActivityConfigData
function LevelActivityMgr:initActivity(mgrConfig)
    self.config = mgrConfig
end

---@param player SBasePlayer
---@param cache LevelActivityDBData
function LevelActivityMgr:setPlayerCache(player, cache)
    self.dataCache = cache
    if self.cacheCallBack then
        self.cacheCallBack()
    end
end

---@return LevelActivityDBData
function LevelActivityMgr:getPlayerCache()
    return self.dataCache or {
        records = {},
        haveBuy = false,
        level = 0,
    }
end

---@return
function LevelActivityMgr:getLevel()
    return self:getPlayerCache().level
end

function LevelActivityMgr:isRewardReceived(rewardId)
    return TableUtil.tableContain(self:getPlayerCache().records, rewardId)
end

-------------------------------------功能相关---------------------------------------------------
function LevelActivityMgr:tryGetReward(rewardId)
    if not self:getPlayerCache().haveBuy then
        return
    end
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "tryGetReward",
        rewardId = rewardId,
    })
end

function LevelActivityMgr:onBuyPrivilege()
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "buyPrivilege"
    })
    return true
end

function LevelActivityMgr:isGetAllReward()
    local list = self:getPlayerCache().records
    local num = 0
    for i, v in pairs(list) do
        num = num + 1
    end
    return num >= self:getLevel()
end

function LevelActivityMgr:updateLastOpenUIDate()
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "updateLastOpenUIDate"
    })
end

return LevelActivityMgr