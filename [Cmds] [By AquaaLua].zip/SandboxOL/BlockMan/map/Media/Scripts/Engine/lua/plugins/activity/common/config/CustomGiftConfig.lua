---@class CustomGiftConfig
local CustomGiftConfig = T(Global, "CustomGiftConfig")

---@type RandomStoreConfigData[]
local ConfigList = {}
local CellRewardSetting = {}

local function initConfig()
    local settings = FileUtil.getConfigFromCsv("plugins/activity/CustomGift.csv", 2, true)
    for _, item in pairs(settings) do
        local data = {
            id = item.n_id,
            activityId = tonumber(item.n_activity_id) or 0,
            limitBuyCount = tonumber(item.n_limit_buy_count) or 0,
            price = tonumber(item.n_price) or 0,
            orderId = tonumber(item.n_order_id) or 0,
            name = item.s_name,
        }
        local rewardCellList = {}
        if item.s_reward_cell_list ~= "#" then
            local list = StringUtil.split(item.s_reward_cell_list, "#")
            for _, cellId in pairs(list) do
                table.insert(rewardCellList, cellId)
            end
        end
        data.rewardCellList = rewardCellList
        ConfigList[data.activityId] = ConfigList[data.activityId] or {}
        table.insert(ConfigList[data.activityId], data)
    end
    for _, groups in pairs(ConfigList or {}) do
        table.sort(groups, function(a, b)
            return a.id < b.id
        end)
    end
    settings = FileUtil.getConfigFromCsv("plugins/activity/CustomGiftCell.csv", 2, true)
    for _, item in pairs(settings) do
        local data = {
            id = item.n_id,
            defaultRewardIndex = tonumber(item.n_default_reward_index) or 0
        }
        if item.s_custom_reward_list ~= "#" then
            local rewardPool = {}
            local arr = StringUtil.split(item.s_custom_reward_list, "#")
            for _, v in ipairs(arr or {}) do
                local rewardStr = StringUtil.split(v, ",")
                local rewardData = {
                    rewardId = tonumber(rewardStr[1]),
                    num = tonumber(rewardStr[2]),
                }
                table.insert(rewardPool, rewardData)
            end
            data.rewardPool = rewardPool
        end

        local defaultReward = {}
        if data.defaultRewardIndex then
            defaultReward = data.rewardPool[data.defaultRewardIndex] or {}
        end
        data.defaultReward = defaultReward

        CellRewardSetting[data.id] = data
    end
end

---获取奖励格子数据
function CustomGiftConfig:getCellCfg(cellId)
    return CellRewardSetting[cellId]
end

---获取格子对应index的奖励数据
function CustomGiftConfig:getCellRewardDataByIndex(cellId, index)
    local cellCfg = self:getCellCfg(cellId)
    if not cellCfg then
        return
    end
    if not index then
        return cellCfg.defaultReward
    else
        return cellCfg.rewardPool[index] or cellCfg.defaultReward
    end
end

---获取格子默认奖励数据
function CustomGiftConfig:getCellDefaultRewardData(cellId)
    local cellCfg = self:getCellCfg(cellId)
    if not cellCfg then
        return
    end
    return cellCfg.defaultReward
end

---获取当前活动自定义礼包数据
function CustomGiftConfig:getCustomGiftCfgById(activityId, id)
    for _, v in pairs(ConfigList[activityId] or {}) do
        if v.id == id then
            return v
        end
    end
end

---获取当前活动配置
function CustomGiftConfig:getActivityById(activityId)
    return ConfigList[activityId]
end


initConfig()

return CustomGiftConfig