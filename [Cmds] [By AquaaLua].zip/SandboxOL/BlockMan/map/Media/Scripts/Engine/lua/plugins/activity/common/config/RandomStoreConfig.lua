---@class RandomStoreConfig
local RandomStoreConfig = T(Global, "RandomStoreConfig")

---@type RandomStoreConfigData[]
local ConfigList = {}
---@type RandomStoreGroupData[]
local GroupConfig = {}

local function initConfig()
    local settings = FileUtil.getConfigFromCsv("plugins/activity/RandomStoreGroup.csv", 3, true)
    for _, item in pairs(settings) do
        ---@class RandomStoreGroupData
        local data = {
            id = tonumber(item.id) or 0,
            activityId = tonumber(item.activityId) or 0,
            groupId = tonumber(item.groupId) or 0,
            randomCount = tonumber(item.randomCount) or 0,
            uniqueId = tonumber(item.uniqueId) or 0,
        }
        if not GroupConfig[data.activityId] then
            GroupConfig[data.activityId] = {}
        end
        table.insert(GroupConfig[data.activityId], data)
    end
    for _, groups in pairs(GroupConfig or {}) do
        table.sort(groups, function(a, b)
            return a.groupId < b.groupId
        end)
    end
    settings = FileUtil.getConfigFromCsv("plugins/activity/RandomStore.csv", 3, true)
    for _, item in pairs(settings) do
        ---@class RandomStoreConfigData
        local data = {
            id = tonumber(item.id) or 0,
            groupId = tonumber(item.groupId) or 0,
            rewardId = tonumber(item.rewardId) or 0,
            rewardCount = tonumber(item.rewardCount) or 0,
            originPrice = tonumber(item.originPrice) or 0,
            price = tonumber(item.price) or 0,
            moneyType = tonumber(item.moneyType) or 0,
            limitCount = tonumber(item.limitCount) or 0,
            weight = tonumber(item.weight) or 0,
            canReBuy = item.canReBuy == "1",
            quality = tonumber(item.quality),
            scale = item.scale,
            actorRotate = item.actorRotate,
            actorYOffset = item.actorYOffset, ---模型高度偏移
            actorXRotate = item.actorXRotate
        }
        if not ConfigList[data.groupId] then
            ConfigList[data.groupId] = {}
        end
        ConfigList[data.groupId][data.id] = data
    end
end

function RandomStoreConfig:getGroupCfg(groupId)
    for _, groups in pairs(GroupConfig or {}) do
        for _, group in pairs(groups or {}) do
            if group.groupId == groupId then
                return group
            end
        end
    end
    LogUtil.logError("no group cfg", groupId)
    return {}
end

function RandomStoreConfig:getGroupPool(groupId)
    if not ConfigList[groupId] then
        LogUtil.logError("no random store config", groupId)
        return
    end
    return ConfigList[groupId]
end

---@return RandomStoreGroupData
function RandomStoreConfig:getActivityById(activityId)
    if not GroupConfig[activityId] then
        LogUtil.logError("no random store group config", activityId)
        return
    end
    return GroupConfig[activityId]
end

---@return RandomStoreConfigData
function RandomStoreConfig:getRewardById(id)
    for _, list in pairs(ConfigList) do
        if list[id] then
            return list[id]
        end
    end
    LogUtil.logError("no random store reward config", id)
end

function RandomStoreConfig:randomWeightsPool(pool, num, ifReduce)
    local _pool = {}
    local weightSum = 0
    for _, item in pairs(pool) do
        weightSum = weightSum + item.weight
        table.insert(_pool, item)
    end
    if #_pool == 0 then
        return nil
    end
    local ret = {}
    for i=1, num do
        local random = math.random(1, weightSum)
        local weightTag = 0
        for index, item in pairs(_pool) do
            weightTag = weightTag + item.weight
            if weightTag >= random then
                table.insert(ret, item)
                if ifReduce then
                    table.remove(_pool, index)
                    weightSum = weightSum - item.weight
                end
                break
            end
        end
    end
    return ret
end

initConfig()

return RandomStoreConfig