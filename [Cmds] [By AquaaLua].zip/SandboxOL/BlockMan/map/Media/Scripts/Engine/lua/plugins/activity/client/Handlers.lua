---@type CBasePlayer
local handler = T(Global, "PacketHandlers")

---@type CMainActivity
local MainActivity = Plugins.Require("activity", "client.MainActivity")

---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")

function handler:PluginAddActivity(packet)
    MainActivity:addActivity(CommonActivityConfig:getCommonActivityById(packet.activityId))
end

function handler:PluginRemoveActivity(packet)
    MainActivity:removeActivity(packet.activityId)
end

function handler:ToActivityPacket(packet)
    local activityMgr = MainActivity:getActivity(packet.activityId)
    if activityMgr and activityMgr[packet.funcName] then
        activityMgr[packet.funcName](activityMgr, PlayerManager:getClientPlayer(), packet)
    else
        LogUtil.logError(string.format("ToActivityPacket Error ,activityMgr not exist , activityId = %d", packet.activityId))
    end
end

function handler:SetActivityMoney(packet)
    PlayerWallet:setMoneyCount(tonumber(packet.coinId), packet.count)
end

function handler:S2CActivityInitFinish(packet)
    --惊喜礼包初始化完活动数据后尝试弹出
    local surprisePackActivityList = PluginMainActivity:getActivityByClass("CSurprisePackMgr")
    if next(surprisePackActivityList) then
        local mgr = surprisePackActivityList[1]
        if mgr then
            mgr:tryShowPanel(packet.registrationTimeKey)
        end
    end
end