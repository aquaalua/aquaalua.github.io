---@class TreasureBoxConfig
local TreasureBoxConfig = {}
---@type TreasureBoxData[]
local ConfigList = {}
---@type table<number, TreasureBoxItemData[]>
local BoxGroups = {}
---@type TreasureBoxItemData[]
local BoxItems = {}

---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")

local function initCfg()
    ConfigList = {}
    BoxGroups = {}
end

local function initConfig()
    local path = FileUtil:getMapPath() .. "plugins/activity/TreasureBox.csv"
    local file = io.open(path, "r")
    if not file then
        return
    end
    io.close(file)

    local settings = CsvUtil.loadCsvFile(path, 3)
    for _, item in pairs(settings) do
        local endTime = 0
        if item.boxEndTime and item.boxEndTime ~= "#" then
            local _, _, year, month, day, hour, min, sec = string.find(item.boxEndTime, "(%d+)-(%d+)-(%d+)-(%d+)-(%d+)-(%d+)")
            endTime = DateUtil.date2BeiJingTime({ year = year, month = month, day = day, hour = hour, min = min, sec = sec })
        end
        ---@class TreasureBoxData
        local data = {
            id = tonumber(item.id),
            price = tonumber(item.price),
            boxGroupId = tonumber(item.boxGroupId),
            freeBoxGroupId = tonumber(item.freeBoxGroupId),
            moneyType = tonumber(item.moneyType),
            uniqueId = tonumber(item.uniqueId),
            conditionType = tonumber(item.conditionType),
            boxEndTime = endTime,
        }
        table.insert(ConfigList, data)
    end

    path = FileUtil:getMapPath() .. "plugins/activity/TreasureBoxItem.csv"
    file = io.open(path, "r")
    if not file then
        return
    end
    io.close(file)

    local config = CsvUtil.loadCsvFile(path, 3)
    for _, item in pairs(config) do
        ---@type TreasureBoxItemData[]
        local group = BoxGroups[tostring(item.groupId)] or {}
        ---@class TreasureBoxItemData
        local data = {
            id = tonumber(item.id),
            groupId = tonumber(item.groupId),
            totalCount = tonumber(item.totalCount) or 0,
            boxIndexList = StringUtil.split(item.boxIndexList or "-1", "#"),
            boxIndexMap = {},
            times = tonumber(item.times) or 1,
            weights = tonumber(item.weights) or 1,
            boxSettingId = tonumber(item.boxSettingId) or 1,
            normalImage = item.normalImage,
            openImage = item.openImage,
            hallBoxEffect = item.hallBoxEffect,
            resultBoxEffect = item.resultBoxEffect,
            openTipEffect = item.openTipEffect,
        }
        table.insert(group, data)
        BoxItems[data.id] = data
        BoxGroups[tostring(item.groupId)] = group

        for _, index in pairs(data.boxIndexList) do
            data.boxIndexMap[tonumber(index)] = true
        end
    end
    for _, group in pairs(BoxGroups) do
        table.sort(group, function(a, b)
            return #a.boxIndexList < #b.boxIndexList
        end)
    end
end

local function init()
    initCfg()
    initConfig()
end

function TreasureBoxConfig:getActivityById(id)
    for _, config in pairs(ConfigList) do
        if config.id == id then
            return config
        end
    end
end

function TreasureBoxConfig:getBoxConfigByGroupId(groupId)
    return BoxGroups[tostring(groupId)]
end

function TreasureBoxConfig:getBoxItem(boxId)
    return BoxItems[boxId]
end

---@class TreasureBoxItemDBData
---@field boxId number
---@field status number value [0:未获得 1:未领取. 2:已领取]

---@param group TreasureBoxItemData[]
local function dgBoxList(group, totalCount, indexMap)
    local outIndexMap = nil
    for _, item in pairs(group) do
        if item.totalCount > 0 then
            ---随机结果
            local randomPos = math.random(1, #item.boxIndexList)
            ---标记
            local boxIndex = table.remove(item.boxIndexList, randomPos)
            indexMap[tostring(boxIndex)] = item.id
            item.totalCount = item.totalCount - 1
            ---递归
            outIndexMap = dgBoxList(group, totalCount, TableUtil.copyTable(indexMap))
            ---回溯
            table.insert(item.boxIndexList, randomPos, boxIndex)
            indexMap[tostring(boxIndex)] = nil
            item.totalCount = item.totalCount + 1
        end

        if TableUtil.getTableSize(outIndexMap) >= totalCount then
            break
        end
    end
    if outIndexMap == nil then
        return indexMap
    else
        return outIndexMap
    end
end

---@param _group TreasureBoxItemData[]
local function randomBoxList(_group)
    ---@type TreasureBoxItemData[]
    local group = {}
    ---@type TreasureBoxItemData[]
    local allPositionItemList = {}
    local needCount = 0
    for _, item in pairs(_group) do
        needCount = needCount + item.totalCount
        if item.boxIndexMap[-1] then
            table.insert(allPositionItemList, item)
        else
            table.insert(group, item)
        end
    end

    local boxList = {}
    local indexMap = dgBoxList(group, needCount, {})
    for index = 1, needCount do
        ---@type TreasureBoxItemDBData
        local data = {
            boxId = 0,
            status = 0
        }

        if indexMap[tostring(index)] then
            data.boxId = indexMap[tostring(index)]
        else
            ---@type TreasureBoxItemData
            local tempItem = CommonActivityConfig:randomWeightsPool(allPositionItemList)
            tempItem.totalCount = tempItem.totalCount - 1
            if tempItem.totalCount == 0 then
                tempItem.weights = 0
            end
            data.boxId = tempItem.id
        end
        table.insert(boxList, data)
    end

    return boxList
end

function TreasureBoxConfig:randomBoxListByGroupId(groupId)
    return randomBoxList(TableUtil.copyTable(self:getBoxConfigByGroupId(groupId)))
end

init()

return TreasureBoxConfig