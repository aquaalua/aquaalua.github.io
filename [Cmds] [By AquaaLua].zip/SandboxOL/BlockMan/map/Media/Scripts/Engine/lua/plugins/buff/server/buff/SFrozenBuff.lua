---@type SBaseBuff
local SBaseBuff = Plugins.Require("buff", "server.buff.SBaseBuff")

---@class SFrozenBuff : SBaseBuff
local SFrozenBuff = class("SFrozenBuff", SBaseBuff)

function SFrozenBuff.syncAllPlayer()
    return true
end

function SFrozenBuff:onCreate()
    local player = PlayerManager:getPlayerByUserId(self.targetId)
    if player then
        if not PlayerManager:isAIPlayer(player) then
            player.entityPlayerMP:setDisableMove(self.config.duration * 50)
        else
            player.entityPlayerMP:setAIMoveSpeed(0)
            local ai = AIManager:getAIByUserId(self.targetId)
            if ai then
                ai:setBanMove(true)
            end
        end
    end
end

function SFrozenBuff:onRemove()
    local player = PlayerManager:getPlayerByUserId(self.targetId)
    if player then
        if PlayerManager:isAIPlayer(player) then
            local ai = AIManager:getAIByUserId(self.targetId)
            if ai then
                ai:setBanMove(false)
            end
        end
    end
end

return SFrozenBuff