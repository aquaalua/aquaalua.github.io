---@type CustomGiftConfig
local CustomGiftConfig = Plugins.Require("activity", "common.config.CustomGiftConfig")
---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")
---@class CCustomGiftMgr : CBaseActivityMgr
local CCustomGiftMgr = class("CCustomGiftMgr", BaseActivityMgr)
---@type EventUtil
local EventUtil = T(Global, "EventUtil")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.CustomGift, CCustomGiftMgr, CustomGiftConfig)
----------------------------------------------------------------------------------

function CCustomGiftMgr:init()
    EventUtil.goObjEvent(self)
end

---@param mgrConfig LevelActivityConfigData
function CCustomGiftMgr:initActivity(mgrConfig)
    self.config = mgrConfig
    self.dataCache = {}
    self.chooseCacheData = {}
end

---@param player SBasePlayer
---@param cache LevelActivityDBData
function CCustomGiftMgr:setPlayerCache(player, cache)
    self.dataCache = cache
    if self.cacheCallBack then
        self.cacheCallBack()
    end
    self:emitEvent("CustomGiftCacheDataChange")
    self:initRedDot()
    self:checkRedDot()
end

---@return LevelActivityDBData
function CCustomGiftMgr:getPlayerCache()
    return self.dataCache or {}
end

-------------------------------------功能相关---------------------------------------------------
---缓存当前格子奖励选择结果
function CCustomGiftMgr:cacheChooseResult(giftId, cellId, index)
    if not next(self.chooseCacheData) then
        self.chooseCacheData = {
            giftId = giftId,
            cellIndexMap = {}
        }
    end
    self.chooseCacheData.cellIndexMap[cellId] = index
end

function CCustomGiftMgr:clearCacheChooseResult()
    self.chooseCacheData = {}
end

---提交礼包奖励选择结果
function CCustomGiftMgr:submitChooseResult()
    if self.chooseCacheData and next(self.chooseCacheData) then
        local chooseData = self.dataCache.chooseData
        if not chooseData then
            chooseData = {}
            self.dataCache.chooseData = chooseData
        end
        local giftChooseData = chooseData[self.chooseCacheData.giftId]
        if not giftChooseData then
            giftChooseData = {}
            chooseData[self.chooseCacheData.giftId] = giftChooseData
        end
        for cellId, index in pairs(self.chooseCacheData.cellIndexMap or {}) do
            giftChooseData[cellId] = index
        end
        PlayerManager:getClientPlayer():sendPacket({
            pid = "ToActivityPacket",
            activityId = self.mainConfig.id,
            funcName = "C2SSubmitChooseResult",
            chooseChangeData = self.chooseCacheData
        })
        self:emitEvent("CustomGiftRefreshReward", self.chooseCacheData)
        self.chooseCacheData = {}
    end
end

---获取奖励格子的选择数据
function CCustomGiftMgr:getChooseData()
    local chooseData = self:getPlayerCache().chooseData
    if not chooseData then
        chooseData = {}
        self.dataCache.chooseData = chooseData
    end
    return chooseData
end

---获取指定格子的奖励信息
function CCustomGiftMgr:getGiftCellChooseRewardData(giftId, cellId, index)
    local chooseData = self:getChooseData()
    if chooseData[giftId] then
        local rewardIndex = 0
        if index then
            rewardIndex = index
        else
            local chooseIndex = chooseData[giftId][cellId]
            if chooseIndex then
                rewardIndex = chooseIndex
            end
        end
        return CustomGiftConfig:getCellRewardDataByIndex(cellId, rewardIndex)
    else
        return CustomGiftConfig:getCellDefaultRewardData(cellId)
    end
end

---奖励格子是否选中了该奖励
function CCustomGiftMgr:isChooseReward(giftId, cellId, index)
    if next(self.chooseCacheData) then
        if self.chooseCacheData.giftId == giftId and
                self.chooseCacheData.cellId == cellId and
                self.chooseCacheData.index == index then
            return true
        else
            return false
        end
    else
        local rewardIndex = 0
        local chooseData = self:getChooseData()
        local giftChooseData = chooseData[giftId]
        if giftChooseData then
            rewardIndex = giftChooseData[cellId] or 0
        end
        if rewardIndex == 0 then
            ---判断是否默认奖励
            local cellCfg = CustomGiftConfig:getCellCfg(cellId)
            if cellCfg then
                return cellCfg.defaultRewardIndex == index
            end
        else
            return rewardIndex == index
        end
    end
end

---购买自定义礼包
function CCustomGiftMgr:buyCustomGift(giftId)
    if self:isGiftBuyLimit(giftId) then
        return
    end
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "C2SBuyCustomGift",
        giftId = giftId,
    })
end

---获取礼包记录的购买数量
function CCustomGiftMgr:getGiftBuyCount(giftId)
    local buyCountRecord = self.dataCache.buyCountRecord or {}
    return buyCountRecord[giftId] or 0
end

---判断是否限购
function CCustomGiftMgr:isGiftBuyLimit(giftId)
    local giftConfig = CustomGiftConfig:getCustomGiftCfgById(self.mainConfig.activityId, giftId)
    local buyCountRecord = self.dataCache.buyCountRecord or {}
    return (buyCountRecord[giftId] or 0) >= giftConfig.limitBuyCount
end

---判断礼包是否都选择了奖励，没有空格子
function CCustomGiftMgr:isGiftNeedChoose(giftId)
    local giftConfig = CustomGiftConfig:getCustomGiftCfgById(self.mainConfig.activityId, giftId)
    for i, cellId in ipairs(giftConfig.rewardCellList) do
        local rewardData = self:getGiftCellChooseRewardData(giftId, cellId)
        if (not rewardData) or (not next(rewardData)) then
            return true
        end
    end
    return false
end

function CCustomGiftMgr:checkRedDot()
    for _, giftCfg in pairs(self.config) do
        if giftCfg.price == 0 then
            local value = 0
            if not self:isGiftBuyLimit(giftCfg.id) then
                value = 1
            end
            UIUtils.updateRedDotCount(self.mainConfig.id.."_"..giftCfg.id, value)
        end
    end
end

function CCustomGiftMgr:initRedDot()
    for _, giftCfg in pairs(self.config) do
        if giftCfg.price == 0 then
            UIUtils.dynamicAddRedDot(self.mainConfig.id.."_"..giftCfg.id,Define.RedDotKey.GameActivity .. "_" .. self.mainConfig.id, 0)
        end
    end
end

CCustomGiftMgr:init()

return CCustomGiftMgr