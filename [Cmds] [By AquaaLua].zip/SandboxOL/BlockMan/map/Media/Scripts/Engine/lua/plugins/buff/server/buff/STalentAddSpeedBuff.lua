---@type SBaseBuff
local SBaseBuff = Plugins.Require("buff", "server.buff.SBaseBuff")

---@class STalentAddSpeedBuff : SBaseBuff
local STalentAddSpeedBuff = class("STalentAddSpeedBuff", SBaseBuff)

function STalentAddSpeedBuff.syncAllPlayer()
    return true
end

function STalentAddSpeedBuff:onCreate()
    self.addSpeed = tonumber(self.config.param[1]) * 10
    local player = PlayerManager:getPlayerByUserId(self.targetId)
    if player then
        player:changeSpeed(self.addSpeed)
        if self.addSpeed < 0 then
            self:calcLessEndTime()
        end
    end
end

function STalentAddSpeedBuff:onRemove()
    local player = PlayerManager:getPlayerByUserId(self.targetId)
    if player then
        player:changeSpeed(-self.addSpeed)
    end
end

return STalentAddSpeedBuff