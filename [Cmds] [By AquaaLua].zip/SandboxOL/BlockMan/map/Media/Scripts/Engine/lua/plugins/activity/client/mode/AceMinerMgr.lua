---@type AceMinerConfig
local AceMinerConfig = Plugins.Require("activity", "common.config.AceMinerConfig")

---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")

---@class AceMinerMgr : CBaseActivityMgr
local AceMinerMgr = class("CAceMinerMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.AceMiner, AceMinerMgr, AceMinerConfig)
----------------------------------------------------------------------------------
---@param mgrConfig AceMinerConfigData
function AceMinerMgr:initActivity(mgrConfig)
    self.config = mgrConfig
end

local function getDayStartTime(time)
    local t = os.date("*t", time)
    local timestamp = DateUtil.date2BeiJingTime({ year = t.year, month = t.month, day = t.day, hour = 0, min = 0, sec = 0 })
    return timestamp
end

local function getDeltaDay(startTime, endTime)
    local deltaDay = (getDayStartTime(endTime) - getDayStartTime(startTime)) / (3600 * 24)
    return math.floor(deltaDay)
end

local function getCanReceiveCount(self, startTime, curTime)
    if curTime < startTime then
        return 0
    end
    local deltaDay = getDeltaDay(startTime, curTime)
    if deltaDay < 0 then
        return 0
    end
    local maxNum = AceMinerConfig:getMaxBoxNum(self.mainConfig.id)
    if deltaDay >= maxNum then
        return maxNum
    end
    return deltaDay + 1
end

---@param player SBasePlayer
---@param cache AceMinerDBData
function AceMinerMgr:setPlayerCache(player, cache)
    self.dataCache = cache
    if self.cacheCallBack then
        self.cacheCallBack()
    end
end

---@return AceMinerDBData
function AceMinerMgr:getPlayerCache()
    return self.dataCache or {
        receiveCount = 0,
    }
end

function AceMinerMgr:buy()
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "buy"
    })
    return true
end

function AceMinerMgr:isGetAllReward()
    local maxBoxNum = self:getMaxBoxNum()
    local cache = self:getPlayerCache()

    return cache.receiveCount >= maxBoxNum
end

function AceMinerMgr:getMaxBoxNum()
    return AceMinerConfig:getMaxBoxNum(self.mainConfig.id)
end

function AceMinerMgr:getNextDayStartTime()
    return getDayStartTime(os.time() + (3600 * 24))
end

--function AceMinerMgr:checkCanReceive()
--    local cache = self:getPlayerCache()
--    if cache.receiveCount >= self:getMaxBoxNum() then
--        return false
--    end
--
--    local canReceiveCount = getCanReceiveCount(self, self.mainConfig.startTime, os.time())
--    if cache.receiveCount >= canReceiveCount then
--        return false
--    end
--    return true
--end

function AceMinerMgr:getCurrentCountPrice()
    local cache = self:getPlayerCache()
    local num = cache.receiveCount + 1
    return self.config[num] and self.config[num].price or 0
end

function AceMinerMgr:getCurrentCountShowPrice()
    local cache = self:getPlayerCache()
    local num = cache.receiveCount + 1
    return self.config[num] and self.config[num].showPrice or 0
end

function AceMinerMgr:getActivityCfgByBoxId(boxId)
    local cfg = AceMinerConfig:getActivityById(self.mainConfig.id)
    if not cfg then
        return {}
    end
    for i, v in pairs(cfg) do
        if v.boxId == boxId then
            return v
        end
    end
    return {}
end

return AceMinerMgr