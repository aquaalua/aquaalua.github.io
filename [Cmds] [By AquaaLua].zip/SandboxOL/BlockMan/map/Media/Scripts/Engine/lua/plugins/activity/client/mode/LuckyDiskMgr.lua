---@type LuckyDiskConfig
local LuckyDiskConfig = Plugins.Require("activity", "common.config.LuckyDiskConfig")

---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")

---@class LuckyDiskMgr : CBaseActivityMgr
local LuckyDiskMgr = class("CLuckyDiskMgr", BaseActivityMgr)

BaseActivityMgr.addActivityType(BaseActivityMgr.ActivityType.LuckyDisk, LuckyDiskMgr, LuckyDiskConfig)
----------------------------------------------------------------------------------
---@param mgrConfig LuckyDiskConfigData
function LuckyDiskMgr:initActivity(mgrConfig)
    self.config = mgrConfig
end

---@param player SBasePlayer
---@param cache LuckyDiskDBData
function LuckyDiskMgr:setPlayerCache(player, cache)
    self.dataCache = cache
    if self.cacheCallBack then
        self.cacheCallBack()
    end
end

---@return LuckyDiskDBData
function LuckyDiskMgr:getPlayerCache()
    return self.dataCache or {
        storeList = {}, --当前随机出来的物品
        curSelectId = {},
        refreshTimes = 1,
        buyTimes = 1,
        startDayTime = 0,
    }
end

---@return LuckyDiskRewardConfig
function LuckyDiskMgr:getRewardCfgById(id)
    for _, v in pairs(self.config.rewardCfg) do
        if id == v.id then
            return v
        end
    end
end

---@return LuckyDiskRewardConfig[]
function LuckyDiskMgr:getRewardCfg()
    return self.config.rewardCfg
end

---@return LuckyDiskRefreshPriceConfig
function LuckyDiskMgr:getRefreshPricesCfg(refreshTime)
    local refreshPriceCfg = self.config.refreshPriceCfg

    if refreshTime > #refreshPriceCfg then
        return refreshPriceCfg[#refreshPriceCfg]
    end
    for _, v in pairs(refreshPriceCfg) do
        if refreshTime == v.times then
            return v
        end
    end
end

---@return LuckyDiskBuyPricesConfig
function LuckyDiskMgr:getBuyPricesCfg(refreshTime)
    local buyPriceCfg = self.config.buyPriceCfg
    if refreshTime > #buyPriceCfg then
        return buyPriceCfg[#buyPriceCfg]
    end
    for _, v in pairs(buyPriceCfg) do
        if refreshTime == v.times then
            return v
        end
    end
end

function LuckyDiskMgr:refreshPool()
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "refreshPool",
    })
end

function LuckyDiskMgr:tryBuy()
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ToActivityPacket",
        activityId = self.mainConfig.id,
        funcName = "buy",
    })
end

function LuckyDiskMgr:luckyDiskDataRefresh()
    Events.LuckyDiskPoolRefreshEvent:invoke(self.mainConfig.activityId)
end

function LuckyDiskMgr:getNextDayStartTime()
    return DateUtil.getUTCDayStartTime(os.time() + (3600 * 24))
end

return LuckyDiskMgr
