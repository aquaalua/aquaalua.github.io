---@class AtLessLotteryConfig
local AtLessLotteryConfig = {}
---@type AtLessLotteryData[]
local ConfigList = {}
---@type table<string, table<string, AtLessRewardGroupData[]>>
local GroupDataList = {}

local function initCfg()
    ConfigList = {}
end

local function initConfig()
    local path = FileUtil:getMapPath() .. "plugins/activity/AtLessLottery.csv"
    local file = io.open(path, "r")
    if not file then
        return
    end
    file:close()

    local settings = CsvUtil.loadCsvFile(path, 3)
    for _, item in pairs(settings) do
        ---@class AtLessLotteryData
        local data = {
            id = tonumber(item.id),
            rewardGroupId = tonumber(item.rewardGroupId),
            conditionType = tonumber(item.conditionType),
            dailyTimes = tonumber(item.dailyTimes),
            totalTimes = tonumber(item.totalTimes),
        }
        table.insert(ConfigList, data)
    end
end

local function initRewardGroupConfig()
    local path = FileUtil:getMapPath() .. "plugins/activity/AtLessRewardGroup.csv"
    local file = io.open(path, "r")
    if not file then
        return
    end
    file:close()

    local settings = CsvUtil.loadCsvFile(path, 3)
    for _, item in pairs(settings) do
        ---@type table<string, AtLessRewardGroupData[]>
        local times_group = GroupDataList[tostring(item.groupId)] or {}
        ---@type AtLessRewardGroupData[]
        local reward_group = times_group[tostring(item.rewardTimes)] or {}
        ---@class AtLessRewardGroupData
        local data = {
            index = tonumber(item.index),
            rewardId = tonumber(item.rewardId),
        }
        table.insert(reward_group, data)
        times_group[tostring(item.rewardTimes)] = reward_group
        GroupDataList[tostring(item.groupId)] = times_group
    end
end

local function init()
    initCfg()
    initRewardGroupConfig()
    initConfig()
end

function AtLessLotteryConfig:getConfigList()
    return ConfigList
end

function AtLessLotteryConfig:getActivityById(id)
    for _, config in pairs(ConfigList) do
        if config.id == id then
            return config
        end
    end
end

function AtLessLotteryConfig:getRewardGroup(groupId)
    return GroupDataList[tostring(groupId)] or {}
end

init()

return AtLessLotteryConfig